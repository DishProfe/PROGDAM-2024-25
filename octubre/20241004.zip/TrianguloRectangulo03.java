package ejemplos2024;
import ejemplos2023.*;
import java.util.Scanner;

/**
 *
 * @author portatil_profesorado
 */
public class TrianguloRectangulo03 {
    
    public static void main(String[] args) {
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Variables de entrada
        double base, altura;
        
        // Variables de salida
        double superficieMetros, perimetroMetros;
        double superficieCentimetros, perimetroCentimetros;
        
        // Variables auxiliares
        double hipotenusa;
        

        // Entrada de datos
        // ----------------
        System.out.println ("CÁLCULO DE PERÍMETRO Y SUPERFICIE DE TRIÁNGULOS RECTÁNGULOS");
        System.out.println ("-----------------------------------------------------------");
        
        System.out.print ("Introduzca base (m): ");
        base = teclado.nextDouble();
        
        System.out.print ("Introduzca altura (m): ");
        altura = teclado.nextDouble();
        
        // Procesamiento
        // -------------

        // Cálculo de la superficie del triángulo
        superficieMetros = base * altura / 2;

        // Cálculo del perímetro del triángulo
        hipotenusa = Math.sqrt ( base*base + altura*altura );
        perimetroMetros = base + altura + hipotenusa;
        
        // Pasamos a centímetros
        perimetroCentimetros = perimetroMetros * 100;
        superficieCentimetros = superficieMetros * 100*100;
        
        
        // Salida de resultados
        // --------------------
        System.out.println();

        System.out.print ("Superficie en metros: ");
        System.out.print ( superficieMetros );
        System.out.println ( " m2" );
        System.out.print ("Superficie en centímetros: ");
        System.out.print ( superficieCentimetros );
        System.out.println ( " cm2" );
        
        System.out.println();
        
        System.out.print ("Perímetro en metros: ");
        System.out.print ( perimetroMetros );
        System.out.println ( " m" );
        System.out.print ("Perímetro en centímetros: ");
        System.out.print ( perimetroCentimetros );
        System.out.println ( " cm" );
        
        
    }

}
