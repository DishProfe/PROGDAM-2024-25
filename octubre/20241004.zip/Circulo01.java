package ejemplos2023;


import java.util.Scanner;

/**
 *   Programa para calcular superficie y perímetro de una circunferencia
 */

public class Circulo01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        double radio;
        
        
        // Variables de salida
        double area, perimetro;


        // Variables auxiliares


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos
        //----------------------------------------------
        System.out.println("ÁREA Y PERÍMETRO DE CÍRCULOS");
        System.out.println("----------------------------");
        System.out.println("Introduzca radio (cm): ");
        radio = teclado.nextDouble();
        
        //----------------------------------------------
        //                 Procesamiento
        //----------------------------------------------
        
        // Cáculo del perímetro
        perimetro = 2 * 3.14 * radio;
        
        // Cáculo de la superficie
        area = 3.14 * radio * radio;
        
        //----------------------------------------------
        //              Salida de resultados
        //----------------------------------------------
        
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        System.out.print ("Perímetro = ");
        System.out.print (perimetro);
        System.out.println (" cm");
        System.out.print ("Área = ");
        System.out.print (area);
        System.out.println (" cm2");
        
        System.out.println ();
        System.out.println ("Fin del programa.");
        
        
    }
    
}