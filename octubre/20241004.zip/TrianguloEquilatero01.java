package ejemplos2023;
import java.util.Scanner;

/**
 *
 * @author portatil_profesorado
 */
public class TrianguloEquilatero01 {
    
    public static void main(String[] args) {
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Variables de entrada
        double base, altura;
        
        // Variables de salida
        double superficie, perimetro;
        

        // Entrada de datos
        // ----------------
        System.out.println ("CÁLCULO DE PERÍMETRO Y SUPERFICIE DE TRIÁNGULOS EQUILÁTEROS");
        System.out.println ("-----------------------------------------------------------");
        
        System.out.print ("Introduzca base (cm): ");
        base = teclado.nextDouble();
        
        System.out.print ("Introduzca altura (cm): ");
        altura = teclado.nextDouble();
        
        // Procesamiento
        // -------------

        // Cálculo de la superficie del triángulo
        superficie = base * altura / 2;

        // Cálculo del perímetro del triángulo
        perimetro = base * 3;

        
        // Salida de resultados
        // --------------------
        System.out.print ("Superficie: ");
        System.out.print ( superficie );
        System.out.println ( " cm2" );
        
        
        System.out.print ("Perímetro: ");
        System.out.print ( perimetro );
        System.out.println ( " cm" );
        
        
    }

}
