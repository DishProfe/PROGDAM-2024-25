
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercicioPrimUltLetra01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        String palabra;
        
        // Variables de salida
        char primeraLetra, ultimaLetra;
        
        // Variables auxiliares
        int longitud;
        

        // Entrada de datos
        // ----------------
        System.out.println ("PRIMERA Y ÚLTIMA LETRA"); 
        System.out.println ("----------------------"); 

        System.out.print ("Introduzca palabra: ");
        palabra = teclado.nextLine();
        
        // Procesamiento
        // -------------
        longitud = palabra.length();

        primeraLetra = palabra.charAt(0);
        ultimaLetra = palabra.charAt(longitud-1);
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("Palabra: " + palabra);
        System.out.println ("Primera letra: " + primeraLetra);
        System.out.println ("Última letra: " + ultimaLetra);
        
        
        
        
        
        
        
    }    
    
    
    
}
