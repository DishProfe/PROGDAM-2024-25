
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjOperadores02 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        
        // Variables de entrada
        int  x = 6;
        
        // Variables de salida
        
        // Variables auxiliares
        
        
        
        // Entrada de datos
        // ----------------
        System.out.println ("EJEMPLOS DE OPERADORES"); 
        System.out.println ("----------------------"); 

        
        // Procesamiento
        // -------------
        System.out.print ("x=");
        System.out.println (x);
        
        x = x + 4;
        System.out.print ("x=");
        System.out.println (x);
        
        x = x - 14;
        System.out.print ("x=");
        System.out.println (x);
        
        x = x * -3;
        System.out.print ("x=");
        System.out.println (x);
        
        x = x / 4;
        System.out.print ("x=");
        System.out.println (x);

        System.out.print ("x=");
        System.out.println (--x);

        


        
        
        
        
        
        // Salida de resultados
        // --------------------
        
        
        
        
        
        
        
    }    
    
    
    
}
