
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjOperadores06 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        
        // Variables de entrada
        boolean v1,v2;
        
        // Variables de salida
        boolean resultadoComparacion;
        
        // Variables auxiliares
        
        
        
        // Entrada de datos
        // ----------------
        System.out.println ("EJEMPLOS DE OPERADORES: OPERADORES LÓGICOS"); 
        System.out.println ("------------------------------------------"); 

        
        // Procesamiento
        // -------------
        v1 = true;
        v2 = false;
        System.out.print ("v1=");
        System.out.println (v1);
        System.out.print ("v2=");
        System.out.println (v2);
        System.out.println ();


        resultadoComparacion = v1 & v2;
        System.out.print ( "v1 & v2 = " + resultadoComparacion );
        System.out.println ();

        resultadoComparacion = v1 | v2;
        System.out.print ( "v1 | v2 = " + resultadoComparacion );
        System.out.println ();

        resultadoComparacion = !v1;
        System.out.print ( "!v1 = " + resultadoComparacion );
        System.out.println ();

        resultadoComparacion = !v2;
        System.out.print ( "!v2 = " + resultadoComparacion );
        System.out.println ();

        resultadoComparacion = v1 & !v2;
        System.out.print ( "v1 & !v2 = " + resultadoComparacion );
        System.out.println ();

        resultadoComparacion = v1 && v2;
        System.out.print ( "v1 && v2 = " + resultadoComparacion );
        System.out.println ();

        resultadoComparacion = v1 || v2;
        System.out.print ( "v1 || v2 = " + resultadoComparacion );
        System.out.println ();
        
        // Salida de resultados
        // --------------------
        
        
        
        
        
        
        
    }    
    
    
    
}
