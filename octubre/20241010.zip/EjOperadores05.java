
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjOperadores05 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        
        // Variables de entrada
        int  x,z;
        
        // Variables de salida
        boolean resultadoComparacion;
        
        // Variables auxiliares
        
        
        
        // Entrada de datos
        // ----------------
        System.out.println ("EJEMPLOS DE OPERADORES: OPERADORES RELACIONALES"); 
        System.out.println ("-----------------------------------------------"); 

        
        // Procesamiento
        // -------------
        x = 5;
        z = 6;
        System.out.print ("x=");
        System.out.println (x);
        System.out.print ("z=");
        System.out.println (z);
        System.out.println ();


        resultadoComparacion = x!=z;
        System.out.print ( resultadoComparacion );
        System.out.println ();

        resultadoComparacion = x==z;
        System.out.print ( resultadoComparacion );
        System.out.println ();

        resultadoComparacion = x<z;
        System.out.print ( resultadoComparacion );
        System.out.println ();

        resultadoComparacion = x>=z;
        System.out.print ( resultadoComparacion );
        System.out.println ();

        resultadoComparacion = x<=z;
        System.out.print ( resultadoComparacion );
        System.out.println ();

        resultadoComparacion = x>z;
        System.out.print ( resultadoComparacion );
        System.out.println ();
        
        // Salida de resultados
        // --------------------
        
        
        
        
        
        
        
    }    
    
    
    
}
