
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjOperadores04 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        
        // Variables de entrada
        int  x,y;
        
        // Variables de salida
        
        // Variables auxiliares
        
        
        
        // Entrada de datos
        // ----------------
        System.out.println ("EJEMPLOS DE OPERADORES: OPERADORES RELACIONALES"); 
        System.out.println ("-----------------------------------------------"); 

        
        // Procesamiento
        // -------------
        x = 10;
        y = 6;
        System.out.print ("x=");
        System.out.println (x);
        System.out.print ("y=");
        System.out.println (y);
        System.out.println ();


        System.out.print ("x>5 = ");
        System.out.print ( x>5 );
        System.out.println ();
        
        System.out.print ("x>=y -> ");
        System.out.print ( x>=y );
        System.out.println ();

        System.out.print ("y<=x-4 -> ");
        System.out.print ( y<=x-4 );
        System.out.println ();

        System.out.print ("x<y -> ");
        System.out.print ( x<y );
        System.out.println ();

        System.out.print ("x==y -> ");
        System.out.print ( x==y );
        System.out.println ();

        System.out.print ("x!=y -> ");
        System.out.print ( x!=y );
        System.out.println ();
        
        // Salida de resultados
        // --------------------
        
        
        
        
        
        
        
    }    
    
    
    
}
