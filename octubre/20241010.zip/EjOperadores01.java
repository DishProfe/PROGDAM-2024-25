
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjOperadores01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        
        // Variables de entrada
        
        // Variables de salida
        
        // Variables auxiliares
        
        int entero =  10;
        double real = 10;
        
        int  ent1 = 2_000_000_000;
        long ent4 = 2_000_000_000L;


        int ent2 = 2000000000;
        long ent3 = 2_500_000_000L;
        
        short ent5 = 32767;

        int ent6 = 0b1111_1111;
        int ent7 = 0xFF;
        int ent8 = 255;
        int ent9  = 0b1_111;
        int ent10 = 017;
        
        
        
        // Entrada de datos
        // ----------------
        System.out.println ("EJEMPLOS DE OPERADORES"); 
        System.out.println ("----------------------"); 

        
        // Procesamiento
        // -------------
        
        int suma1 = 55;
        suma1 = 12+15;
        suma1 = 12*10;
        int suma2 = suma1 + 100;
        int var1 = -2;
        int var2 = -var1;
        
        int var3 = 7 / 3 ;
        
        double var4 = 7.0 / 3 ;
        
        int var5 = 7 / 2 ;
        int var6 = 7 % 2;
        int var7 = 11 % 4;
        
        int var8 = 10;
        var8 =  var8 + 1;
        var8++;
        ++var8;
        
        var8 = 10;
        int x = var8++;  // x <- 10, var8<-var8+1
        var8 = 10;
        int y = ++var8;  // var8 <- var8+1, y<- 11
        
        
        
        
        
        
        
        
        // Salida de resultados
        // --------------------
        
        
        
        
        
        
        
    }    
    
    
    
}
