
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjOperadores03 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        
        // Variables de entrada
        int  x,y;
        
        // Variables de salida
        
        // Variables auxiliares
        
        
        
        // Entrada de datos
        // ----------------
        System.out.println ("EJEMPLOS DE OPERADORES"); 
        System.out.println ("----------------------"); 

        
        // Procesamiento
        // -------------
        x = 10;
        y = 10;
        System.out.print ("x=");
        System.out.println (x);
        System.out.print ("y=");
        System.out.println (y);
        System.out.println ();


        
        x =  x + 5;
        y += 5;
        System.out.print ("x=");
        System.out.println (x);
        System.out.print ("y=");
        System.out.println (y);
        System.out.println ();
        

        x =  x * 2;
        y *= 2;
        System.out.print ("x=");
        System.out.println (x);
        System.out.print ("y=");
        System.out.println (y);
        System.out.println ();

        int a = 10;
        int b = 10;
        int c = 10;
        System.out.print ("a=");
        System.out.println (a);
        System.out.print ("b=");
        System.out.println (b);
        System.out.print ("c=");
        System.out.println (c);
        System.out.println ();
        
        a= a+1;
        b++;
        c+= 1;
        System.out.print ("a=");
        System.out.println (a);
        System.out.print ("b=");
        System.out.println (b);
        System.out.print ("c=");
        System.out.println (c);
        System.out.println ();
        
        
        // Salida de resultados
        // --------------------
        
        
        
        
        
        
        
    }    
    
    
    
}
