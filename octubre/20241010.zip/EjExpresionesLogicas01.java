
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjExpresionesLogicas01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        
        // Variables de entrada
        int x1=10, x2=5, x3=0;
        char c1='F', c2='S';        

        // Variables de salida
        
        // Variables auxiliares
        
        
        
        // Entrada de datos
        // ----------------
        System.out.println ("EJEMPLOS DE OPERADORES: EXPRESIONES LÓGICAS"); 
        System.out.println ("-------------------------------------------"); 

        
        // Procesamiento
        // -------------
        
        // Salida de resultados
        // --------------------
        System.out.println ("x1 = " + x1);
        System.out.println ("x2 = " + x2);
        System.out.println ("x3 = " + x3);
        System.out.println ("c1 = " + c1);
        System.out.println ("c2 = " + c2);
        System.out.println ();

        System.out.print ("x1 es igual a x2: ");
        System.out.println (x1 == x2);
        
        System.out.print ("c1 es distinto de c2: ");
        System.out.println (c1 != c2);
        
        System.out.print ("x1 está entre 10 y 100: ");
        System.out.println ( x1>=10 && x1<=100  );
        
        System.out.print ("x2 no está entre 10 y 100: ");
        System.out.println ( !(x2>=10 && x2<=100)  );
        System.out.println ( x2<10 || x2>100 );
        
        
    }    
    
    
    
}
