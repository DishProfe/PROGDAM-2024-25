
package ejemplos2024;

/**
 *
 * @author diosdado
 */
public class Prog03 {
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.print ("2+3=");
        System.out.println (2+3);
        
        
    }    
    
    
    
}
