
package ejemplos2024;

/**
 *
 * @author diosdado
 */
public class Prog04 {
    
    
    public static void main(String[] args) {
        
        // 1. Escribir por pantalla
        // Hola Juan
        System.out.println ("--------------------");
        System.out.println ("Hola Juan");
        //System.out.print ("1. Hola ");
        //System.out.println ("Juan");
        
        
        // 2. Escribir por pantalla 
        // Hola
        // Juan
        System.out.println ("--------------------");
        System.out.println ("Hola");
        System.out.println ("Juan");
                
        // 3. Escribir por pantalla usando println
        // Hola
        //
        // Juan
        System.out.println ("--------------------");
        System.out.println ("Hola");
        System.out.println ();
        System.out.println ("Juan");

        // 4. Escribir por pantalla sin usar println, usando\n
        // Hola
        //
        // Juan
        System.out.println ("--------------------");
        System.out.print ("Hola\n\n");
        System.out.print ("Juan\n");
        

        
        
    }    
    
    
    
}
