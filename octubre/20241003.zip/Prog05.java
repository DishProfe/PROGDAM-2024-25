
package ejemplos2024;

/**
 *
 * @author diosdado
 */
public class Prog05 {
    
    
    public static void main(String[] args) {
    
        System.out.print ("Primer elemento: ");
        System.out.println (2);
        
        System.out.print ("Segundo elemento: ");
        System.out.println (3);
        
        System.out.print ("Suma: ");
        System.out.println (2+3);
    }
    
    
    
}
