
package ejemplos2024;

/**
 *
 * @author diosdado
 */
public class Prog01 {
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        

        // Mostramos por pantalla el texto "Hola"
        System.out.println ("Hola"); 
        System.out.println ("Diosdado");

        
        
    }    
    
    
    
}
