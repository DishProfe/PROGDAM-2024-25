package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class NumeroPositivo07 {

    public static void main(String[] args) {

        // Entrada de datos
        Scanner teclado = new Scanner(System.in);
        int numero;
        System.out.print("Introduzca un número entero: ");
        numero = teclado.nextInt();

        
        System.out.println ("El número " +  (numero>0 ? "es " : "no es ") +  "positivo." );

    }

}
