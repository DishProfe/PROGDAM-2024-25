package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjemploCondicionales06 {

    public static void main(String[] args) {

        // Entrada de datos
        Scanner teclado = new Scanner(System.in);
        int numero;
        System.out.print("Introduzca un número entero: ");
        numero = teclado.nextInt();
        
        if (numero % 2 == 0) ;
            System.out.print("El número es par");

    }

}
