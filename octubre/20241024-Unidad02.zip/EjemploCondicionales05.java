package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjemploCondicionales05 {

    public static void main(String[] args) {

        // Entrada de datos
        Scanner teclado = new Scanner(System.in);
        int numero;
        System.out.print("Introduzca un número entero: ");
        numero = teclado.nextInt();

        if (numero % 2 == 0) {  // Si el resto de la división entera entre 2 es cero, el número es par
            System.out.println("El número es par.");
        } else { // Si no, el número es impar
            System.out.println("El número es impar.");
        }

    }

}
