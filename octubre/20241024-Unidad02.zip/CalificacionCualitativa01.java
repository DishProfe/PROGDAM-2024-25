package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class CalificacionCualitativa01 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        
        
        // Variables de entrada
        double nota;  // Calificación cuantitativa

        // Variables de salida
        String calificacionCualitativa; // Calificación cualitativa
        
        // Entrada de datos
        System.out.print("Introduzca una nota real cuantitativa (0-10): ");
        nota = teclado.nextDouble();

        // Procesamiento
        if (nota >= 5.0) {
            calificacionCualitativa = "APROBADO";
        } else {
            calificacionCualitativa = "SUSPENSO";            
        }
        
        
        // Salida de resultados
        System.out.println ("La calificación cualitativa es: " +  calificacionCualitativa);
        
        
        

    }

}
