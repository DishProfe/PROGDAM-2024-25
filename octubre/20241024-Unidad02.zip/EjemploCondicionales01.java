package ejemplos2024;

/**
 *
 * @author diosdado
 */
public class EjemploCondicionales01 {

    public static void main(String[] args) {

        int valor = 10;
        System.out.println("El programa está ejecutándose."); // Esta línea se ejecuta en cualquier caso
        if (valor < 0) {
            System.out.println("El valor es negativo."); // Esta línea solo se ejecuta si valor < 0
        }
        System.out.println("El programa sigue ejecutándose."); // Esta línea se ejecuta en cualquier caso        

    }

}
