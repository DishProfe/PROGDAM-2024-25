package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjemploCondicionales08 {

    public static void main(String[] args) {

        // Entrada de datos
        Scanner teclado = new Scanner(System.in);
        int numero;
        System.out.print("Introduzca un número entero: ");
        numero = teclado.nextInt();
        
        if (numero % 2 == 0 ) {
            
            if (numero > 100) {
                System.out.println ("El número es par y mayor que 100");
            }
        }
    }

}
