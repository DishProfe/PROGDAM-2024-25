package ejemplos2024;

/**
 *
 * @author diosdado
 */
public class EjemploCondicionales02 {

    public static void main(String[] args) {

        int valor = 100;
        System.out.println("El programa está ejecutándose."); // Esta línea se ejecuta en cualquier caso
        if (valor < 0) {
            System.out.println("El valor es negativo."); // Esta línea solo se ejecuta si valor < 0
            valor = 0; // Esta línea solo se ejecuta si valor < 0
            System.out.println("El valor ha sido reseteado a cero."); // Esta línea solo se ejecuta si valor < 0
        }
        System.out.println("Contenido de la variable valor tras el condicional: " + valor);
        System.out.println("El programa sigue ejecutándose."); // Esta línea se ejecuta en cualquier caso     
        
    }

}
