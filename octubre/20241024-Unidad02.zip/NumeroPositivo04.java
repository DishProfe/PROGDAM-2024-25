package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class NumeroPositivo04 {

    public static void main(String[] args) {

        // Entrada de datos
        Scanner teclado = new Scanner(System.in);
        int numero;
        System.out.print("Introduzca un número entero: ");
        numero = teclado.nextInt();

        
       
        System.out.println (  numero>0   ? "El número es positivo." : "El número no es positivo.");

    }

}
