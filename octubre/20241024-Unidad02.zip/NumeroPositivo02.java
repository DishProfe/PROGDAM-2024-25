package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class NumeroPositivo02 {

    public static void main(String[] args) {

        // Entrada de datos
        Scanner teclado = new Scanner(System.in);
        int numero;
        System.out.print("Introduzca un número entero: ");
        numero = teclado.nextInt();

        if ( numero <= 0 ) {
            System.out.println ("El número no es positivo.");
        } else {
            System.out.println ("El número es positivo.");
        }

    }

}
