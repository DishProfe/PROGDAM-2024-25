package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class DiaSemana02 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int diaNumerico;
        
        // Variables de salida
        String diaSemana = "";
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("DÍA DE LA SEMANA"); 
        System.out.println ("----------------"); 

        System.out.println ("Introduzca día de la semana numérico (entero 1-7): ");
        diaNumerico = teclado.nextInt();

        
        // Procesamiento
        // -------------
        if ( diaNumerico < 1 || diaNumerico > 7 ){
            diaSemana = "error";
        } else {
            switch ( diaNumerico ) {                
                case 1:
                    diaSemana = "lunes";
                    break;                
                case 2:
                    diaSemana = "martes";
                    break;
                case 3:
                    diaSemana = "miércoles";
                    break;
                case 4:
                    diaSemana = "jueves";
                    break;
                case 5:
                    diaSemana = "viernes";
                    break;
                case 6:
                    diaSemana = "sábado";
                    break;
                case 7:
                    diaSemana = "domingo";
                    break;
            }
        } 
            
        
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El día de la semana es: " + diaSemana);
        
        
        
        
        
        
    }    

}
