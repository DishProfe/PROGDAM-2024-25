package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class MayorMenor01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int numero1, numero2;
        
        // Variables de salida
        int maximo, minimo;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("CÁLCULO DEL MÁXIMO Y MÍNIMO"); 
        System.out.println ("---------------------------"); 

        System.out.println ("Introduzca primer número: ");
        numero1 = teclado.nextInt();

        System.out.println ("Introduzca segundo número: ");
        numero2 = teclado.nextInt();
        
        // Procesamiento
        // -------------
        maximo = numero1 > numero2 ? numero1 : numero2 ;
        minimo = numero1 < numero2 ? numero1 : numero2 ;
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El máximo es " + maximo);
        System.out.println ("El mínimo es " + minimo);
        
        
        
        
        
        
        
    }    

}
