package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Contando02 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int inicio, fin;

        // Variables de salida

        // Variables auxiliares
        int contador;
        
        // Entrada de datos
        // ----------------
        System.out.println("CONTANDO NÚMEROS");
        System.out.println("----------------");

        System.out.println ("Introduzca inicio: ");
        inicio = teclado.nextInt();

        System.out.println ("Introduzca fin: ");
        fin = teclado.nextInt();
        
        
        
        // Procesamiento
        // -------------
        // Inicialización
        contador = inicio;

        while (contador <= fin) {
            System.out.println(contador);
            contador++;
        }
        
        // Salida de resultados
        // --------------------
        System.out.println();

    }

}
