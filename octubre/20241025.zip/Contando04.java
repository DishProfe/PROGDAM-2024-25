package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Contando04 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int inicio, fin;

        // Variables de salida

        // Variables auxiliares
        int contador;
        
        // Entrada de datos
        // ----------------
        System.out.println("CONTANDO NÚMEROS");
        System.out.println("----------------");

        do {
            System.out.println ("Introduzca inicio y fin (inicio<=fin)");
        
            System.out.println ("Inicio: ");
            inicio = teclado.nextInt();

            System.out.println ("Fin: ");
            fin = teclado.nextInt();
        } while ( inicio > fin );
        
        
        // Procesamiento
        // -------------
        // Inicialización
        contador = inicio;

        
        System.out.print ("Secuencia de números de " + inicio + " a " + fin + ": ");
        while (contador <= fin) {
            System.out.print (contador + " ");
            contador++;
        }
        
        // Salida de resultados
        // --------------------
        System.out.println();

    }

}
