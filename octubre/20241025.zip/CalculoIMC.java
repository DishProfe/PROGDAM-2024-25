
package ejemplos2024;

/**
 *
 * @author diosdado
 */
import java.util.Scanner;

public class CalculoIMC
{

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Variables de entrada
        double peso, altura;

        // Variables de salida
        double imc;
        String mensaje;

        // Variables auxiliares
        // Objeto Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CÁLCULO DEL ÍNDICE DE MASA CORPORAL (IMC)");
        System.out.println("-----------------------------------------");
        System.out.print("Introduce el peso (en kg): ");
        peso = teclado.nextDouble();
        System.out.print("Introduce la altura (en cm): ");
        altura = teclado.nextDouble() / 100.0;  //Pasamos a metros la altura dividiendo por 100

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        imc = peso / (altura * altura);

        if (imc < 16) {
            mensaje = "Necesita ingresar en un hospital.";
        } else if (imc < 17) {
            mensaje = "Tiene infrapeso.";
        } else if (imc < 18) {
            mensaje = "Tiene bajo peso.";
        } else if (imc < 26) {
            mensaje = "Tiene un peso saludable.";
        } else if (imc < 30) {
            mensaje = "Tiene sobrepeso de grado I.";
        } else if (imc < 35) {
            mensaje = "Tiene obesidad de grado II.";
        } else if (imc < 40) {
            mensaje = "Tiene obesidad premórbida o de grado III.";
        } else {
            mensaje = "Tiene obesidad mórbida o de grado IV";
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------  
        System.out.println("Para un peso de " + peso + " kilogramos y una altura de "
                + altura + " metros:\n" + "El índice de masa corporal es de: " + imc);
        System.out.println(mensaje);

    }
}
