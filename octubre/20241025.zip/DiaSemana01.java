package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class DiaSemana01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int diaNumerico;
        
        // Variables de salida
        String diaSemana = "";
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("DÍA DE LA SEMANA"); 
        System.out.println ("----------------"); 

        System.out.println ("Introduzca día de la semana numérico (entero 1-7): ");
        diaNumerico = teclado.nextInt();

        
        // Procesamiento
        // -------------
        if ( diaNumerico < 1 || diaNumerico > 7 ){
            diaSemana = "error";
        } else if ( diaNumerico == 1 ) {
            diaSemana = "lunes";            
        } else if ( diaNumerico == 2 ) {
            diaSemana = "martes";            
        } else if ( diaNumerico == 3 ) {
            diaSemana = "miércoles";            
        } else if ( diaNumerico == 4 ) {
            diaSemana = "jueves";            
        } else if ( diaNumerico == 5 ) {
            diaSemana = "viernes";            
        } else if ( diaNumerico == 6 ) {
            diaSemana = "sábado";            
        } else {
            diaSemana = "domingo";            
        }
        
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El día de la semana es: " + diaSemana);
        
        
        
        
        
        
    }    

}
