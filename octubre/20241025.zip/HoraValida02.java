package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class HoraValida02 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int hora, minuto, segundo;
        
        // Variables de salida
        boolean horaValida;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("COMPROBACIÓN DE HORA VÁLIDA"); 
        System.out.println ("---------------------------"); 

        System.out.println ("Introduzca HORA (0-23): ");
        hora = teclado.nextInt();

        System.out.println ("Introduzca MINUTO (0-59): ");
        minuto = teclado.nextInt();
        
        System.out.println ("Introduzca SEGUNDO (0-59): ");
        segundo = teclado.nextInt();

        // Procesamiento
        // -------------
        horaValida = hora >=0 && hora <=23 && minuto >=0 && minuto <=59 && segundo >=0 && segundo <=59;
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("La hora es válida: " + horaValida);
       
        
        
        
        
        
        
    }    

}
