package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class CalificacionCualitativa03 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        // Variables de entrada
        double notaCuantitativa;  // Calificación cuantitativa

        // Variables de salida
        String notaCualitativa = ""; // Calificación cualitativa

        // Entrada de datos
        System.out.print("Introduzca una nota real cuantitativa (0-10): ");
        notaCuantitativa = teclado.nextDouble();

        // Procesamiento
        if (notaCuantitativa < 0.0 || notaCuantitativa > 10.0) { 
            notaCualitativa = "Calificación introducida no válida";
        }
        if (notaCuantitativa < 5) {
            notaCualitativa = "INSUFICIENTE";
        }
        if (notaCuantitativa >= 5 && notaCuantitativa < 6) {
            notaCualitativa = "SUFICIENTE";
        }
        if (notaCuantitativa >= 6 && notaCuantitativa < 7) {
            notaCualitativa = "BIEN";
        }
        if (notaCuantitativa >= 7 && notaCuantitativa < 9) {
            notaCualitativa = "NOTABLE";
        }
        if (notaCuantitativa >= 9 && notaCuantitativa <= 10) {
            notaCualitativa = "SOBRESALIENTE";
        }

        // Salida de resultados
        System.out.println("La calificación cualitativa es: " + notaCualitativa);

    }

}
