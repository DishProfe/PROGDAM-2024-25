package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class AnalisisNumero01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int numero;
        
        // Variables de salida
        boolean esPar;
        String signo;
        boolean mas3Cifras;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("ANÁLISIS DE UN NÚMERO"); 
        System.out.println ("---------------------------------"); 

        System.out.println ("Introduzca número entero: ");
        numero = teclado.nextInt();

        
        // Procesamiento
        // -------------
        // Calculamos si es par (si el resto de dividir entre 2 es cero)
        esPar = numero % 2 == 0;
        
        // Calculamos si es positivo, negativo o cero (signo)
        if ( numero < 0 ) {
            signo = "negativo";
        } else if ( numero > 0) {
            signo = "positivo";
        } else {
            signo = "cero";    
        }
        
        // Calculamos si tiene más de tres cifras        
        mas3Cifras = numero / 1000 > 0 ;
        
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El número es par: " + esPar);
        System.out.println ("El número es " + signo);
        System.out.println ("El número tiene más de tres cifras: " + mas3Cifras);
        
        
        
        
        
        
    }    

}
