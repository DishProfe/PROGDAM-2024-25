package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class NombreMasLargo02 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        String nombre1, nombre2;
        
        // Variables de salida
        String nombreMasLargo;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("CALCULAR EL NOMBRE MÁS LARGO"); 
        System.out.println ("----------------------------"); 

        System.out.println ("Introduzca primer nombre: ");
        nombre1 = teclado.nextLine();

        System.out.println ("Introduzca segundo nombre: ");
        nombre2 = teclado.nextLine();
        
        // Procesamiento
        // -------------
        nombreMasLargo = nombre1.length() > nombre2.length() ? nombre1 : nombre2 ;
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El nombre más largo es " + nombreMasLargo);
        
        
        
        
        
        
        
    }    

}
