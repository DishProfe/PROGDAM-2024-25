package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class DiaSemana04 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        String diaSemana;

        // Variables de salida
        String tipoDia;

        // Variables auxiliares
        // Entrada de datos
        // ----------------
        System.out.println("DÍA DE LA SEMANA");
        System.out.println("----------------");

        System.out.println("Introduzca día de la semana (texto): ");
        diaSemana = teclado.nextLine();

        // Procesamiento
        // -------------
        switch (diaSemana) {
            case "lunes":
            case "martes":
            case "miércoles":
            case "jueves":
            case "viernes":
                tipoDia = "día laborable";
                break;
            case "sábado":
            case "domingo":
                tipoDia = "fin de semana";
                break;
            default:
                tipoDia = "error";                
        }

        // Salida de resultados
        // --------------------
        System.out.println();

        System.out.println(
                "El día de la semana es: " + tipoDia);

    }

}
