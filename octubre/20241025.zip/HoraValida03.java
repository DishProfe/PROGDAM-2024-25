package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class HoraValida03 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int hora, minuto, segundo;
        
        // Variables de salida
        boolean horaValida;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("COMPROBACIÓN DE HORA VÁLIDA"); 
        System.out.println ("---------------------------"); 

        horaValida = true;
        System.out.println ("Introduzca HORA (0-23): ");
        hora = teclado.nextInt();
        if ( hora < 0 || hora > 23 ) {
            horaValida= false;
        } else {
            System.out.println ("Introduzca MINUTO (0-59): ");
            minuto = teclado.nextInt();      
            if ( minuto <0 || minuto > 59 ) { 
                horaValida= false;
            } else {
                System.out.println ("Introduzca SEGUNDO (0-59): ");
                segundo = teclado.nextInt();                
                if ( segundo <0 || segundo > 59 ) { 
                    horaValida= false;
                }
            }
        }
        
        
        
        

        // Procesamiento
        // -------------


        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("La hora es válida: " + horaValida);
       
        
        
        
        
        
        
    }    

}
