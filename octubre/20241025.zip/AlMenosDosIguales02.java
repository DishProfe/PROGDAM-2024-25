package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class AlMenosDosIguales02 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int numero1, numero2, numero3;
        
        // Variables de salida
        boolean hayAlMenos2Iguales;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("HAY AL MENOS DOS NÚMEROS IGUALES?"); 
        System.out.println ("---------------------------------"); 

        System.out.println ("Introduzca primer número: ");
        numero1 = teclado.nextInt();

        System.out.println ("Introduzca segundo número: ");
        numero2 = teclado.nextInt();

        System.out.println ("Introduzca tecer número: ");
        numero3 = teclado.nextInt();
        
        // Procesamiento
        // -------------
        hayAlMenos2Iguales = numero1 == numero2 || numero2 == numero3 || numero1 == numero3;
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ( (hayAlMenos2Iguales ? "Hay" : "No hay")    
                +  " al menos dos iguales.");
        
        
        
        
        
        
    }    

}
