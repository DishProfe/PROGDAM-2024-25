package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Contando01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada

        // Variables de salida

        // Variables auxiliares
        int numero;
        
        // Entrada de datos
        // ----------------
        System.out.println("CONTANDO NÚMEROS");
        System.out.println("----------------");

        // Procesamiento
        // -------------
        numero = 1;

        while (numero <= 5) {
            System.out.println(numero);
            numero++;
        }
        
        // Salida de resultados
        // --------------------
        System.out.println();

    }

}
