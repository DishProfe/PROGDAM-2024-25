
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class ObtenerCentenas01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int numero;
        
        // Variables de salida
        int centenas;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("OBTENER LAS CENTENAS DE UN NÚMERO ENTERO"); 
        System.out.println ("----------------------------------------"); 

        System.out.println ("Introduzca número entero: ");
        numero = teclado.nextInt();

        
        // Procesamiento
        // -------------
        
        centenas = numero / 100;
                
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("Las centenas son: " + centenas);
        
        
        
        
        
        
    }    
    
    
    
}
