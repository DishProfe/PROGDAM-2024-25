
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Capicua01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int numero;
        
        // Variables de salida
        int numeroCapicua;
        
        // Variables auxiliares
        int unidades, decenas;
        

        // Entrada de datos
        // ----------------
        System.out.println ("GENERAR LA CAPICÚA A PARTIR DE UN NÚMERO ENTERO DE DOS CIFRAS"); 
        System.out.println ("-------------------------------------------------------------"); 
        System.out.println ("Ejemplo: 23 -> 2332"); 

        System.out.println ("Introduzca número entero de dos cifras: ");
        numero = teclado.nextInt();

        
        // Procesamiento
        // -------------
        unidades = numero % 10;
        decenas  = numero /10;
        
        numeroCapicua = decenas*1000 + unidades*100 + unidades*10 + decenas;
        //numeroCapicua = numero*100+ + unidades*10 + decenas;
        
        
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El número al revés es: " + numeroCapicua);
        
        
        
        
        
        
    }    
    
    
    
}
