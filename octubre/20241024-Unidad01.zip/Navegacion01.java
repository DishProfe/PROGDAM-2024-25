
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Navegacion01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int rumboInicial;
        int viraje;
        
        // Variables de salida
        int rumboFinal;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("AÑADIR VIRAJE A UN RUMBO INICIAL"); 
        System.out.println ("--------------------------------"); 
        System.out.println ("Ejemplo: rumbo 270 (W) + viraje 135 -> 45 (NE)"); 

        System.out.println ("Introduzca rumbo inicial (entero): ");
        rumboInicial = teclado.nextInt();

        System.out.println ("Introduzca viraje (entero): ");
        viraje = teclado.nextInt();
        
        // Procesamiento
        // -------------
        rumboFinal = ( rumboInicial + viraje ) % 360;

        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El rumbo final es: " + rumboFinal);
        
        
        
        
        
        
    }    
    
    
    
}
