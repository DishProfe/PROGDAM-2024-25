
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class CambiarCifras01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int numero;
        
        // Variables de salida
        int numeroAlReves;
        
        // Variables auxiliares
        int unidades, decenas;
        

        // Entrada de datos
        // ----------------
        System.out.println ("CONMUTAR LAS CIFRAS DE UN NÚMERO ENTERO DE DOS CIFRAS"); 
        System.out.println ("-----------------------------------------------------"); 
        System.out.println ("Ejemplo: 23 -> 32"); 

        System.out.println ("Introduzca número entero de dos cifras: ");
        numero = teclado.nextInt();

        
        // Procesamiento
        // -------------
        unidades = numero % 10;
        decenas  = numero /10;
        
        numeroAlReves = 10*unidades + decenas;
                
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El número al revés es: " + numeroAlReves);
        
        
        
        
        
        
    }    
    
    
    
}
