
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class ObtenerUnidades01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int numero;
        
        // Variables de salida
        int unidades;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("OBTENER LAS UNIDADES DE UN NÚMERO ENTERO"); 
        System.out.println ("----------------------------------------"); 

        System.out.println ("Introduzca número entero: ");
        numero = teclado.nextInt();

        
        // Procesamiento
        // -------------
        
        unidades = numero % 10;
                
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("Las unidades son: " + unidades);
        
        
        
        
        
        
    }    
    
    
    
}
