
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class SaqueTenis01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int puntos1 ,puntos2;       
        
        // Variables de salida
        String saque = "";
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("SAQUE DE TENIS"); 
        System.out.println ("--------------"); 

        System.out.println ("Introduzca puntuación del jugador 1 (0-3): ");
        puntos1 = teclado.nextInt();

        System.out.println ("Introduzca puntuación del jugador 2 (0-3): ");
        puntos2 = teclado.nextInt();
        
        // Procesamiento
        // -------------
        

        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El saque será a la: " + saque);
        
        
        
        
        
        
    }    
    
    
    
}
