/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/ProgramaJava.java to edit this template
 */
package ejemplos2024;

import java.util.Scanner;

/**
 * Programa
 */
public class EjemploConversion01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        // Variables de salida
        // Variables auxiliares
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE CONVERSIÓN");
        System.out.println("----------------------");
        System.out.println(" ");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        int a;
        byte b;
        
        float real1 = 1.17f;
        double real2 = 22.56;
        double real3 = 2f;
        float real4 =  1000_000_000_000L;

        
        a = 12;
        b = 12;
        
        b = (byte) a;

        a = (int) real2;
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.println("a= " + a );
        System.out.println("b= " + b );
        
        
        System.out.println();
        System.out.println("Fin del programa.");

    }

}
