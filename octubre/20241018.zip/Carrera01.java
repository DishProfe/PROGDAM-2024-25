
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Carrera01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int hora1, min1, seg1;
        int hora2, min2, seg2;
        
        // Variables de salida
        int difHora, difMin, difSeg;
        
        // Variables auxiliares
        int totalSeg1,totalSeg2;
        int difTotalSeg;
        int resto;
        

        // Entrada de datos
        // ----------------
        System.out.println ("DIFERENCIA ENTRE DOS TIEMPOS EN UNA CARRERA"); 
        System.out.println ("-------------------------------------------"); 

        System.out.println ("Introduzca tiempo del primer corredor (hh mm ss): ");
        hora1 = teclado.nextInt();
        min1  = teclado.nextInt();
        seg1  = teclado.nextInt();

        System.out.println ("Introduzca tiempo del segundo corredor (hh mm ss): ");
        hora2 = teclado.nextInt();
        min2  = teclado.nextInt();
        seg2  = teclado.nextInt();

        
        // Procesamiento
        // -------------
        
        // Calculamos segundos totales en el día para tiempo 1
        totalSeg1 = hora1*3600 + min1*60 + seg1;

        // Calculamos segundos totales en el día para tiempo 2
        totalSeg2 = hora2*3600 + min2*60 + seg2;

        // Calculamos la diferencia entre tiempo 2 y tiempo 1
        difTotalSeg = totalSeg2 - totalSeg1;
        
        // Calculamos cuántas horas hay en esa diferencia
        difHora = difTotalSeg / 3600;

        // Calculamos cuántos segundos quedarían tras quitar las horas (grupos de 3600 segundos)
        resto = difTotalSeg % 3600;
 
        // Calculamos cuántos minutos quedan en el resto 
        difMin = resto / 60;

        // Calculamos cuántos segundos quedarían tras quitar los minutos (grupos de 60 segundos)
        resto = resto %60;

        // Calculamos cuántos segundos quedarían tras quitar los minutos (grupos de 60 segundos)
        difSeg = resto;
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("La diferencia de tiempos es: ");
        System.out.println ( difHora + ":" + difMin + ":" + difSeg);
        
        
        
        
        
        
    }    
    
    
    
}
