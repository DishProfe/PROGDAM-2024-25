
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class SaqueTenis02 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int puntos1 ,puntos2;       
        
        // Variables de salida
        String saque;
        
        // Variables auxiliares
        int sumaPuntos;
        

        // Entrada de datos
        // ----------------
        System.out.println ("SAQUE DE TENIS"); 
        System.out.println ("--------------"); 

        System.out.println ("Introduzca puntuación del jugador 1 (0-3): ");
        puntos1 = teclado.nextInt();

        System.out.println ("Introduzca puntuación del jugador 2 (0-3): ");
        puntos2 = teclado.nextInt();
        
        // Procesamiento
        // -------------
        
        // Adptamos el sistema de puntos a 0, 1, 2, 3
        int p1= puntos1 < 40 ? puntos1 / 15 : 3 ; 
        int p2= puntos2 < 40 ? puntos2 / 15 : 3 ; 
        
        // Sumamos los puntos
        sumaPuntos = p1  + p2;
        
        // Si la suma es par el saque será a la derecha. Si no, a la izquierda
        saque = sumaPuntos % 2 == 0 ? "Derecha" : "Izquierda";


        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El saque será a la: " + saque);
        
        
        
        
        
        
    }    
    
    
    
}
