
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class SiguienteDia01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int year, mes, dia;       
        
        // Variables de salida
        int newYear, newMes, newDia;
        
        // Variables auxiliares
        int incDia=1, incMes, incYear;
        

        // Entrada de datos
        // ----------------
        System.out.println ("DÍA SIGUIENTE A UNA FECHA"); 
        System.out.println ("--------------------------"); 

        System.out.println ("Introduzca FECHA en formato dia mes año: ");
        System.out.println ("(supone los días de 0 a 29 y los meses de 0 a 11)");
        dia = teclado.nextInt();
        mes = teclado.nextInt();
        year = teclado.nextInt();

        
        // Procesamiento
        // -------------
        
        // Sumamos el incremento en días a los días actuales y nos quedamos con el resto de dividir entre 30
        newDia = (dia + incDia) % 30;

        // Incremento en meses: cuántas veces hemos superado 30 días
        incMes = (dia + incDia) / 30;
        // Sumamos el incremento en mes a los meses actuales y nos quedamos con el resto de dividir entre 12
        newMes = (mes + incMes) % 12;

        // Incremento en años: cuántas veces hemos superado 12 meses
        incYear = (mes + incMes) / 12;
        // Sumamos el incremento en años a los años actuales 
        newYear = (year + incYear ) ;

        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("La nueva fecha es: ");
        System.out.println ( newDia + "/" + newMes +  "/" + newYear);
        
        
        
        
        
        
    }    
    
    
    
}
