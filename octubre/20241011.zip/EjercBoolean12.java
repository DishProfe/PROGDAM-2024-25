
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercBoolean12 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int hora, minuto, segundo;
        
        // Variables de salida
        boolean resultado;
        
        // Variables auxiliares
        boolean horaValida, minutoValido, segundoValido;
        

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS BOOLEAN"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca horas, minutos y segundos: ");
        System.out.print ("hh =  ");
        hora = teclado.nextInt();
        System.out.print ("mm =  ");
        minuto = teclado.nextInt();
        System.out.print ("ss =  ");
        segundo = teclado.nextInt();

        
        // Procesamiento
        // -------------
        horaValida = hora >= 1 && hora <=12  ;  
        minutoValido = minuto >=0 && minuto <=59;
        segundoValido = segundo >=0 && segundo <=59;
        resultado = horaValida && minutoValido && segundoValido;
        //resultado = hora >= 1 && hora <=12 && minuto >=0 && minuto <=59 && segundo >=0 && segundo <=59;
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("La hora es válida para formato 12h: " + resultado);
        
        
        
        
        
        
        
    }    
    
    
    
}
