
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercCadenas03 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        String matricula, apellido1, apellido2;
        
        // Variables de salida
        String matriculaConGuiones;
        
        // Variables auxiliares
        int longitud2;

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS CADENAS"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca matrícula española (4 dígitos + 3 letras: ");
        matricula = teclado.nextLine();

        
        // Procesamiento
        // -------------
        matriculaConGuiones = matricula.charAt(0) + "-" + 
                matricula.charAt(1) + "-" + 
                matricula.charAt(2) + "-" + 
                matricula.charAt(3) + "-" + 
                matricula.charAt(4) + "-" + 
                matricula.charAt(5) + "-" + 
                matricula.charAt(6)  ; 
                
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println (matriculaConGuiones);
        
        
        
        
        
        
        
    }    
    
    
    
}
