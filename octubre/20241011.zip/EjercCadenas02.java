
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercCadenas02 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        String nombre, apellido1, apellido2;
        
        // Variables de salida
        String textoFinal;
        
        // Variables auxiliares
        int longitud2;

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS CADENAS"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca nombre, apellido1 y apellido2: ");
        System.out.print ("nombre:  ");
        nombre = teclado.nextLine();
        System.out.print ("apellido1:  ");
        apellido1 = teclado.nextLine();
        System.out.print ("apellido1:  ");
        apellido2 = teclado.nextLine();

        
        // Procesamiento
        // -------------
        longitud2 = apellido2.length();
        textoFinal = "D./Dña. " + nombre + " con primer apellido " +  apellido1 + 
                " \nha sido seleccionado por tener como segundo apellido " + apellido2 + 
                ", que tiene " + longitud2 + " letras.";
                
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println (textoFinal);
        
        
        
        
        
        
        
    }    
    
    
    
}
