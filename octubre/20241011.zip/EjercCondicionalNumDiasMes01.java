
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercCondicionalNumDiasMes01 {
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int mes;
        
        // Variables de salida
        int numDias;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS CONDICIONAL"); 
        System.out.println ("----------------------"); 

        System.out.println ("Introduzca mes (1-12): ");
        System.out.print ("Mes =  ");
        mes = teclado.nextInt();

        
        // Procesamiento
        // -------------
        numDias = mes==2 || mes==4 || mes==6 || mes==9 || mes==11 ? 30 : 31;
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El número de días de ese mes es: " + numDias);
        
        
        
        
        
        
        
    }    
    
    
    
}
