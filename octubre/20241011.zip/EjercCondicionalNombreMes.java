
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercCondicionalNombreMes {
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int mes;
        
        // Variables de salida
        String nombreMes;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS CONDICIONAL"); 
        System.out.println ("----------------------"); 

        System.out.println ("Introduzca mes (1-12): ");
        System.out.print ("Mes =  ");
        mes = teclado.nextInt();

        
        // Procesamiento
        // -------------
        nombreMes = mes==1  ?  "enero" : ( mes==2 ? "febrero" : ( mes==3 ? "marzo" : "otro")  );
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El nombre del mes es: " + nombreMes);
        
        
        
        
        
        
        
    }    
    
    
    
}
