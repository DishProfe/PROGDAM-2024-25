
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercBoolean13 {
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int year, mes, dia;
        
        // Variables de salida
        boolean resultado;
        
        // Variables auxiliares
        boolean yearValido, mesValido, diaValido;
        

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS BOOLEAN"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca año, mes y día: ");
        System.out.print ("Año =  ");
        year = teclado.nextInt();
        System.out.print ("Mes =  ");
        mes = teclado.nextInt();
        System.out.print ("Día =  ");
        dia = teclado.nextInt();

        
        // Procesamiento
        // -------------
        yearValido = year >= 1700 && year <=2100  ;  
        mesValido = mes >=1 && mes <=12;
        diaValido = dia>=1 && dia<=31 && 
                  ( (mes==2 && dia<=28) ||
                  ( (mes==4 || mes==6 || mes==9 || mes==11 ) && dia<=30)
                );

//        diaValido = dia>=1 && dia<=31 && 
//                  ( (mes==2 && dia<=28) ||
//                  ( (mes==4 || mes==6 || mes==9 || mes==11 ) && dia<=30) ||
//                  ( (mes==1 || mes==3 || mes==5 || mes==7 || mes==8 || mes==10 || mes==12) && dia<=31)
//                );

//        diaValido = (mes==2  && dia >=1 && dia<=28) ||
//                    (mes==4  && dia >=1 && dia<=30) ||
//                    (mes==6  && dia >=1 && dia<=30) ||
//                    (mes==9  && dia >=1 && dia<=30) ||
//                    (mes==11 && dia >=1 && dia<=30) ||
//                    (mes==1  && dia >=1 && dia<=31) ||
//                    (mes==3  && dia >=1 && dia<=31) ||
//                    (mes==5  && dia >=1 && dia<=31) ||
//                    (mes==7  && dia >=1 && dia<=31) ||
//                    (mes==8  && dia >=1 && dia<=31) ||
//                    (mes==10 && dia >=1 && dia<=31) ||
//                    (mes==12 && dia >=1 && dia<=31) ;





        resultado = yearValido && mesValido && diaValido;
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("La fecha es válida: " + resultado);
        
        
        
        
        
        
        
    }    
    
    
    
}
