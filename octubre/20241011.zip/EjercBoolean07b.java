
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercBoolean07b {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        char caracter;
        
        // Variables de salida
        boolean resultado;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS BOOLEAN"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca un caracter: ");
        System.out.print ("c =  ");
        caracter = teclado.nextLine().charAt(0);

        
        // Procesamiento
        // -------------
        resultado  = Character.isUpperCase(caracter) ;  
        
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("Es una letra mayúscula: " + resultado);
        
        
        
        
        
        
        
    }    
    
    
    
}
