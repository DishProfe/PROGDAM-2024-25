
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercCondicional01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int n1, n2, n3;
        
        // Variables de salida
        String resultado;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS OPERADOR CONDICIONAL"); 
        System.out.println ("-------------------------------"); 

        System.out.println ("Introduzca tres números enteros: ");
        System.out.print ("n1 =  ");
        n1 = teclado.nextInt();
        System.out.print ("n2 =  ");
        n2 = teclado.nextInt();
        System.out.print ("n3 =  ");
        n3 = teclado.nextInt();

        
        // Procesamiento
        // -------------
        resultado = n1==n2 && n2==n3 ? "Los tres números son iguales" : "Los tres números no son iguales";
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println (resultado);
        
        
        
        
        
        
        
    }    
    
    
    
}
