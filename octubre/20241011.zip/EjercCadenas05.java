
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercCadenas05 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        String matricula;
        
        // Variables de salida
        String numerosMatricula;
        String letrasMatricula;
        
        // Variables auxiliares

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS CADENAS"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca matrícula española (4 dígitos + 3 letras: ");
        matricula = teclado.nextLine();

        
        // Procesamiento
        // -------------
        numerosMatricula = 
                matricula.charAt(0) + "." + 
                matricula.charAt(1) + "." + 
                matricula.charAt(2) + "." + 
                matricula.charAt(3) ; 

                
        letrasMatricula = 
                matricula.charAt(4) + "-" + 
                matricula.charAt(5) + "-" + 
                matricula.charAt(6) ;
                
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("Números: " + numerosMatricula);
        System.out.println ("Letras: "  + letrasMatricula);
        
        
        
        
        
        
        
    }    
    
    
    
}
