
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercBoolean07 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        String linea;
        char caracter;
        
        // Variables de salida
        boolean resultado;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS BOOLEAN"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca un caracter: ");
        System.out.print ("c =  ");
        linea = teclado.nextLine();
        caracter = linea.charAt(0);

        
        // Procesamiento
        // -------------
        resultado = caracter >= 'A'  && caracter <= 'Z' ;  
        
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("Es una letra mayúscula: " + resultado);
        
        
        
        
        
        
        
    }    
    
    
    
}
