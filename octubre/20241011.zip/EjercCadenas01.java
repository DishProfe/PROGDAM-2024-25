
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercCadenas01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        String nombre, apellido1, apellido2;
        
        // Variables de salida
        String textoFinal;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS CADENAS"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca nombre, apellido1 y apellido2: ");
        System.out.print ("nombre:  ");
        nombre = teclado.nextLine();
        System.out.print ("apellido1:  ");
        apellido1 = teclado.nextLine();
        System.out.print ("apellido1:  ");
        apellido2 = teclado.nextLine();

        
        // Procesamiento
        // -------------
        textoFinal = "Bienvenido Sr./Sra. " + apellido1 + " " + apellido2 + ", " + nombre;
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println (textoFinal);
        
        
        
        
        
        
        
    }    
    
    
    
}
