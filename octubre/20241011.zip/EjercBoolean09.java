
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercBoolean09 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        char caracter;
        
        // Variables de salida
        boolean resultado;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS BOOLEAN"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca un caracter: ");
        System.out.print ("c =  ");
        caracter = teclado.nextLine().charAt(0);

        
        // Procesamiento
        // -------------
        resultado =  caracter >= 'a'  && caracter <= 'z'  ||  caracter >= 'A'  && caracter <= 'Z' ;  
        
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("Es una letra: " + resultado);
        
        
        
        
        
        
        
    }    
    
    
    
}
