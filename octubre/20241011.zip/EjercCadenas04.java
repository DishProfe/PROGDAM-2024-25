
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class EjercCadenas04 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        String matricula;
        
        // Variables de salida
        String matriculaConMarco;
        
        // Variables auxiliares

        // Entrada de datos
        // ----------------
        System.out.println ("EJERCICIOS CADENAS"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca matrícula española (4 dígitos + 3 letras: ");
        matricula = teclado.nextLine();

        
        // Procesamiento
        // -------------
        matriculaConMarco = 
                "+---------+\n" + 
                "| " + matricula + " |\n" +
                "+---------+";
                
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println (matriculaConMarco);
        
        
        
        
        
        
        
    }    
    
    
    
}
