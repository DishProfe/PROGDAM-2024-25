package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class ContarMultiplos01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int inicio, fin;

        // Variables de salida
        int cantidadMultiplos3;
        int sumaMultiplos3;

        // Variables auxiliares
        int contador;
        
        // Entrada de datos  
        // -----------------
        System.out.println("CALCULANDO MÚLTIPLOS DE 3");
        System.out.println("-------------------------");

        System.out.println ("Introduzca inicio y fin");
        inicio = teclado.nextInt();
        fin = teclado.nextInt();
        
        // Procesamiento
        // -------------
        // Inicialización
        cantidadMultiplos3 = 0;
        sumaMultiplos3 = 0;
        contador = inicio;
        
        while ( contador <= fin ) {
            if ( contador % 3 ==0 ) {
                cantidadMultiplos3++;
                sumaMultiplos3 += contador;
            }
            contador++;
        }
        
        
        
        // Salida de resultados
        // --------------------
        System.out.println ("Cantidad de múltiplos de 3: " + cantidadMultiplos3);
        System.out.println ("Suma de múltiplos de 3: " + sumaMultiplos3);
        System.out.println();

    }

}
