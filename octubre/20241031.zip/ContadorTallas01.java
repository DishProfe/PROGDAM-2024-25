package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class ContadorTallas01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        String talla;

        // Variables de salida
        int totalPeticiones;
        int totalPrendas;
        int cantidadS, cantidadXS, cantidadM, cantidadL,
                cantidadXL, cantidadXXL;

        // Variables auxiliares
        int numErrores;

        // Entrada de datos + Procesamiento
        // --------------------------------
        System.out.println("CONTANDO PRENDAS");
        System.out.println("----------------");

        // Inicialización
        totalPeticiones = 0;
        totalPrendas = 0;
        cantidadXS = 0;
        cantidadS = 0;
        cantidadM = 0;
        cantidadL = 0;
        cantidadXL = 0;
        cantidadXXL = 0;
        numErrores = 0;

        boolean fin = false;
        do {
            System.out.println("Introduzca talla de la prenda (XS, S, M, L, XL, XXL)");
            System.out.println("Introduzca FIN para terminar.");
            talla = teclado.nextLine();

            boolean error = false;
            switch (talla.toUpperCase()) {
                case "XS":
                    cantidadXS++;
                    break;
                case "S":
                    cantidadS++;
                    break;
                case "M":
                    cantidadM++;
                    break;
                case "L":
                    cantidadL++;
                    break;
                case "XL":
                    cantidadXL++;
                    break;
                case "XXL":
                    cantidadXXL++;
                    break;
                case "FIN":
                    fin = true;
                    break;
                default:
                    error = true;
            }

            if (!fin) {
                totalPeticiones++;
            }

            if (error) {
                System.out.println("Talla errónea. No se tendrá en cuenta.");
                numErrores++;
            } else if (!fin) {
                System.out.println("Solicitada talla " + talla.toUpperCase());
            }

            /*
            if ( talla.equals("XS"))  {
                cantidadXS++;
            } else if ( talla.equals("S") ) {
                cantidadS++;
            } else if ( talla.equals("M") ) {
                cantidadM++;
            } else if ( talla.equals("L") ) {
                cantidadL++;
            } else if ( talla.equals("XL") ) {
                cantidadXL++;
            } else if ( talla.equals("XXL") ) {
                cantidadXXL++;
            } else {
                numErrores++;
            }
             */
            System.out.println();

        } while (!fin);

        //totalPrendas = cantidadXS + cantidadS + cantidadM + cantidadL + cantidadXL + cantidadXXL; 
        totalPrendas = totalPeticiones - numErrores;

        // Salida de resultados
        // --------------------
        System.out.println();
        System.out.println("Cantidad de peticiones total (incluyendo las erróneas): " + totalPeticiones);
        System.out.println("Cantidad de prendas total (solo prendas válidas): " + totalPrendas);
        System.out.println("Cantidad de prendas XS : " + cantidadXS);
        System.out.println("Cantidad de prendas S  : " + cantidadS);
        System.out.println("Cantidad de prendas M  : " + cantidadM);
        System.out.println("Cantidad de prendas L  : " + cantidadL);
        System.out.println("Cantidad de prendas XL : " + cantidadXL);
        System.out.println("Cantidad de prendas XXL: " + cantidadXXL);

    }

}
