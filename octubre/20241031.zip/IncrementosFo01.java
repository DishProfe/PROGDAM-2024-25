package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class IncrementosFo01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int inicio, fin, incremento;

        // Variables de salida
        int suma, producto;
        double media;

        // Variables auxiliares
        int contador;
        int numElementos;

        // Entrada de datos  
        // -----------------
        System.out.println("INCREMENTOS DENTRO DE UN RANGO");
        System.out.println("------------------------------");

        System.out.println("Introduzca inicio y fin");
        inicio = teclado.nextInt();
        fin = teclado.nextInt();

        System.out.println("Introduzca incremento");
        incremento = teclado.nextInt();

        // Procesamiento + Salida de resultados
        // ------------------------------------
        contador = inicio;
        suma = 0;
        producto = 1;
        numElementos = 0;
        do {

            System.out.println(contador);
            suma += contador;
            producto *= contador;
            contador += incremento;
            numElementos++;

        } while (contador <= fin);

        
        media = (double)suma / numElementos;

        System.out.println("Suma: " + suma);
        System.out.println("Producto: " + producto);
        System.out.println("Media: " + media);

    }

}
