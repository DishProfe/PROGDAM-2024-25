package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class TablaMultiplicarFor01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numero;

        // Variables de salida

        // Variables auxiliares
        int contador;
        int producto;
        
        // Entrada de datos 
        // ----------------
        System.out.println("TABLA DE MULTIPLICAR");
        System.out.println("--------------------");


        do { 
           System.out.println ("Introduzca número (1-10):");
           numero = teclado.nextInt();
        } while ( numero<1 || numero>10  );
        
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   
        System.out.println ("Tabla del " + numero);

        contador = 1;
        while ( contador<10 ) {
           producto = numero * contador;
           System.out.println (numero + "*" + contador + "= " + producto);
           contador++;
        }

        System.out.println();

    }

}
