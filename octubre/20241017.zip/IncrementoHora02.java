
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class IncrementoHora02 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int hora, min, seg;       
        int incSeg, incMin;
        
        // Variables de salida
        int newHora, newMin, newSeg;
        
        // Variables auxiliares
        int acarreoMin, acarreoHora;
        

        // Entrada de datos
        // ----------------
        System.out.println ("INCREMENTO DE UNA HORA"); 
        System.out.println ("-----------------------"); 

        System.out.println ("Introduzca hora en formato hh mm ss: ");
        hora = teclado.nextInt();
        min = teclado.nextInt();
        seg = teclado.nextInt();

        System.out.println ("Introduzca el incremento en minutos: ");
        incMin = teclado.nextInt();

        System.out.println ("Introduzca el incremento en segundos: ");
        incSeg = teclado.nextInt();
        
        // Procesamiento
        // -------------
        
        // Sumamos el incremento en segundos a los segundos actuales y nos quedamos con el resto de dividir entre 60
        newSeg = (seg + incSeg) % 60;

        // Incremento en minutos: cuántas veces hemos superado 60 segundos + el incremento en minutos introducido desde teclado 
        acarreoMin = (seg + incSeg) / 60 + incMin;
        // Sumamos el incremento en minutos a los minutos actuales y nos quedamos con el resto de dividir entre 60
        newMin = (min + acarreoMin) % 60;

        // Incremento en horas: cuántas veces hemos superado 60 minutos
        acarreoHora = (min + acarreoMin) / 60;
        // Sumamos el incremento en horas a las horas actuales y nos quedamos con el resto de dividir entre 24
        newHora = (hora + acarreoHora ) % 24;

        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("La nueva hora es: ");
        System.out.println ( newHora + ":" + newMin + ":" + newSeg );
        
        
        
        
        
        
    }    
    
    
    
}
