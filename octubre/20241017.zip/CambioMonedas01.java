
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class CambioMonedas01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        double dinero;
        
        // Variables de salida
        int m01c, m02c, m05c, m10c;
        int m20c, m50c;
        int m1e, m2e;
        
        // Variables auxiliares
        int centimos;
        int resto;
        

        // Entrada de datos
        // ----------------
        System.out.println ("CÁLCULO DE CAMBIO EN MONEDAS"); 
        System.out.println ("----------------------------"); 

        System.out.println ("Introduzca la cantidad de euros a cambiar: (hasta dos decimales) ");
        dinero = teclado.nextDouble();
        
        // Procesamiento
        // -------------
        
        // Calculamos la cantidad de céntimos
        centimos = (int) (dinero * 100);

        // Calculamos la cantidad de monedas de 2 euros
        m2e = centimos / 200 ;
        
        // Calculamos la cantidad de céntimos que quedan tras quitar los grupos de 2 euros
        resto = centimos % 200;
        
        // Calculamos la cantidad de monedas de 1 euro
        m1e = resto / 100 ;
        
        // Calculamos la cantidad de céntimos que quedan tras quitar los grupos de 1 euro
        resto = resto % 100;
        
        // Calculamos la cantidad de monedas de 50c
        m50c = resto / 50 ;
        
        // Calculamos la cantidad de céntimos que quedan tras quitar los grupos de 50c
        resto = resto % 50;
        
        // Calculamos la cantidad de monedas de 20c
        m20c = resto / 20 ;
        
        // Calculamos la cantidad de céntimos que quedan tras quitar los grupos de 20c
        resto = resto % 20;
        
        // Calculamos la cantidad de monedas de 10c
        m10c = resto / 10 ;
        
        // Calculamos la cantidad de céntimos que quedan tras quitar los grupos de 10c
        resto = resto % 10;
        
        // Calculamos la cantidad de monedas de 5c
        m05c = resto / 5 ;
        
        // Calculamos la cantidad de céntimos que quedan tras quitar los grupos de 5c
        resto = resto % 5;
        
        // Calculamos la cantidad de monedas de 2c
        m02c = resto / 2 ;
        
        // Calculamos la cantidad de céntimos que quedan tras quitar los grupos de 2c
        m01c = resto % 2;


        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("El cambio es: ");
        System.out.println ("Monedas de  2 euros:    "  + m2e);
        System.out.println ("Monedas de  1 euro:     "  + m1e);
        System.out.println ("Monedas de 50 céntimos: "  + m50c);
        System.out.println ("Monedas de 20 céntimos: "  + m20c);
        System.out.println ("Monedas de 10 centimos: "  + m10c);
        System.out.println ("Monedas de  5 céntimos: "  + m05c);
        System.out.println ("Monedas de  2 céntimos: "  + m02c);
        System.out.println ("Monedas de  1 céntimo:  "  + m01c);
        
        
        
        
        
        
    }    
    
    
    
}
