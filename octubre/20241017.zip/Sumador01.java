
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Sumador01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        int u1, d1, c1;
        int u2, d2, c2;
        int u3, d3, c3;       
        
        // Variables de salida
        int uSuma, dSuma, cSuma, umSuma;
        
        // Variables auxiliares
        int dAcarreo, cAcarreo, umAcarreo;
        

        // Entrada de datos
        // ----------------
        System.out.println ("SUMADOR"); 
        System.out.println ("-------"); 

        System.out.println ("Introduzca primer número en tres cifras (c d u): ");
        c1 = teclado.nextInt();
        d1 = teclado.nextInt();
        u1 = teclado.nextInt();

        System.out.println ("Introduzca segundo número en tres cifras (c d u): ");
        c2 = teclado.nextInt();
        d2 = teclado.nextInt();
        u2 = teclado.nextInt();

        System.out.println ("Introduzca tercer número en tres cifras (c d u): ");
        c3 = teclado.nextInt();
        d3 = teclado.nextInt();
        u3 = teclado.nextInt();
        
        // Procesamiento
        // -------------
        
        // Sumamos las unidades y nos quedamos solamente con la última cifra  (unidades)
        uSuma = ( u1 + u2 + u3 ) % 10;

        // Calculamos el posible "me llevo" o "acarreo" de sumar las unidades
        dAcarreo = ( u1 + u2 + u3 ) / 10;
        // Sumamos las decenas junto con el posible acarreo y nos quedamos con la última cifra (unidades)
        dSuma = ( d1 + d2 + d3 + dAcarreo ) % 10;
        
        // Calculamos el posible "me llevo" o "acarreo" de sumar las decenas
        cAcarreo = ( d1 + d2 + d3 + dAcarreo ) / 10 ; 
        // Sumamos las centenas junto con el posible acarreo y nos quedamos con la última cifra (unidades)
        cSuma = ( c1 + c2 + c3 + cAcarreo ) % 10 ;

        // Calculamos el posible "me llevo" o "acarreo" de sumar las centenas        
        umAcarreo = ( c1 + c2 + c3 + cAcarreo ) / 10 ;
        // Las unidades de millar serán el posible acarreo de las centenas
        umSuma = umAcarreo;
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("La suma es: ");
        System.out.println ( umSuma + " " + cSuma + " " + dSuma + " " + uSuma);
        
        
        
        
        
        
    }    
    
    
    
}
