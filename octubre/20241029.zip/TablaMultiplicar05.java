package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class TablaMultiplicar05 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numero;

        // Variables de salida

        // Variables auxiliares
        int contador;
        int producto;
        boolean numeroValido;
        int numIntentos;
        
        // Entrada de datos 
        // ----------------
        System.out.println("TABLA DE MULTIPLICAR");
        System.out.println("--------------------");

        numIntentos = 0;
        do { 
           System.out.println ("Introduzca número (1-10):");
           numero = teclado.nextInt();
           numeroValido = numero>=1 && numero<=10;
           if ( !numeroValido ) {
               if ( numIntentos < 3) {  
                   System.out.println ("El número no está en el rango. Introdúzcalo de nuevo.");
               } else if ( numIntentos < 5 ) {
                   System.out.println ("Número incorrecto. Por favor lea con atención las instrucciones de entrada.");                                      
               } else {
                   System.out.println ("Espabile, que el número no está en el rango y ya se ha equivocado varias veces."
                           + " \nIntrodúzcalo de nuevo.");                   
               }
               numIntentos++;
           }
           
        } while ( !numeroValido );
        
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   
        System.out.println ("Tabla del " + numero);

        contador = 1;
        do {
           producto = numero * contador;
           System.out.println (numero + "*" + contador + "= " + producto);
           contador++;
        } while ( contador<10 );

        System.out.println();

    }

}
