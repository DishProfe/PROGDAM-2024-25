package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class ContandoNumeros01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numero;

        // Variables de salida
        int cantidadNumeros;
        int suma;

        // Variables auxiliares
        boolean esNegativo;
        
        // Entrada de datos + Procesamiento
        // --------------------------------
        System.out.println("CONTANDO Y SUMANDO NÚMEROS");
        System.out.println("--------------------------");

        System.out.println ("Introduzca números enteros no negativos");
        System.out.println ("(para terminar introduzca número < 0)");
        
        // Inicialización
        cantidadNumeros = 0;
        suma = 0;
        
        do {            
            System.out.println ("Introduzca número: ");
            numero = teclado.nextInt();

            esNegativo = numero < 0;
            if ( ! esNegativo ) {
                cantidadNumeros++;
                suma += numero;
            }
        }while ( ! esNegativo );
        
        
        // Salida de resultados
        // --------------------
        System.out.println ("Cantidad de números: " + cantidadNumeros);
        System.out.println ("Suma: " + suma );
        System.out.println();

    }

}
