package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class TablaMultiplicar03 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numero;

        // Variables de salida

        // Variables auxiliares
        int contador;
        int producto;
        boolean numeroValido;
        
        // Entrada de datos 
        // ----------------
        System.out.println("TABLA DE MULTIPLICAR");
        System.out.println("--------------------");


        do { 
           System.out.println ("Introduzca número (1-10):");
           numero = teclado.nextInt();
           numeroValido = numero>=1 && numero<=10;
           if ( !numeroValido ) {
               System.out.println ("El número no está en el rango. Introdúzcalo de nuevo");
           }
           
        } while ( !numeroValido );
        
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   
        System.out.println ("Tabla del " + numero);

        contador = 1;
        do {
           producto = numero * contador;
           System.out.println (numero + "*" + contador + "= " + producto);
           contador++;
        } while ( contador<10 );

        System.out.println();

    }

}
