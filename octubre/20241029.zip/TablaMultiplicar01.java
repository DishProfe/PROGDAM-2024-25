package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class TablaMultiplicar01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numero;

        // Variables de salida

        // Variables auxiliares
        int contador;
        int producto;
        
        // Entrada de datos 
        // ----------------
        System.out.println("TABLA DE MULTIPLICAR");
        System.out.println("--------------------");

        System.out.println ("Introduzca número (1-10):");
        numero = teclado.nextInt();
        
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   
        System.out.println ("Tabla del " + numero);

        contador = 1;
        do {
           producto = numero * contador;
           System.out.println (numero + "*" + contador + "= " + producto);
           contador++;
        } while ( contador<10 );

        System.out.println();

    }

}
