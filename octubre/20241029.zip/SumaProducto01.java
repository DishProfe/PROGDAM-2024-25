package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class SumaProducto01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numero;

        // Variables de salida
        int suma;
        int producto;

        // Variables auxiliares
        int contador;
        boolean numeroValido;
       
        // Entrada de datos 
        // ----------------
        System.out.println("SUMATORIO Y FACTORIAL");
        System.out.println("---------------------");

        do { 
           System.out.println ("Introduzca número positivo:");
           numero = teclado.nextInt();
           numeroValido = numero>0;
        } while ( !numeroValido );
        
        
        // Procesamiento 
        // --------------
        // Inicializar
        contador=1;
        suma = 0;
        producto = 1;

        while ( contador <= numero ) {
            suma += contador;
            producto *= contador;
            contador++;
        }

        // Salida de resultados
        // --------------------
        System.out.println ("Suma: " + suma);
        System.out.println ("Producto: " + producto);
        

    }

}
