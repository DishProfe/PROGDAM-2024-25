
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Salario02 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        final double PORCENTAJE_IRPF = 18.0;
        
        // Variables de entrada
        double salarioBrutoDiario, precioHoraExtra;
        int horasExtra, diasTrabajados;
        
        // Variables de salida
        double salarioFinal;
        
        // Variables auxiliares
        double salarioDiasTrabajados, salarioHorasExtra, salarioBrutoFinal, retencionIRPF;
        

        // Entrada de datos
        // ----------------
        System.out.println ("CÁLCULO DE SALARIO"); 
        System.out.println ("------------------"); 

        System.out.print ("Introduzca salario bruto diario (euros): ");
        salarioBrutoDiario = teclado.nextDouble();

        System.out.print ("Introduzca número de horas extras realizadas este mes: ");
        horasExtra = teclado.nextInt();

        System.out.print ("Introduzca número de días trabajados este mes: ");
        diasTrabajados = teclado.nextInt();

        System.out.print ("Introduzca precio de la hora extra (euros): ");
        precioHoraExtra = teclado.nextDouble();

        
        // Procesamiento
        // -------------
        // Calculamos salario correspondiente a los días trabajados
        salarioDiasTrabajados = salarioBrutoDiario * diasTrabajados;
        
        // Calculamos salario correspondiente a las horas extra
        salarioHorasExtra =  precioHoraExtra * horasExtra;
        
        // Calculamos el salario bruto final teniendo en cuenta horas extra
        salarioBrutoFinal = salarioDiasTrabajados + salarioHorasExtra;
        
        // Calculamos la retención de impuestos
        retencionIRPF = salarioBrutoFinal * PORCENTAJE_IRPF/100;

        // Calculamos el salario neto teniendo en cuenta la retención de impuestos
        salarioFinal = salarioBrutoFinal - retencionIRPF;
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("Salario desglosado");

        System.out.print ("Salario bruto sin horas extras: ");
        System.out.print (salarioDiasTrabajados);
        System.out.println (" euros");
        
        System.out.print ("Salario bruto por horas extras: ");
        System.out.print (salarioHorasExtra);
        System.out.println (" euros");

        System.out.print ("Salario bruto completo: ");
        System.out.print (salarioBrutoFinal);
        System.out.println (" euros");

        System.out.print ("Retención por IRPF: ");
        System.out.print (retencionIRPF);
        System.out.println (" euros");

        System.out.println ();
        System.out.print ("Salario neto final: ");
        System.out.print (salarioFinal);
        System.out.println (" euros");
        
        
        
        
        
        
        
    }    
    
    
    
}
