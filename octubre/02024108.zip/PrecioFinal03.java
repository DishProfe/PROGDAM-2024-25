
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class PrecioFinal03 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        final double PORCENTAJE_IVA = 21.0;
        
        // Variables de entrada
        double precio, porcentajeDescuento;
        int unidades;
        
        // Variables de salida
        double precioFinal;
        
        // Variables auxiliares
        double precioConDescuento, iva, precioFinalUnidad;
        

        // Entrada de datos
        // ----------------
        System.out.println ("CÁLCULO DE PRECIO FINAL"); 
        System.out.println ("-----------------------"); 

        System.out.print ("Introduzca precio (euros): ");
        precio = teclado.nextDouble();

        System.out.print ("Introduzca cantidad de unidades: ");
        unidades = teclado.nextInt();

        System.out.print ("Introduzca porcentaje de descuento (0-99%): ");
        porcentajeDescuento = teclado.nextDouble();
        
        // Procesamiento
        // -------------
        // Calculamos precio del producto con el descuento
        precioConDescuento = precio - precio*porcentajeDescuento/100.0;
        
        // Calculamos el IVA del precio con el descuento aplicado
        iva = precioConDescuento * PORCENTAJE_IVA / 100.0;
        
        // Calculamos el precio final del producto incluyendo impuestos (IVA)
        precioFinalUnidad = precioConDescuento + iva; 

        // Calculamos el precio final teniendo en cuenta la cantidad de unidades del producto
        precioFinal = precioFinalUnidad * unidades;
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.print ("Precio final: ");
        System.out.print (precioFinal);
        System.out.println (" euros");
        
        
        
        
        
        
        
    }    
    
    
    
}
