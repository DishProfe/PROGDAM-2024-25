
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class PrecioFinal01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        final double PORCENTAJE_IVA = 21.0;
        
        // Variables de entrada
        double precio;
        
        // Variables de salida
        double precioFinal;
        
        // Variables auxiliares
        double iva;
        

        // Entrada de datos
        // ----------------
        System.out.println ("CÁLCULO DE PRECIO FINAL"); 
        System.out.println ("-----------------------"); 

        System.out.print ("Introduzca precio (euros): ");
        precio = teclado.nextDouble();

        
        // Procesamiento
        // -------------
        iva = precio * PORCENTAJE_IVA / 100.0;
        precioFinal = precio + iva; 
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.print ("Precio final: ");
        System.out.print (precioFinal);
        System.out.println (" euros");
        
        
        
        
        
        
        
    }    
    
    
    
}
