/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplos2024;


/**
 *
 * @author profe
 */
public class EjercicioUnidadesVolumen { // Ejercicio EjercicioUnidadesVolumen 
    
     public enum UnidadVolumen {MILILITRO, CENTILITRO, DECILITRO, LITRO, DECALITRO, HECTOLITRO };
     
     public static void main(String[] args) {

         UnidadVolumen var1, var2, var3;
                  
         System.out.println ("TIPO UnidadVolumen");
         System.out.println ("------------------");
         System.out.println ("Valores posibles:");
         System.out.println(UnidadVolumen.MILILITRO);
         System.out.println(UnidadVolumen.CENTILITRO);
         System.out.println(UnidadVolumen.DECILITRO);
         System.out.println(UnidadVolumen.LITRO);
         System.out.println(UnidadVolumen.DECALITRO);
         System.out.println(UnidadVolumen.HECTOLITRO);

         System.out.println();
         System.out.println("Contenido de variables de tipo UnidadVolumen:");
         
         var1 = UnidadVolumen.LITRO;
         System.out.print ("Valor de var1: ");
         System.out.println (var1);
         
         var2 = UnidadVolumen.CENTILITRO;
         System.out.print ("Valor de var2: ");
         System.out.println (var2);
              
         var3 = var1;
         System.out.print ("Valor de var3: ");
         System.out.println (var3);

     }
}
