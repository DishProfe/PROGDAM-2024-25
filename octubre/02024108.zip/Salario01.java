
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Salario01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        final double PORCENTAJE_IRPF = 18.0;
        
        // Variables de entrada
        double salarioBrutoDiario, precioHoraExtra;
        int horasExtra, diasTrabajados;
        
        // Variables de salida
        double salarioFinal;
        
        // Variables auxiliares
        double salarioDiasTrabajados, salarioHorasExtra, salarioBrutoFinal, retencionIRPF;
        
        int entero =  10;
        double real = 10;
        
        int  ent1 = 2_000_000_000;
        long ent4 = 2_000_000_000L;


        int ent2 = 2000000000;
        long ent3 = 2_500_000_000L;
        
        short ent5 = 32767;

        int ent6 = 0b1111_1111;
        int ent7 = 0xFF;
        int ent8 = 255;
        int ent9  = 0b1_111;
        int ent10 = 017;
        
        
        
        // Entrada de datos
        // ----------------
        System.out.println ("CÁLCULO DE SALARIO"); 
        System.out.println ("------------------"); 

        System.out.print ("Introduzca salario bruto diario (euros): ");
        salarioBrutoDiario = teclado.nextDouble();

        System.out.print ("Introduzca número de horas extras realizadas este mes: ");
        horasExtra = teclado.nextInt();

        System.out.print ("Introduzca número de días trabajados este mes: ");
        diasTrabajados = teclado.nextInt();

        System.out.print ("Introduzca precio de la hora extra (euros): ");
        precioHoraExtra = teclado.nextDouble();

        
        // Procesamiento
        // -------------
        // Calculamos salario correspondiente a los días trabajados
        salarioDiasTrabajados = salarioBrutoDiario * diasTrabajados;
        
        // Calculamos salario correspondiente a las horas extra
        salarioHorasExtra =  precioHoraExtra * horasExtra;
        
        // Calculamos el salario bruto final teniendo en cuenta horas extra
        salarioBrutoFinal = salarioDiasTrabajados + salarioHorasExtra;
        
        // Calculamos la retención de impuestos
        retencionIRPF = salarioBrutoFinal * PORCENTAJE_IRPF/100;

        // Calculamos el salario neto teniendo en cuenta la retención de impuestos
        salarioFinal = salarioBrutoFinal - retencionIRPF;
        
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.print ("Salario neto final: ");
        System.out.print (salarioFinal);
        System.out.println (" euros");
        
        
        
        
        
        
        
    }    
    
    
    
}
