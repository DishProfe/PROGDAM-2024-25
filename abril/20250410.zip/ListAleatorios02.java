package ejemplos2025;



import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Programa
 */
public class ListAleatorios02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        List<Integer> lista1;

        // Variables de salida
        // Variables auxiliares
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LISTA DE NÚMEROS ALEATORIOS");
        System.out.println("---------------------------");
        System.out.println(" ");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        System.out.println("Rellenamos la lista con números aleatorios:");
        lista1 = new LinkedList<>();
        for (int indice = 0; indice < 10; indice++) {
            int numAleatorio = (int) (Math.random() * 10);
            lista1.add(numAleatorio);
        }
        System.out.printf("Lista1:%s\n", lista1);
        System.out.println();


        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.printf("Lista1:%s\n", lista1);
        System.out.println();

        // Recorrido con bucle for convencional
        System.out.println ("Recorrido mediante bucle for convencional:");
        for ( int indice = 0; indice < lista1.size() ; indice++ ){
            Integer elemento = lista1.get(indice);
            System.out.printf("Lista1 - Elemento %2d: %2d\n", indice, elemento);            
        }
        
        
        // Recorrido con bucle while
        int indice = 0;
        System.out.println ("Recorrido mediante bucle while:");
        while ( indice < lista1.size() ){
            Integer elemento = lista1.get(indice);
            indice++;
            System.out.printf("Lista1 - Elemento %2d: %2d\n", indice, elemento);            
        }
        
        // Recorrido con bucle for como si fuera un while
        indice = 0;
        System.out.println ("Recorrido mediante bucle for como si fuera un while:");
        for ( ; indice < lista1.size() ; ){
            Integer elemento = lista1.get(indice);
            indice++;
            System.out.printf("Lista1 - Elemento %2d: %2d\n", indice, elemento);            
        }
        
        
        // Recorrido con bucle foreach
        indice = 0;
        System.out.println ("Recorrido mediante bucle foreach:");
        for ( Integer elemento : lista1 ){
            System.out.printf("Lista1 - Elemento %2d: %2d\n", indice++, elemento);            
        }
        
        
        // Recorrido con iterador
        System.out.println ("Recorrido utilizando un iterador:");
        Iterator<Integer> it = lista1.iterator();        
        indice = 0;
        while ( it.hasNext() ) {
            Integer elemento = it.next();
            System.out.printf("Lista1 - Elemento %2d: %2d\n", indice++, elemento);            
        }

        
        
    }

}
