package ejemplos2025;



import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Programa
 */
public class ListAleatorios03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        List<Integer> lista1;

        // Variables de salida
        // Variables auxiliares
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LISTA DE NÚMEROS ALEATORIOS");
        System.out.println("---------------------------");
        System.out.println(" ");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        System.out.println("Rellenamos la lista con números aleatorios:");
        lista1 = new LinkedList<>();
        for (int indice = 0; indice < 10; indice++) {
            int numAleatorio = (int) (Math.random() * 10);
            lista1.add(numAleatorio);
        }
        System.out.printf("Lista1:%s\n", lista1);
        System.out.println();

        System.out.println("Eliminamos de la lista los números pares y usando un iterador:");
        Iterator it = lista1.iterator();        
        while ( it.hasNext() ) {
            Integer elemento = (Integer) it.next();
            if (elemento % 2 == 0) {
                System.out.printf("Borrando Elemento: %2d\n", elemento);
                it.remove();
            }
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.printf("Lista1:%s\n", lista1);
        System.out.println();
        
        
    }

}
