package ejemplos2025;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author profe
 */
public class EjemploListas01 {
    
    
    public static void main ( String[] args ) {
        
        System.out.println ("Ejemplos de uso de listas en Java");
        System.out.println ("---------------------------------");
        System.out.println ();
        
        // Declaración de variables de tipo List<E>
        System.out.println ("Declaración de variables de tipo List<E>");
        List<Integer> listaEnteros;
        List<String> listaTextos;
        List<LocalDate> listaFechas;
        System.out.println ();
        
        
        System.out.println ("Creación de un objeto de tipo ArrayList<Integer>");
        //listaEnteros = new ArrayList<>();
        listaEnteros = new LinkedList<>();
        System.out.printf ("Contenido inicial: %s\n",
                listaEnteros.toString());
        
        
        System.out.println ("Le añadimos el valor 150: lista.add(150)");
        listaEnteros.add(150);
        System.out.printf ("Contenido actual: %s\n",
                listaEnteros.toString());
        
        System.out.println ("Le añadimos el valor 20: lista.add(20)");
        listaEnteros.add(20);
        System.out.printf ("Contenido actual: %s\n",
                listaEnteros.toString());
               
        System.out.println ("Le añadimos el valor 200: lista.add(200)");
        listaEnteros.add(200);
        System.out.printf ("Contenido actual: %s\n",
                listaEnteros.toString());
        System.out.printf ("Tamaño actual de la lista: %s\n",
                listaEnteros.size());

        System.out.println ("Obtenemos el contenido de la posición 0: lista.get(0)");
        System.out.printf ("%s\n", listaEnteros.get(0));

        System.out.println ("Obtenemos el contenido de la posición 1: lista.get(1)");
        System.out.printf ("%s\n", listaEnteros.get(1));

        System.out.println ("Obtenemos el contenido de la posición 2: lista.get(2)");
        System.out.printf ("%s\n", listaEnteros.get(2));
                
        System.out.println ("Eliminamos el contenido de la posición 0: lista.remove(0)");
        listaEnteros.remove(0);

        System.out.printf ("Contenido actual: %s\n",
                listaEnteros.toString());

        System.out.printf ("Tamaño actual de la lista: %s\n",
                listaEnteros.size());

        System.out.println ("Obtenemos el contenido de la posición 0: lista.get(0)");
        System.out.printf ("%s\n", listaEnteros.get(0));

        System.out.println ("Obtenemos el contenido de la posición 1: lista.get(1)");
        System.out.printf ("%s\n", listaEnteros.get(1));

        System.out.println ("Obtenemos el contenido de la posición 2: lista.get(2) -> Error");
        //System.out.printf ("%s\n", listaEnteros.get(2));

        System.out.println ("Modifcamos el contenido de la posición 1 con el valor 77: lista.set(1, 77)");
        listaEnteros.set (1,77);
        System.out.printf ("Contenido actual: %s\n",
                listaEnteros.toString());
        
        
    }
    
    
    
    
}



/*
        List<String> lista1, lista2;
        
        lista1 = new LinkedList<>();
        
        System.out.printf ("Tamaño de lista1: %d\n", lista1.size());
        System.out.printf ("Contenido de lista1: %s\n", lista1 );
        System.out.println();
        
        // Añadimos elementos a la lista
        System.out.printf ("Añadimos elementos a lista1: %s\n", lista1 );
        lista1.add("Mario");
        lista1.add("Jose");
        lista1.add("Antonio");
        lista1.add("Alfredo");
        lista1.add("Daniel");
        lista1.add("Adrián");
        lista1.add("Cristian");
        lista1.add("Zelmar");
        lista1.add("Carlos");
        lista1.add("Juan");
        lista1.add("Alonso");
        lista1.add("Agustín");
        System.out.printf ("Tamaño de lista1: %d\n", lista1.size());
        System.out.printf ("Contenido de lista1: %s\n", lista1 );

*/