package ejemplos2025;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Programa
 */
public class ListAleatorios01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        List<Integer> lista1, lista2;

        // Variables de salida
        // Variables auxiliares
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LISTAS DE NÚMEROS ALEATORIOS");
        System.out.println("----------------------------");
        System.out.println(" ");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        lista1 = new ArrayList<>();
        lista2 = new LinkedList<>();
        for (int i = 0; i < 20; i++) {
            int numAleatorio = (int) (Math.random() * 100);
            System.out.printf ("Añadimos el número %d\n", numAleatorio);
            lista1.add(numAleatorio);
            lista2.add(0, numAleatorio);
            System.out.printf("Lista1:%s\n", lista1);
            System.out.printf("Lista2:%s\n", lista2);
            System.out.println();
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO FINAL");
        System.out.println("---------------");
        System.out.printf("Lista1:%s\n", lista1);
        System.out.printf("Lista2:%s\n", lista2);
        System.out.println();

        System.out.println("Fin del programa.");

    }

}
