
package ejemplos2025.cajas;

/**
 * Clase CajaTextos.
 * @author profe
 * @param <T1>
 * @param <T2>
 */
public class CajaMixta <T1, T2> {
 
    T1 elemento1;
    T2 elemento2;
    
    
    public CajaMixta ( T1 elem1, T2 elem2) {
        this.elemento1 = elem1;
        this.elemento2 = elem2;
    }


    @Override
    public String toString() {
        return String.format ("{ %s, %s }",
                this.elemento1, this.elemento2);
    }
    
    
}
