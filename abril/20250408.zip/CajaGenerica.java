
package ejemplos2025.cajas;

/**
 * Clase CajaTextos.
 * @author profe
 */
public class CajaGenerica <T> {
 
    T elemento1, elemento2;
    
    
    public CajaGenerica ( T elem1, T elem2) {
        this.elemento1 = elem1;
        this.elemento2 = elem2;
    }


    @Override
    public String toString() {
        return String.format ("{ %s, %s }",
                this.elemento1, this.elemento2);
    }
    
    
}
