
package ejemplos2025.cajas;
import java.time.LocalDate;

/**
 * Clase Caja.
 * @author profe
 */
public class CajaInteger  {
 
    private Integer elemento1, elemento2; 
    
    
    public CajaInteger (Integer elem1, Integer elem2) {
        this.elemento1 = elem1;
        this.elemento2 = elem2;
    }


    @Override
    public String toString() {
        return String.format ("{ %s, %s }",
                this.elemento1, this.elemento2);
    }
    
    
}
