
package ejemplos2025.cajas;

import java.time.LocalDate;
import java.time.LocalTime;



/**
 * Pruba de uso de objetos CajaTextos.
 * @author profe
 */
public class PruebaCajas {
    
    
    public static void main (String[] args) {
    
        System.out.println("PRUEBA DE CAJAS");
        System.out.println("---------------");
        
        CajaTextos ct1, ct2;
        CajaFechas cf1, cf2;
        CajaInteger ce1, ce2;
        CajaHoras ch1, ch2;
        
        Caja c1, c2;
        CajaGenerica<LocalDate> cg1;
        CajaGenerica<String> cg2;
        CajaMixta<LocalDate, String> cgen1;
        CajaMixta<Integer, Boolean> cgen2;
        CajaMixta<Integer, Integer> cgen3;
        
        
        ct1 = new CajaTextos ("Elemento1", "Elemento2");
        ct2 = new CajaTextos ("e1", "e2");
        
        cf1 = new CajaFechas (LocalDate.of (1977, 8, 16), LocalDate.of (1963, 11, 22));
        cf2 = new CajaFechas (LocalDate.now(), LocalDate.now().minusYears(1));

        ce1 = new CajaInteger (100, 20);
        ce2 = new CajaInteger (1, 5);

        ch1 = new CajaHoras (LocalTime.of (10,20), LocalTime.of (0,0));
        ch2 = new CajaHoras (LocalTime.now(), LocalTime.now().minusMinutes(30));
        
        c1 = new Caja ( "Texto 1", LocalDate.now());
        c2 = new Caja ( 27, true);
        
        cg1 = new CajaGenerica<> (LocalDate.now(),LocalDate.now().minusDays(1));
        cg2 = new CajaGenerica<> ("Cadena 1", "Cadena2");
        
        
        System.out.printf ("ct1 = %s\n", ct1.toString());
        System.out.printf ("ct2 = %s\n", ct2.toString());
        System.out.println();
        
        System.out.printf ("cf1 = %s\n", cf1.toString());
        System.out.printf ("cf2 = %s\n", cf2.toString());
        System.out.println();

        System.out.printf ("ce1 = %s\n", ce1.toString());
        System.out.printf ("ce2 = %s\n", ce2.toString());
        System.out.println();
        
        System.out.printf ("ch1 = %s\n", ch1.toString());
        System.out.printf ("ch2 = %s\n", ch2.toString());
        System.out.println();

        System.out.printf ("c1 = %s\n", c1.toString());
        System.out.printf ("c2 = %s\n", c2.toString());
        System.out.println();

        System.out.printf ("cg1 = %s\n", cg1.toString());
        System.out.printf ("cg2 = %s\n", cg2.toString());
        System.out.println();
    }
    
}
