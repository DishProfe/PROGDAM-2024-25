
package ejemplos2025.cajas;
import java.time.LocalDate;

/**
 * Clase Caja.
 * @author profe
 */
public class CajaFechas  {
 
    private LocalDate elemento1, elemento2; 
    
    
    public CajaFechas (LocalDate elem1, LocalDate elem2) {
        this.elemento1 = elem1;
        this.elemento2 = elem2;
    }


    @Override
    public String toString() {
        return String.format ("{ %s, %s }",
                this.elemento1, this.elemento2);
    }
    
    
}
