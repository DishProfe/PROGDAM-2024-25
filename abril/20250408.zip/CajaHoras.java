
package ejemplos2025.cajas;import java.time.LocalTime;

/**
 * Clase Caja.
 * @author profe
 */
public class CajaHoras  {
 
    private LocalTime elemento1, elemento2; 
    
    
    public CajaHoras (LocalTime elem1, LocalTime elem2) {
        this.elemento1 = elem1;
        this.elemento2 = elem2;
    }


    @Override
    public String toString() {
        return String.format ("{ %s, %s }",
                this.elemento1, this.elemento2);
    }
    
    
}
