package ejemplos2025.ajedrez;


/**
 * Clase que representa a la pieza Torre del juego de Ajedrez.
 * @author profe
 */
public class Torre extends PiezaAjedrez {

    // ------------------------------------------------------
    //                   Atributos de clase
    // ------------------------------------------------------

    // ------------------------------------------------------
    //             Atributos de objeto (todos privados)
    // ------------------------------------------------------


    // ------------------------------------------------------
    //                     Constructores
    // ------------------------------------------------------
    public Torre (int fila, int columna, String color) 
            throws IllegalArgumentException {

        // Parte gen�rica del constructor (llamada al constructor padre)
        super (fila, columna, color);
        
    }

    // ------------------------------------------------------
    //             M�todos heredados de PiezaAjedrez
    // ------------------------------------------------------
    /**
     * Indica si la torre se puede mover a una determina ubicaci�n 
     * del tablero.
     * Las reglas de movimiento de una torre son .......
     * @param fila
     * @param columna
     * @return <code>true</code> si puede moverse a esa ubicaci�n, <code>false</code> en otro caso
     */
    @Override
    public boolean esMovible (int fila, int columna) {
        // Comprobamos que el destino cumple las reglas de movimiento de una torre
        // Puede moverse en verticual u horizontal
        return  fila == this.getFila() && columna != this.getColumna() || 
                  fila != this.getFila() && columna == this.getColumna() ;               
    }
    

    
     // ------------------------------------------------------
    //                   M�todo toString
    // ------------------------------------------------------
    /**
     * toString
     * @return 
     */
    @Override
    public String toString () {
        return String.format ("Torre: %s",
                super.toString()
        );
    }
   
    
}
