package ejemplos2025.ajedrez;

import Ejemplos2023.ajedrez.*;
import java.util.Scanner;

/**
 * Programa
 */
public class PruebaAjedrez01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        PiezaAjedrez[] arrayPiezas = {
            new Peon(2, 1, "BLANCO"),
            new Peon(2, 2, "BLANCO"),
            new Peon(2, 3, "BLANCO"),
            new Peon(2, 4, "BLANCO"),
            new Peon(2, 5, "BLANCO"),
            new Peon(2, 6, "BLANCO"),
            new Peon(2, 7, "BLANCO"),
            new Peon(2, 8, "BLANCO"),
            new Torre(1, 1, "BLANCO"),
            new Torre(1, 8, "BLANCO"),
            new Caballo(1, 2, "BLANCO"),
            new Caballo(1, 7, "BLANCO"),
            new Alfil(1, 3, "BLANCO"),
            new Alfil(1, 6, "BLANCO"),
            new Reina(1, 4, "BLANCO"),
            new Rey(1, 5, "BLANCO")

        };

        // Variables de salida
        // Variables auxiliares
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("PIEZAS DE AJEDREZ");
        System.out.println("-----------------");
        System.out.println();

        System.out.println("Ubicaciones iniciales");
        for (PiezaAjedrez pieza : arrayPiezas) {
            System.out.printf("%s\n", pieza.toString());
        }
        System.out.println();
        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        System.out.println ("PRUEBAS DE MOVIMIENTO DE PIEZAS");
        for (PiezaAjedrez pieza : arrayPiezas) {

            // 1. mover la pieza una posici�n hacia delante (arriba);
            System.out.print ("Intento de movimiento 1 posici�n hacia delante: ");
            intentarMoverPieza(pieza, pieza.getFila() + 1, pieza.getColumna());

            //2. mover la pieza una posici�n hacia la derecha;
            System.out.print ("Intento de movimiento 1 posici�n hacia la derecha: ");
            intentarMoverPieza(pieza, pieza.getFila(), pieza.getColumna() + 1);

            //3. mover la pieza una posici�n hacia delante y la derecha;
            System.out.print ("Intento de movimiento 1 posici�n hacia delante y 1 hacia la derecha: ");
            intentarMoverPieza(pieza, pieza.getFila()+1, pieza.getColumna() + 1);

            //4. mover la pieza una posici�n hacia delante y la izquierda;
            System.out.print ("Intento de movimiento 1 posici�n hacia delante y 1 hacia la izquierda: ");
            intentarMoverPieza(pieza, pieza.getFila()+1, pieza.getColumna() - 1);

            //5. mover la pieza dos posiciones hacia delante y una hacia la derecha.        
            System.out.print ("Intento de movimiento 2 posiciones hacia delante 1 hacia la izquierda: ");
            intentarMoverPieza(pieza, pieza.getFila()+2, pieza.getColumna() -1 );

        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.println("Ubicaciones finales");
        for (PiezaAjedrez pieza : arrayPiezas) {
            System.out.printf("%s\n", pieza.toString());
        }

        System.out.println();
        System.out.println("Fin del programa.");

    }

    public static void intentarMoverPieza(PiezaAjedrez pieza, int fila, int columna) {
        System.out.printf ("%s -> (%d, %d)\n",
                pieza, fila, columna);
        try {
            pieza.mover(fila, columna);
            System.out.printf ("Movimiento efectuado con �xito.\n");
        } catch (IllegalArgumentException | IllegalStateException ex) {
            System.out.printf("Error: %s\n", ex.getMessage());
        }
        System.out.println();
    }

}
