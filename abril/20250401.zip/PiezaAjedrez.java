package ejemplos2025.ajedrez;

/**
 * Clase que representa una pieza del juego del ajedrez en general.
 * �nicamente contendr� el color de la pieza y su ubicaci�n (fila y columna)
 * @author profe
 */
public abstract class PiezaAjedrez {

    // ------------------------------------------------------
    //                   Atributos de clase
    // ------------------------------------------------------

    // Atributos constantes y p�blicos
    // -------------------------------
    
    /**
     * M�nima columna: {@value MIN_COL}
     */
    public static final int MIN_COL = 1; 
    
    /**
     * M�xima columna: {@value MAX_COL}
     */
    public static final double MAX_COL = 8; 
    
    /**
     * M�nima fila: {@value MIN_FIL}
     */
    public static final int MIN_FIL = 1; 
    
    /**
     * M�xima fila: {@value MAX_FIL}
     */
    public static final int MAX_FIL = 8; 

    /**
     * Fila por omisi�n: {@value DEFAULT_FIL}
     */
    public static final int DEFAULT_FIL = 1; 
    
    /**
     * Columna por omisi�n: {@value DEFAULT_COL}
     */
    public static final int DEFAULT_COL = 1; 

    /**
     * Color por omisi�n: {@value DEFAULT_COLOR}
     */
    public static final String DEFAULT_COLOR = "BLANCO"; 
    
    
    
    // Atributos privados (estado de la clase)
    // ---------------------------------------
    // N�mero de piezas creadas hasta el momento
    private static int piezasCreadas = 0;
    
    
    // ------------------------------------------------------
    //             Atributos de objeto (todos privados)
    // ------------------------------------------------------

    // Atributos constantes (definen la "naturaleza" del objeto)
    // ---------------------------------------------------------
    private final String color;
    
    // Atributos variables (definen el "estado" del objeto en un momento dado)
    // -----------------------------------------------------------------------
    private int fila;
    private int columna;

    
    // ------------------------------------------------------
    //                     Constructores
    // ------------------------------------------------------
    /**
     * Constructor para crear una pieza de Ajedrez en una fila y columna dadas y
     * del color pasado como par�metro.
     * La fila y la columna deben estar en el rango {@value MIN_FIL}-{@value MAX_FIL}.
     * El color solo puede ser "BLANCO" o "NEGRO". Se admiten may�sculas y min�sculas.
     * @param fila fila donde se colocar� la pieza
     * @param columna columna donde se colocar� la pieza
     * @param color color de la pieza
     * @throws IllegalArgumentException si la ubicaci�n (fila, columna) es inv�lida 
     * o el color es inv�lido.
     */
    public PiezaAjedrez (int fila, int columna, String color) 
            throws IllegalArgumentException {

        // Variables locales
        String colorMayuscula = color.toUpperCase();
        
        // Controlamos que la pieza est� dentro del tablero
        if ( !enTablero(fila,columna) ) {
            throw new IllegalArgumentException (
                    String.format ("Pieza fuera del tablero (%d,%d)", fila, columna));
        } else if (!colorCorrecto(colorMayuscula)) {
            throw new IllegalArgumentException (
                    String.format ("Color de pieza incorrecto: %s", colorMayuscula));            
        }
        // Si todo ha ido bien:
        
        // 1. Inicializamos atributos de objeto
        this.fila = fila;
        this.columna = columna;
        this.color = colorMayuscula;
        
        // 2. Actualizamos atributos de clase
        PiezaAjedrez.piezasCreadas++;
        
    }
        
    /**
     * Constructor para crear una pieza de Ajedrez en una fila y columna dadas. 
     * El color ser� el valor por omisi�n: {@value DEFAULT_COLOR}
     * @param fila Fila donde se ubicar� la pieza
     * @param columna Columna donde se ubicar� la pieza
     */
    public PiezaAjedrez (int fila, int columna) {
        this (fila, columna, PiezaAjedrez.DEFAULT_COLOR);
    }

    /**
     * Constructor donde solo se proporciona el color.
     * La ubicaci�n ser� el valor por omisi�n: {@value DEFAULT_FIL, @value DEFAULT_COL}
     * @param color Color de la pieza
     */
    public PiezaAjedrez (String color) {
        this ( PiezaAjedrez.DEFAULT_FIL, PiezaAjedrez.DEFAULT_COL, color);
    }

    /**
     * Constructor sin par�metros. Se crear� un objeto pieza ubicada en {@value DEFAULT_FIL, @value DEFAULT_COL}
     * y de color el valor por omisi�n  {@value DEFAULT_COLOR}
     */
    public PiezaAjedrez () {
        this (PiezaAjedrez.DEFAULT_COLOR);
    }
    
    // ------------------------------------------------------
    //               M�todos GETTER
    // ------------------------------------------------------
    /**
     * Obtiene la fila de la pieza
     * @return fila en la que est� ubicada la pieza
     */
    public int getFila() {
        return this.fila;
    }
    
    /**
     * Obtiene la columna de la pieza
     * @return columna en la que est� ubicada la pieza
     */
    public int getColumna() {
        return this.columna;
    }

    /** 
     * Obtiene el color de la pieza
     * @return color de la pieza
     */
    public String getColor() {
        return this.color;
    }
    
    // ------------------------------------------------------
    //               M�todos SETTER
    // ------------------------------------------------------
    /** 
     * Establece una nueva fila para la pieza
     * @param fila nueva fila para la pieza
     */
    private void setFila(int fila) {
        this.fila = fila;
    }
    
    /**
     * Establece una nueva columna para la pieza
     * @param columna nueva columna para la pieza
     */
    private void setColumna(int columna) {
        this.columna = columna;
    }



    
    // ------------------------------------------------------
    //               M�todos abstractos
    // ------------------------------------------------------
    // M�todos que tendr�n que ser implementados por las clases
    // derivadas.
    /**
     * Indica si la pieza se puede mover a una determina ubicaci�n 
     * del tablero.
     * @param fila fila donde se desea mover la pieza
     * @param columna columna donde se desea mover la pieza
     * @return <code>true</code> si puede moverse a esa ubicaci�n, <code>false</code> en otro caso
     */
    public abstract boolean esMovible (int fila, int columna);

    
    /**
     * Mueve la pieza a la ubicaci�n indicada.
     * Si no es posible llevar a cabo el movimiento, saltar� una excepci�n.
     * @param fila fila donde se desea mover la pieza
     * @param columna columna donde se desea mover la pieza
     * @throws IllegalArgumentException si la fila o la columna est� fuera del tablero
     * @throws IllegalStateException si la ubicaci�n de destino no es posible por las reglas de movimiento de la pieza
     */
    public void mover (int fila, int columna) throws IllegalArgumentException, IllegalStateException {
        if  (fila == this.getFila() && columna == this.getColumna()) {
            // No se est� intentando mover la pieza. Posici�n final igual a posici�n de inicio
            throw new IllegalStateException (
                String.format ("Posici�n final igual a posici�n de inicio: (%d,%d) -> (%d,%d)", 
                    this.getFila(), this.getColumna(), fila, columna));
        } else if (!PiezaAjedrez.enTablero(fila, columna)) {
            // Posici�n fuera del tablero
            throw new IllegalArgumentException (
                String.format ("Esa posici�n est� fuera del tablero: (%d,%d)", 
                    fila, columna));
        } else if (!this.esMovible(fila, columna)) {
            // Movimiento ilegal para esta pieza
            throw new IllegalStateException (
                String.format ("Movimiento ilegal para esta pieza: (%d,%d) -> (%d,%d)", 
                    this.getFila(), this.getColumna(), fila, columna));
        } else {
            // Movimiento posible: lo ejecutamos
            this.setFila(fila);
            this.setColumna(columna);
        }
    } 



    // ------------------------------------------------------
    //                   M�todo toString
    // ------------------------------------------------------
    /**
     * Representaci�n textual del contenido de un objeto del tipo <code>PiezaAjedrez</code>
     * @return 
     */
    @Override
    public String toString () {
        return String.format ("%s: (%d, %d)",
                this.color,
                this.fila,
                this.columna
        );
    }



    
    
    
    // ------------------------------------------------------
    //               M�todos auxiliares
    // ------------------------------------------------------
    /**
     * Indica si una ubicaci�n est� en el tablero de ajedrez.
     * El tama�o de un tablero de ajedrez es de 8x8.
     * Se cuentan filas y columnas desde {@value MIN_COL} hasta {@value MAX_COL}.
     * @param fila fila a comprobar
     * @param columna columna a comprobar
     * @return <code>true</code> si la ubicaci�n est� dentro del tablero o <code>false</code> en caso contrario 
     */
    public static boolean enTablero (int fila, int columna) {
        return fila>=PiezaAjedrez.MIN_FIL && fila<=PiezaAjedrez.MAX_FIL &&
                columna>=PiezaAjedrez.MIN_COL && columna<=PiezaAjedrez.MAX_COL;        
    }
    
    /**
     * Indica si el color es v�lido para una pieza de ajedrez.
     * @param color color a comprobar
     * @return <code>true</code> si el color es v�lido o <code>false</code> en caso contrario 
     */
    private static boolean colorCorrecto (String color) {
        return color.equals("BLANCO") || color.equals("NEGRO");
    }
    
    
}
