package ejemplos2025;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 *
 * @author profe
 */
public class EjemploOperacionesConjuntos01 {

    public static void main(String[] args) {

        System.out.println("Ejemplos de operaciones con conjuntos en Java");
        System.out.println("---------------------------------------------");
        System.out.println();

        int n1 = 1;
        int n2 = 10;
        int cantidad = 5;

        Set<Integer> conjuntoA = new HashSet<>();
        Set<Integer> conjuntoB = new HashSet<>();

        while (conjuntoA.size() < cantidad) {
            // Generamos número aleatorio entre n1 y n2, ambos incluidos
            int aleatorio1 = n1 + (int) (Math.random() * (n2 - n1 + 1));
            int aleatorio2 = n1 + (int) (Math.random() * (n2 - n1 + 1));
            // Lo añadimos al conjunto
            conjuntoA.add(aleatorio1);
            conjuntoB.add(aleatorio2);
        }
        
        
        
        // Union AUB
        Set<Integer> unionAB = new HashSet(conjuntoA);
        unionAB.addAll(conjuntoB);
        
        // Intersección A B
        Set<Integer> interseccionAB = new HashSet(conjuntoA);
        interseccionAB.retainAll(conjuntoB);
        
        // Diferencia A-B
        Set<Integer> diferenciaAB = new HashSet(conjuntoA);
        diferenciaAB.removeAll(conjuntoB);
        
        // Diferencia B-A
        Set<Integer> diferenciaBA = new HashSet(conjuntoB);
        diferenciaBA.removeAll(conjuntoA);
        
        // Conjuntos iniciales
        System.out.printf ("A = %s\n", conjuntoA);
        System.out.printf ("B = %s\n", conjuntoB);
        
        // Resultados de las opoeraciones
        System.out.printf ("unionAB = %s\n", unionAB);
        System.out.printf ("interseccionAB = %s\n", interseccionAB);
        System.out.printf ("diferenciaAB = %s\n", diferenciaAB);
        System.out.printf ("diferenciaBA = %s\n", diferenciaBA);

    }

}


