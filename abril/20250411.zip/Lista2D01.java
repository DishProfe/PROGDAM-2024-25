package ejemplos2025;



import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Programa
 */
public class Lista2D01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        List<List<Integer>> lista2D;
        
        // Variables de salida
        // Variables auxiliares
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LISTA DE LISTAS DE ENTEROS ALEATORIOS");
        System.out.println("-------------------------------------");
        System.out.println(" ");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        System.out.println("Creamos la lista inicial (primera dimensión):");
        lista2D = new LinkedList<>();
        System.out.println(lista2D.toString());

/*        
        for (int indice1 = 0 ; indice1 < 4 ; indice1++ ) {
            List<Integer> lista1D = new LinkedList<>();       
            for (int indice2 = 0 ; indice2 < 4 ; indice2++ ) {
                int numAleatorio = (int)(Math.random()*10);
                lista1D.add (numAleatorio);                    
            }
            lista2D.add(lista1D);
            System.out.println(lista2D.toString());
        }
*/


        for (int indice1 = 0 ; indice1 < 4 ; indice1++ ) {
            lista2D.add(new LinkedList<>());
            for (int indice2 = 0 ; indice2 < 4 ; indice2++ ) {
                int numAleatorio = (int)(Math.random()*10);
                lista2D.get(indice1).add (numAleatorio);                    
            }
            System.out.println(lista2D.toString());
        }

        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.printf("Lista:%s\n", lista2D);
        System.out.println();
        
        
    }

}
