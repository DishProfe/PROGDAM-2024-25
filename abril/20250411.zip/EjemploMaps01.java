package ejemplos2025;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author profe
 */
public class EjemploMaps01 {
    
    
    public static void main ( String[] args ) {
        
        Map<String, String> mapDniNombre;
        mapDniNombre = new HashMap<>();
        
        System.out.println ("Creamos la lista");
        System.out.printf ("Tamaño del  map: %d\n", mapDniNombre.size());
        System.out.printf ("Contenido de dniNombre: %s\n", mapDniNombre );
        System.out.println();
        
        // Añadimos elementos al map
        System.out.println ("Añadimos elementos al map");
        mapDniNombre.put ("55555555E" ,"Alonso Alcaraz");
        mapDniNombre.put ("66666666F" ,"Roberto Milan");
        mapDniNombre.put ("11111111B" ,"Antonio Perez");
        mapDniNombre.put ("11111111C" ,"David Suciu");
        mapDniNombre.put ("11111111D" ,"Alvaro Gonzalez");
        mapDniNombre.put ("11111111E" ,"Paco Rodriguez ");
        mapDniNombre.put ("11111111G" ,"Dani Cano");
        mapDniNombre.put ("11111111H" ,"Jordan  Mauricio");
        mapDniNombre.put ("11111111K" ,"Fernando Mendez");
        mapDniNombre.put ("11111111P" ,"Miguel Garcia-Tapia");
        System.out.printf ("Tamaño de map: %d\n", mapDniNombre.size());
        System.out.printf ("Contenido de map: %s\n", mapDniNombre );
        
        
        System.out.println();
        System.out.println("Obtenemos algunos elementos del map:");
        System.out.printf ("Contenido de la posición 55555555E: %s\n", 
                mapDniNombre.get("55555555E") );
        System.out.printf ("Contenido de la posición 11111111D: %s\n", 
                mapDniNombre.get("11111111D") );
        System.out.println();
        

        System.out.println ("Obtenemos el conjunto de claves del map");
        Set<String> setClaves = mapDniNombre.keySet();
        System.out.printf ("Set de claves (keys) del map: %s\n",
                setClaves.toString());
        System.out.println();
        
        System.out.println ("Recorremos el conjunto de claves del map");
        for ( String clave : setClaves  ) {
            System.out.printf ("%s\n", clave);
        }
        System.out.println();
        
        
        System.out.println ("Obtenemos para cada clave del map su valor asociado:");
        for ( String clave : setClaves  ) {
            String valor = mapDniNombre.get(clave);
            System.out.printf ("%s -> %s\n", clave, valor);
        }
        System.out.println();
        
        System.out.println ("Obtenemos para cada clave del map su valor asociado usando iterador:");
        Iterator<String> it = setClaves.iterator();
        while ( it.hasNext() ) {
            String clave = it.next();
            String valor = mapDniNombre.get(clave);
            System.out.printf ("%s -> %s\n", clave, valor);
        }
        System.out.println();
        
        
        
/*        
        // Obtenemos el set que contiene todas las claves del map
        Set<String> setClaves = mapDniNombre.keySet();
        for ( String clave : setClaves ) {
            System.out.printf ("%s -> %s\n", 
                    clave,
                    mapDniNombre.get(clave));
        }
*/
        
        
        
        
               
    }
    
    
    
    
}
