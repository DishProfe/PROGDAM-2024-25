package ejemplos2025;



import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Programa
 */
public class Lista3D01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        List<List<List<Integer>>> lista3D;
        
        // Variables de salida
        // Variables auxiliares
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LISTA DE LISTAS DE LISTAS DE ENTEROS ALEATORIOS");
        System.out.println("-----------------------------------------------");
        System.out.println(" ");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        System.out.println("Creamos la lista inicial (primera dimensión):");
        lista3D =  new LinkedList<>();

/*        
        for (int indice1 = 0 ; indice1 < 4 ; indice1++ ) {
            // Creamos sublistas de la segunda dimensión
            List<List<Integer>>lista2D = new LinkedList<>();
            lista3D.add (lista2D);
            for (int indice2 = 0 ; indice2 < 4 ; indice2++ ) {
                // Creamos sublistas de la tercera dimensión
                List<Integer> lista1D = new LinkedList<>();
                lista2D.add (lista1D);  
                for (int indice3 = 0 ; indice3 < 4; indice3++ ) {
                    // Generamos enteros aleatorios para las sublistas de la 3a dimensión
                    int numAleatorio = (int)(Math.random()*10);
                    lista1D.add(numAleatorio);
                    //System.out.println(lista2D.toString());
                }                
                System.out.println(lista3D.toString());
            }
            System.out.println(lista3D.toString());
        }
*/

        for (int indice1 = 0 ; indice1 < 4 ; indice1++ ) {
            // Creamos sublistas de la segunda dimensión
            lista3D.add(new LinkedList<>());
            for (int indice2 = 0 ; indice2 < 4 ; indice2++ ) {
                // Creamos sublistas de la tercera dimensión
                lista3D.get(indice1).add (new LinkedList<>());  
                for (int indice3 = 0 ; indice3 < 4; indice3++ ) {
                    // Generamos enteros aleatorios para las sublistas de la 3a dimensión
                    int numAleatorio = (int)(Math.random()*10);
                    lista3D.get(indice1).get(indice2).add(numAleatorio);
                    //System.out.println(lista2D.toString());
                }                
                System.out.println(lista3D.toString());
            }
            System.out.println(lista3D.toString());
        }

       
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.printf("Lista:%s\n", lista3D.toString());
        System.out.println();

/*        
        System.out.println("Recorrido elemento a elemento");
        int indice1 = 0;
        for ( List<List<Integer>> lista2D : lista3D) {
            int indice2 = 0;
            for ( List<Integer> lista1D  : lista2D ) {
                int indice3 = 0;
                for ( Integer elemento : lista1D ) {
                    System.out.printf ("Elemento (%d,%d,%d): %d  ",
                            indice1,
                            indice2,
                            indice3,
                            elemento);
                    indice3++;
                }
                System.out.println();
                indice2++;
            }
            indice1++;
            System.out.println();
        }
*/

        System.out.println("Recorrido elemento a elemento");
        for ( int indice1 = 0; indice1 < lista3D.size() ; indice1++ ) {
            
            for ( int indice2 = 0; indice2 < lista3D.get(indice1).size() ; indice2++ ) {
                
                for ( int indice3 = 0 ; indice3 < lista3D.get(indice1).get(indice2).size(); indice3++ ) {
                    System.out.printf ("Elemento (%d,%d,%d): %d  ",
                            indice1,
                            indice2,
                            indice3,
                            lista3D.get(indice1).get(indice2).get(indice3) );
                }
                System.out.println();
            }
            System.out.println();
        }

        
        
    }

}
