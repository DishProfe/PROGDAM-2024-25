package ejemplos2024arrays;


import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class RepasoHorarioClase03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida
        int[][] horario;
        
        
        // Variables auxiliares
        String[] materias= {"PROG", "BD", "SI", "ED", "LMSGI", "IP", "SOS", "DIG"};
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("HORARIO DE CLASES EN ARRAY");
        System.out.println("--------------------------");
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Asignamos espacio en memoria para el array horario
        horario = new int[5][6];

        // Asignamos materias aleatorias al horario
        for ( int dia = 0 ; dia < horario.length ; dia++ ) {
            for ( int hora = 0 ; hora<horario[dia].length ; hora++ ) {
                
                // Generamos materia aleatoria
                int materiaAleatoria = (int)(Math.random()*8);
                
                // La asignamos a la posición del horario: [dia][hora]
                horario[dia][hora] = materiaAleatoria;
                
            }
        }
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        // Mostramos el contenido del array de LocalTime
        System.out.println ("Horario de clases: ");
        System.out.println (Arrays.toString (horario));
        System.out.println ();

        System.out.println (Arrays.deepToString (horario));
        System.out.println ();
        
        for (int dia=0; dia < horario.length ;  dia++ ) {
            System.out.println (Arrays.toString (horario[dia]));
        }
        System.out.println ();
        
        for ( int dia=0; dia < horario.length ;  dia++ ) {
            for ( int hora=0 ; hora<horario[dia].length; hora++ ) {
                System.out.printf ("%-5s ", materias[horario[dia][hora]] );
            }
            System.out.printf("\n");
        }
        System.out.println ();

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}