package ejemplos2024arrays;


import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class RepasoHorarioClase01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida
        String[][] horario = {
            //Lunes
            { "ED", "ED", "IP", "SI", "SI", "SI"},
            // Martes
            { "ED", "LMSGI", "LMSGI", "LMSGI", "PROG", "PROG"},
            // Miércoles
            { "SOS", "SI", "SI", "BD", "BD", "BD"},   
            // Jueves
            { "PROG", "PROG", "PROG", "IP", "IP", "DIG"}, 
             // Viernes
            { "PROG", "PROG", "PROG", "BD", "BD", "BD"}               
        };
        
        
        // Variables auxiliares
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("HORARIO DE CLASES EN ARRAY");
        System.out.println("--------------------------");
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // 

        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        // Mostramos el contenido del array de LocalTime
        System.out.println ("Horario de clases: ");
        System.out.println (Arrays.toString (horario));
        System.out.println ();

        System.out.println (Arrays.deepToString (horario));
        System.out.println ();
        
        for (int dia=0; dia < horario.length ;  dia++ ) {
            System.out.println (Arrays.toString (horario[dia]));
        }
        System.out.println ();
        
        for ( int dia=0; dia < horario.length ;  dia++ ) {
            for ( int hora=0 ; hora<horario[dia].length; hora++ ) {
                System.out.printf ("%-5s ", horario[dia][hora]);
            }
            System.out.printf("\n");
        }
        System.out.println ();

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}