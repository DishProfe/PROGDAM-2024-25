package ejemplos2024arrays;


import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class RepasoHorarioClase02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida
        
        
        int[][] horario = {
            //Lunes
            { 3, 3, 5, 2, 2, 2},
            // Martes
            { 3, 4, 4, 4, 0, 0},
            // Miércoles
            { 6, 2, 2, 1, 1, 1},   
            // Jueves
            { 0, 0, 0, 5, 5, 7}, 
            // Viernes
            { 0, 0, 0, 5, 5, 5}               
        };
        
        
        // Variables auxiliares
        String[] materias= {"PROG", "BD", "SI", "ED", "LMSGI", "IP", "SOS", "DIG"};
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("HORARIO DE CLASES EN ARRAY");
        System.out.println("--------------------------");
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // 

        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        // Mostramos el contenido del array de LocalTime
        System.out.println ("Horario de clases: ");
        System.out.println (Arrays.toString (horario));
        System.out.println ();

        System.out.println (Arrays.deepToString (horario));
        System.out.println ();
        
        for (int dia=0; dia < horario.length ;  dia++ ) {
            System.out.println (Arrays.toString (horario[dia]));
        }
        System.out.println ();
        
        for ( int dia=0; dia < horario.length ;  dia++ ) {
            for ( int hora=0 ; hora<horario[dia].length; hora++ ) {
                System.out.printf ("%-5s ", materias[horario[dia][hora]] );
            }
            System.out.printf("\n");
        }
        System.out.println ();

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}