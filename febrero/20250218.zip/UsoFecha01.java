package ejemplos2025;


import java.util.Scanner;

/**
 *   Programa
 */

    public class UsoFecha01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares


        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS FECHA");
        System.out.println("--------------------------------");
        System.out.println(" ");

        
        Fecha f1, f2, f3, f4;
        
        f1 = new Fecha( 18, 2, 2025 );
        System.out.printf ("f1.dia  = %d\n", f1.getDia() );
        System.out.printf ("f1.mes  = %d\n", f1.getMes() );
        System.out.printf ("f1.year = %d\n", f1.getYear() );
        System.out.printf ("f1.esBisiesto = %s\n", f1.isYearBisiesto() );
        System.out.println ("Cambiamos el valor de d�a: f1.setDia(15)");
        f1.setDia(15);
        System.out.printf ("f1.dia  = %d\n", f1.getDia() );
        System.out.println ();
        
        f2 = new Fecha ( 10, 2025 );
        System.out.printf ("f2.dia  = %d\n", f2.getDia() );
        System.out.printf ("f2.mes  = %d\n", f2.getMes() );
        System.out.printf ("f2.year = %d\n", f2.getYear() );
        System.out.println ();

        f3 = new Fecha ( 2025 );
        System.out.printf ("f3.dia  = %d\n", f3.getDia());
        System.out.printf ("f3.mes  = %d\n", f3.getMes());
        System.out.printf ("f3.year = %d\n", f3.getYear());
        System.out.println ();

        f4 = new Fecha ( );
        System.out.printf ("f4.dia  = %d\n", f4.getDia());
        System.out.printf ("f4.mes  = %d\n", f4.getMes());
        System.out.printf ("f4.year = %d\n", f4.getYear());
        System.out.printf ("f4.esBisiesto = %s\n", f4.isYearBisiesto() );
        System.out.println ();



        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}