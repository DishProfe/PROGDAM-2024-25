package ejemplos2025;

/**
 *
 * @author diosdado
 */
public class Fecha {

    // ------------------------------------------------------
    //                   Atributos de clase
    // ------------------------------------------------------
    // Atributos de clase constantes y p�blicos
    public static final int MIN_MES = 1;
    public static final int MAX_MES = 12;
    public static final int MIN_DIA = 1;
    public static final int MAX_YEAR = 2100;
    public static final int MIN_YEAR = -8_000;

    // ------------------------------------------------------
    //             Atributos de objeto (todos privados)
    // ------------------------------------------------------
    private int dia;
    private int mes;
    private int year;

    // ------------------------------------------------------
    //                     Constructores
    // ------------------------------------------------------
    public Fecha(int dia, int mes, int year) throws IllegalArgumentException {

        // Comprobamos que los par�metros de creaci�n del objeto son apropiados
        if (mes < Fecha.MIN_MES || mes > Fecha.MAX_MES) {
            throw new IllegalArgumentException("Mes incorrecto: " + mes);
        }
        if (dia < Fecha.MIN_DIA || dia > Fecha.numDiasMes(mes, year)) {
            throw new IllegalArgumentException("D�a incorrecto: " + dia);
        }
        if (year < Fecha.MIN_YEAR || year > Fecha.MAX_YEAR) {
            throw new IllegalArgumentException("A�o incorrecto: " + year);
        }

        // Si todo ha ido bien: inicializamos los atributos del objeto
        this.dia = dia;
        this.mes = mes;
        this.year = year;
    }

    public Fecha(int mes, int year) throws IllegalArgumentException {
        this(Fecha.MIN_DIA, mes, year);
    }

    public Fecha(int year) {
        this(Fecha.MIN_DIA, Fecha.MIN_MES, year);
    }

    public Fecha() {
        this(1, 1, 2089);
    }

    // ------------------------------------------------------
    //                   M�todos f�brica
    // ------------------------------------------------------
    public Fecha of (int dia, int mes, int year) throws IllegalArgumentException {
        return new Fecha (dia, mes, year);
    }
    
    
    // ------------------------------------------------------
    //         M�todos de consulta (getters)
    // ------------------------------------------------------
    public int getDia() {
        return this.dia;
    }

    public int getMes() {
        return this.mes;
    }

    public int getYear() {
        return this.year;
    }

    public boolean isYearBisiesto() {
        return Fecha.isBisiesto(this.year);
    }

    // ------------------------------------------------------
    //            M�TODOS DE MODIFICACI�N: SETTERS
    // ------------------------------------------------------
    // setDia
    public void setDia(int dia) throws IllegalArgumentException {
        int diaMes = Fecha.numDiasMes(this.mes, this.year);
        if (dia >= Fecha.MIN_DIA && dia <= diaMes) {
            this.dia = dia;
        } else {
            throw new IllegalArgumentException("D�a incorrecto: " + dia);
        }
    }

    // setMes 
    public void setMes(int mes) throws IllegalArgumentException {
        if (mes >= Fecha.MIN_MES && mes <= Fecha.MAX_MES) {
            this.mes = mes;
        } else {
            throw new IllegalArgumentException("Mes incorrecto: " + mes);
        }
    }

    // setYear
    // ------------------------------------------------------
    //                M�TODOS DE "ACCI�N"
    // ------------------------------------------------------
    // sumar1Dia
    public void sumar1Dia() throws IllegalStateException {
        int diasMes = Fecha.numDiasMes(this.mes, this.year);

        if (this.dia == diasMes) {    // Si hemos alcanzado el m�ximo d�a del mes
            this.dia = Fecha.MIN_DIA;   // Volvemos a d�a 1 (del mes siguiente)
            if (this.mes == Fecha.MAX_MES) { // Si hemos alcanzado el m�ximo mes del a�o
                this.mes = Fecha.MIN_MES;   // Volvemos al mes 1 (del a�o siguiente)
                if (year == Fecha.MAX_YEAR) { // Si superamos el a�o m�ximo, se lanza excepci�n
                    throw new IllegalStateException(
                            String.format("Superado el a�o m�ximo: %d", Fecha.MAX_YEAR)
                    );
                }
                this.year++;    // Si no se supera el a�o m�ximo: incrementamos el a�o
            } else {    // Si no hemos alcanzado el m�ximo mes
                this.mes++; // Incrementamos el mes
            }
        } else {    // Si no hemos alcanzado el m�ximo d�a
            this.dia++;  // Incrementamos el d�a
        }
    }

    // sumar1Mes
    public void sumar1Mes() throws IllegalStateException {
        if (this.mes == Fecha.MAX_MES) { // Si hemos alcanzado el m�ximo mes del a�o
            this.mes = Fecha.MIN_MES;   // Volvemos al mes 1 (del a�o siguiente)
            if (year == Fecha.MAX_YEAR) { // Si superamos el a�o m�ximo, se lanza excepci�n
                throw new IllegalStateException(
                        String.format("Superado el a�o m�ximo: %d", Fecha.MAX_YEAR)
                );
            }
            this.year++;    // Incrementamos el a�o
        } else {    // Si no hemos alcanzado el m�ximo mes
            this.mes++; // Incrementamos el mes
        }

        // Si nos hemos pasado del d�a m�ximo de ese mes
        // Ajustamos al d�a m�ximo del mes
        int numDiasMes = Fecha.numDiasMes(this.mes, this.year);
        if (this.dia > numDiasMes) {
            this.dia = numDiasMes;
        }
    }

    // ------------------------------------------------------
    //         M�TODOS EST�TICOS "HERRAMIENTA"  
    // ------------------------------------------------------
    // numDiasMes
    public static int numDiasMes(int mes, int year) {
        int diasMes;
        switch (mes) {
            // Enero, marzo, mayo, julio, agosto, octubre, diciembre
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                diasMes = 31;
                break;
            // Abril, junio, septiembre, noviembre    
            case 4:
            case 6:
            case 9:
            case 11:
                diasMes = 30;
                break;
            // Febrero    
            default:
                if (isBisiesto(year)) {
                    diasMes = 29;
                } else {
                    diasMes = 28;
                }
        }
        return diasMes;
    }

    // isBisiesto
    public static boolean isBisiesto(int year) {
        return year % 4 == 0;
    }

}
