package ejemplos2024Strings;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class RepasoPatronNumeros02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String entrada;
        
        
        // Variables de salida
        boolean formatoValido = false;
        boolean entradaValida = false;
        String textoError="";
        
        
        String numHexLeido, numDecLeido, numBinLeido;
        
        // Variables auxiliares
        String patronEntrada = "([A-F0-9]{1,4})-([01]{1,16})-([0-9]{1,5})";
        Pattern patternEntrada = Pattern.compile (patronEntrada);
        Matcher matcherEntrada = null;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EXPRESIONES REGULARES: RECONOCIMIENTO DE PATRONES");
        System.out.println("-------------------------------------------------");
        System.out.println("Patrón: <número hexadecimal>-<número binario>-<número decimal>");

        do {
            System.out.println("Introduzca una cadena con el formato especificado: ");
            entrada = teclado.nextLine();
            
            matcherEntrada=  patternEntrada.matcher (entrada.trim());
            formatoValido = matcherEntrada.matches();           
        } while (!formatoValido); // Seguiremos solicitando mientras no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        
        if ( formatoValido ) {  // No debemos intentar extraer grupos si no se ha producido acoplamiento
            numHexLeido = matcherEntrada.group(1) ;
            numBinLeido = matcherEntrada.group(2) ;
            numDecLeido = matcherEntrada.group(3) ;
            
            System.out.printf ("Información extraida del texto: %s, %s, %s\n",
                    numHexLeido, 
                    numBinLeido, 
                    numDecLeido);
            
            
            // Comprobamos que la información contenida en el texto es correcta
            /*entradaValida = Integer.parseInt(numDecLeido) == Integer.parseInt (numHexLeido, 16) && 
                    Integer.parseInt (numHexLeido, 16) == Integer.parseInt(numBinLeido, 2);*/            

            entradaValida = true;
            if ( Integer.parseInt (numHexLeido, 16) != Integer.parseInt(numBinLeido, 2) ) {
                textoError = "El número binario no coincide con el hexadecinal\n";
                entradaValida = false;
            } 
            
            if ( Integer.parseInt (numHexLeido, 16) != Integer.parseInt(numDecLeido) ) {
                textoError += "El número decimal no coincide con el hexadecinal\n";
                entradaValida = false;
            }

        }
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        if ( formatoValido ) {
            System.out.println ("Formato válido.");
            if ( entradaValida ) {
                System.out.println ("Entrada válida");
            } else {
                System.out.println ("Entrada no válida");    
                System.out.println (textoError);
            }
        } else {
            System.out.println ("Formato no válido.");            
        }
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}