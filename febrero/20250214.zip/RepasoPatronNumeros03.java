package ejemplos2024Strings;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class RepasoPatronNumeros03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String entrada;
        
        
        // Variables de salida
        boolean formatoValido = false;
        boolean entradaValida = false;
        String textoError = "";
        
        
        String numBinLeido, numUnosLeido;
        
        // Variables auxiliares
        String patronEntrada = "([01]{1,64})-([0-9]{1,2})";
        Pattern patternEntrada = Pattern.compile (patronEntrada);
        Matcher matcherEntrada = null;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EXPRESIONES REGULARES: RECONOCIMIENTO DE PATRONES");
        System.out.println("-------------------------------------------------");
        System.out.println("Patrón: <número binario>-<cantidad de unos>");

        do {
            System.out.println("Introduzca una cadena con el formato especificado: ");
            entrada = teclado.nextLine();
            
            matcherEntrada=  patternEntrada.matcher (entrada.trim());
            formatoValido = matcherEntrada.matches();           
        } while (!formatoValido); // Seguiremos solicitando mientras no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        
        if ( formatoValido ) {  // No debemos intentar extraer grupos si no se ha producido acoplamiento
            numBinLeido = matcherEntrada.group(1) ;
            numUnosLeido = matcherEntrada.group(2) ;
            
            System.out.printf ("Información extraida del texto: %s, %s\n",
                    numBinLeido, 
                    numUnosLeido);
            
            
            // Comprobamos que la información contenida en el texto es correcta
            int numUnosCalculado = 0;
            for ( int indice=0; indice<numBinLeido.length() ; indice++ ) {
                if (numBinLeido.charAt(indice) == '1') {
                    numUnosCalculado++;
                }
            }
    
            /*
            entradaValida = numUnosCalculado == Integer.parseInt(numUnosLeido);            
            */
            
            entradaValida = true;
            if ( numUnosCalculado != Integer.parseInt(numUnosLeido) ) {
                textoError = "Número de unos incorrecto.";
                entradaValida = false;
            }             
        }
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        if ( formatoValido ) {
            System.out.println ("Formato válido.");
            if ( entradaValida ) {
                System.out.println ("Entrada válida");
            } else {
                System.out.println ("Entrada no válida");  
                System.out.println (textoError);
            }
        } else {
            System.out.println ("Formato no válido.");            
        }
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}