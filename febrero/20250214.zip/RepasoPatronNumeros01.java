package ejemplos2024Strings;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class RepasoPatronNumeros01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String entrada;
        
        
        // Variables de salida
        boolean formatoValido = false;
        boolean entradaValida = false;
        String textoError = "";
        
        
        String numHexLeido, cantidadLetrasLeidas, cantidadCifrasLeidas, longTotalLeida;
        int cantidadLetrasCalculadas, cantidadCifrasCalculadas, longTotalCalculada;
        
        // Variables auxiliares
        String patronEntrada = "([A-F0-9]{1,16})-([0-9]{1,2})-([0-9]{1,2})-([0-9]{1,2})";
        Pattern patternEntrada = Pattern.compile (patronEntrada);
        Matcher matcherEntrada = null;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EXPRESIONES REGULARES: RECONOCIMIENTO DE PATRONES");
        System.out.println("-------------------------------------------------");
        System.out.println("Patrón: <número hexadecimal>-<cantidad de letras>-<cantidad de cifras>-<longitud total>");

        do {
            System.out.println("Introduzca una cadena con el formato especificado: ");
            entrada = teclado.nextLine();
            
            matcherEntrada=  patternEntrada.matcher (entrada.trim());
            formatoValido = matcherEntrada.matches();           
        } while (!formatoValido); // Seguiremos solicitando mientras no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        if ( formatoValido ) {  // No debemos intentar extraer grupos si no se ha producido acoplamiento
            numHexLeido = matcherEntrada.group(1) ;
            cantidadLetrasLeidas = matcherEntrada.group(2) ;
            cantidadCifrasLeidas = matcherEntrada.group(3);
            longTotalLeida = matcherEntrada.group(4);
            
            System.out.printf ("Información extraida del texto: %s, %s, %s, %s\n",
                    numHexLeido, 
                    cantidadLetrasLeidas, 
                    cantidadCifrasLeidas, 
                    longTotalLeida);
            
            // Calculamos letras, cifras y total a partir del texto de origen
            cantidadLetrasCalculadas = 0;
            cantidadCifrasCalculadas = 0;
            for ( int indice=0; indice<numHexLeido.length() ; indice++) {
                if (numHexLeido.charAt(indice)>='A' && numHexLeido.charAt(indice)<='Z') {
                    cantidadLetrasCalculadas++;
                } else {
                    cantidadCifrasCalculadas++;
                }
            }
            
            // Comprobamos que la información contenida en el texto es correcta
            /*
            entradaValida = cantidadLetrasCalculadas == Integer.parseInt(cantidadLetrasLeidas) && 
                    cantidadCifrasCalculadas == Integer.parseInt(cantidadCifrasLeidas) &&
                    numHexLeido.length() == Integer.parseInt(longTotalLeida);
            */
             
            entradaValida = true;
            if ( cantidadLetrasCalculadas != Integer.parseInt(cantidadLetrasLeidas) ) {
                textoError = "Número de letras incorrecto.\n";
                entradaValida = false;
            }
            if ( cantidadCifrasCalculadas != Integer.parseInt(cantidadCifrasLeidas) ) {
                textoError += "Número de cifras incorrecto.\n";
                entradaValida = false;                 
            }
            if ( numHexLeido.length() != Integer.parseInt(longTotalLeida) ) {
                textoError += "Número total incorrecto.\n";
                entradaValida = false;                 
            }
            
            
            
             
            
        }
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        if ( formatoValido ) {
            System.out.println ("Formato válido.");
            if ( entradaValida ) {
                System.out.println ("Entrada válida");
            } else {
                System.out.println ("Entrada no válida");  
                System.out.println (textoError);
            }
        } else {
            System.out.println ("Formato no válido.");            
        }
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}