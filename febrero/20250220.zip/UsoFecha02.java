package ejemplos2025;


import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *   Programa
 */

    public class UsoFecha02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares


        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS FECHA");
        System.out.println("--------------------------------");
        System.out.println(" ");

        
        Fecha f1= null, f2, f3, f4;
        int dia = 0;
        
        LocalDate.of (-1,-1,1);
        
        try {
            f1 = new Fecha( -1, 2, 2025 );

            System.out.printf ("f1.dia  = %d\n", f1.getDia() );
            System.out.printf ("f1.mes  = %d\n", f1.getMes() );
            System.out.printf ("f1.year = %d\n", f1.getYear() );
            System.out.printf ("f1.esBisiesto = %s\n", f1.isYearBisiesto() );
        } catch ( IllegalArgumentException ex) {
            System.out.printf ("Error. %s\n", ex.getMessage());
        }


        
        boolean entradaValida;
        do {
            entradaValida = true;
            System.out.println ("Introduzca nuevo d�a: ");
            try {
                dia = teclado.nextInt();
            } catch ( InputMismatchException ex ) {
                System.out.println ("Error: la entrada no es un n�mero entero.");
                teclado.nextLine();
                entradaValida = false;
            }

            if (entradaValida) {
                System.out.printf ("Intentamos cambiar el valor de d�a: f1.setDia(%d)\n", dia);
                try {
                    f1.setDia(dia);
                } catch ( IllegalArgumentException ex ) {
                    System.out.printf ("Error: %s\n", ex.getMessage() );
                    System.out.println ("No se ha llevado a cabo la modificaci�n...");
                    entradaValida = false;
                }
            }

        } while ( !entradaValida );

        System.out.printf ("f1.dia  = %d\n", f1.getDia() );
        System.out.println ();


        System.out.printf ("Probamos f1.sumar1Dia()\n");
        f1.sumar1Dia();
        System.out.println ();
        System.out.printf ("f1.dia  = %d\n", f1.getDia() );
        System.out.printf ("f1.mes  = %d\n", f1.getMes() );
        System.out.printf ("f1.year = %d\n", f1.getYear() );
        System.out.println ();
        
        

        
//        f2 = new Fecha ( 10, 2025 );
//        System.out.printf ("f2.dia  = %d\n", f2.getDia() );
//        System.out.printf ("f2.mes  = %d\n", f2.getMes() );
//        System.out.printf ("f2.year = %d\n", f2.getYear() );
//        System.out.println ();
//
//        f3 = new Fecha ( 2025 );
//        System.out.printf ("f3.dia  = %d\n", f3.getDia());
//        System.out.printf ("f3.mes  = %d\n", f3.getMes());
//        System.out.printf ("f3.year = %d\n", f3.getYear());
//        System.out.println ();
//
//        f4 = new Fecha ( );
//        System.out.printf ("f4.dia  = %d\n", f4.getDia());
//        System.out.printf ("f4.mes  = %d\n", f4.getMes());
//        System.out.printf ("f4.year = %d\n", f4.getYear());
//        System.out.printf ("f4.esBisiesto = %s\n", f4.isYearBisiesto() );
//        System.out.println ();
//


        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}