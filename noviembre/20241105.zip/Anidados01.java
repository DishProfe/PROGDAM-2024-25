package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Anidados01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada

        // Variables de salida

        // Variables auxiliares
        
        // Entrada de datos 
        // ----------------
        System.out.println("BUCLES ANIDADOS");
        System.out.println("---------------");

        
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   
        System.out.println ("1: 1 2 3 4 5");
        System.out.println ("2: 1 2 3 4 5");
        System.out.println ("3: 1 2 3 4 5");
        System.out.println ("4: 1 2 3 4 5");
        System.out.println ("5: 1 2 3 4 5");
        
        
    }

}
