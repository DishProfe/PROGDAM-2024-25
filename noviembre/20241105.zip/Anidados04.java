package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Anidados04 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int filas, columnas;

        // Variables de salida

        // Variables auxiliares
        
        // Entrada de datos 
        // ----------------
        System.out.println("BUCLES ANIDADOS");
        System.out.println("---------------");

        System.out.println ("Introduzca número de filas: ");
        filas = teclado.nextInt();
        
        System.out.println ("Introduzca número de columnas: ");
        columnas = teclado.nextInt();
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   

        for ( int contadorFilas = 1; contadorFilas  <=filas ; contadorFilas++ ) {


            System.out.print ( contadorFilas + ": " );
            for ( int contadorColumnas = 1 ; contadorColumnas <= columnas ; contadorColumnas++ ) {
                System.out.print ( contadorColumnas + " " );                
            }
            System.out.println();
            
        }
     
        System.out.println();
        
    }

}
