package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Anidados03 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int filas;

        // Variables de salida

        // Variables auxiliares
        
        // Entrada de datos 
        // ----------------
        System.out.println("BUCLES ANIDADOS");
        System.out.println("---------------");

        System.out.println ("Introduzca número de filas: ");
        filas = teclado.nextInt();
        
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   

        for ( int contador = 1; contador<=filas ; contador++ ) {
            System.out.println (contador + ": 1 2 3 4 5");
        }
        
    }

}
