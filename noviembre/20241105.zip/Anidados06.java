package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Anidados06 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numFilas, numColumnas;

        // Variables de salida

        // Variables auxiliares
        int contador;
        
        // Entrada de datos 
        // ----------------
        System.out.println("BUCLES ANIDADOS");
        System.out.println("---------------");

        System.out.println ("Introduzca número de filas: ");
        numFilas = teclado.nextInt();
        
        System.out.println ("Introduzca número de columnas: ");
        numColumnas = teclado.nextInt();
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   

        contador = 1;
        for ( int fila = 1; fila  <=numFilas ; fila++ ) {
            System.out.print ( fila + ": " );
            for ( int columna = 1 ; columna <= numColumnas ; columna++ ) {
                System.out.print ( contador + " " );                
                contador++;
            }
            System.out.println();
        }     
        System.out.println();
        
    }

}
