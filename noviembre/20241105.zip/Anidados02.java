package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Anidados02 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada

        // Variables de salida

        // Variables auxiliares
        int contador;
        
        // Entrada de datos 
        // ----------------
        System.out.println("BUCLES ANIDADOS");
        System.out.println("---------------");

        
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   

        for ( contador = 1; contador<=5 ; contador++ ) {
            System.out.println (contador + ": 1 2 3 4 5");
        }
        
    }

}
