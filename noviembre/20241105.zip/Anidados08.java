package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Anidados08 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numFilas, numColumnas;

        // Variables de salida

        // Variables auxiliares
        int fila, columna, contador;
        
        // Entrada de datos 
        // ----------------
        System.out.println("BUCLES ANIDADOS");
        System.out.println("---------------");

        System.out.println ("Introduzca número de filas: ");
        numFilas = teclado.nextInt();
        
        System.out.println ("Introduzca número de columnas: ");
        numColumnas = teclado.nextInt();
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   

        for ( fila = 1, contador=1; fila  <=numFilas ; fila++ ) {
            System.out.print ( fila + ": " );
            for ( columna = 1 ; columna <= numColumnas ; columna++, contador++ ) {
                System.out.print ( contador + " " );                
            }
            System.out.println();
        }     
        System.out.println();
        
    }

}
