
package ejemplos2024;


import java.util.Scanner;
import aguadulce.Dado;

/**
 *   Programa
 */

    public class Dados04 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Dado d1, d2;
        


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS DADO");
        System.out.println("-------------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        System.out.println ("Info general: ");
        System.out.println ("Cantidad de dados creados: " + Dado.getNumeroDadosCreados() );
        System.out.println ("Cantidad de veces lanzados todos los dados: " + Dado.getNumeroLanzamientosGlobal());
        System.out.println ();
        
        
        System.out.println ("Creamos d1");
        d1 = new Dado (4);
        System.out.println ();
        
        System.out.println ("Creamos d2");
        d2 = new Dado ();
        System.out.println ();


        System.out.println ("Info de d1: ");
        System.out.println ("Número de caras: " + d1.getNumeroCaras() );
        System.out.println ("Número de veces lanzado: " + d1.getNumeroLanzamientos());
        System.out.println ("Suma de puntos obtenidos desde que se creó el dado: " + d1.getSumaPuntuacionHistorica() );
        System.out.println ("Todo lo que ha salido desde que se creó el dado: " + d1.getSerieHistoricaLanzamientos() );
        System.out.println ();
        
        System.out.println ("Info de d2: ");
        System.out.println ("Número de caras: " + d2.getNumeroCaras() );
        System.out.println ("Número de veces lanzado: " + d2.getNumeroLanzamientos());
        System.out.println ("Suma de puntos obtenidos desde que se creó el dado: " + d2.getSumaPuntuacionHistorica() );
        System.out.println ("Todo lo que ha salido desde que se creó el dado: " + d2.getSerieHistoricaLanzamientos() );
        System.out.println ();
        
        System.out.println ("Lanzamos d1 diez veces");
        for (int contador=1 ; contador<=10 ; contador++ ) {
            String lanzamiento = d1.lanzar();
            System.out.println (lanzamiento);
        }
        System.out.println ();

        System.out.println ("Lanzamos d2 diez veces");
        for (int contador=1 ; contador<=10 ; contador++ ) {
            String lanzamiento = d2.lanzar();
            System.out.println (lanzamiento);
        }
        System.out.println ();


        System.out.println ("Info de d1: ");
        System.out.println ("Número de caras: " + d1.getNumeroCaras() );
        System.out.println ("Número de veces lanzado: " + d1.getNumeroLanzamientos());
        System.out.println ("Suma de puntos obtenidos desde que se creó el dado: " + d1.getSumaPuntuacionHistorica() );
        System.out.println ("Todo lo que ha salido desde que se creó el dado: " + d1.getSerieHistoricaLanzamientos() );
        for ( int cara=  1   ; cara <= d1.getNumeroCaras()  ; cara++  ) {
            System.out.println ( cara + " ha salido " + d1.getNumeroVecesCara(cara) + " veces");
        }
        System.out.println ();
        
        System.out.println ("Info de d2: ");
        System.out.println ("Número de caras: " + d2.getNumeroCaras() );
        System.out.println ("Número de veces lanzado: " + d2.getNumeroLanzamientos());
        System.out.println ("Suma de puntos obtenidos desde que se creó el dado: " + d2.getSumaPuntuacionHistorica() );
        System.out.println ("Todo lo que ha salido desde que se creó el dado: " + d2.getSerieHistoricaLanzamientos() );
        for ( int cara=  1   ; cara <= d2.getNumeroCaras()  ; cara++  ) {
            System.out.println ( cara + " ha salido " + d2.getNumeroVecesCara(cara) + " veces");
        }
        System.out.println ();

        
        System.out.println ();
        System.out.println ("Info general: ");
        System.out.println ("Cantidad de dados creados: " + Dado.getNumeroDadosCreados() );
        System.out.println ("Cantidad de veces lanzados todos los dados: " + Dado.getNumeroLanzamientosGlobal());


        System.out.println ();
        System.out.println ("Lanzamos d1 otras diez veces");
        for (int contador=1 ; contador<=10 ; contador++ ) {
            String lanzamiento = d1.lanzar();
            System.out.println (lanzamiento);
        }

        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------

        System.out.println ("Info de d1: ");
        System.out.println ("Número de caras: " + d1.getNumeroCaras() );
        System.out.println ("Número de veces lanzado: " + d1.getNumeroLanzamientos());
        System.out.println ("Suma de puntos obtenidos desde que se creó el dado: " + d1.getSumaPuntuacionHistorica() );
        System.out.println ("Todo lo que ha salido desde que se creó el dado: " + d1.getSerieHistoricaLanzamientos() );
        for ( int cara=  1   ; cara <= d1.getNumeroCaras()  ; cara++  ) {
            System.out.println ( cara + " ha salido " + d1.getNumeroVecesCara(cara) + " veces");
        }
        System.out.println ();
        
        System.out.println ("Info de d2: ");
        System.out.println ("Número de caras: " + d2.getNumeroCaras() );
        System.out.println ("Número de veces lanzado: " + d2.getNumeroLanzamientos());
        System.out.println ("Suma de puntos obtenidos desde que se creó el dado: " + d2.getSumaPuntuacionHistorica() );
        System.out.println ("Todo lo que ha salido desde que se creó el dado: " + d2.getSerieHistoricaLanzamientos() );
        for ( int cara=  1   ; cara <= d2.getNumeroCaras()  ; cara++  ) {
            System.out.println ( cara + " ha salido " + d2.getNumeroVecesCara(cara) + " veces");
        }
        System.out.println ();
        
        
        System.out.println ();
        System.out.println ("Info general: ");
        System.out.println ("Cantidad de dados creados: " + Dado.getNumeroDadosCreados() );
        System.out.println ("Cantidad de veces lanzados todos los dados: " + Dado.getNumeroLanzamientosGlobal());
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}