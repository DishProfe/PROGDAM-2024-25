package ejemplos2024;

import java.time.LocalDate;
import java.time.DayOfWeek;
import java.util.Scanner;

/**
 *   Ejemplos con la clase Rectangle
 */

    public class BuscadorLunes01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int mes;
        
        
        // Variables de salida



        // Variables auxiliares
        LocalDate fecha1, fecha2, fecha3, fecha4;
        int year;
        int numDiasMes;
        
        
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BUSCADOR DE LUNES");
        System.out.println("-----------------");
        do {
            System.out.println("Introduzca mes (1-12)");
            mes = teclado.nextInt();
        } while ( mes<1 || mes>12 );

        
        //----------------------------------------------
        //                 Procesamiento 
        //                      +
        //              Salida de resultados 
        //----------------------------------------------
        year = LocalDate.now().getYear();
        numDiasMes = LocalDate.of (year, mes, 1).lengthOfMonth();
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
	System.out.println ("Lunes del mes " + mes + " del año actual " + year + ": ");

        for (int dia = 1 ; dia <= numDiasMes; dia++ ) {
            LocalDate fecha = LocalDate.of (year, mes, dia);
            if ( fecha.getDayOfWeek() == DayOfWeek.MONDAY ) {
                System.out.println (dia);
            }
        }

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}