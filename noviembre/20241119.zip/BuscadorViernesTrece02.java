package ejemplos2024;

import java.time.LocalDate;
import java.time.DayOfWeek;
import java.util.Scanner;

/**
 *   Ejemplos con la clase Rectangle
 */

    public class BuscadorViernesTrece02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int year;
        
        
        // Variables de salida



        // Variables auxiliares
        LocalDate fecha;
        
        
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BUSCADOR DE VIERNES 13");
        System.out.println("----------------------");
        do {
            System.out.println("Introduzca año (1900-2100)");
            year = teclado.nextInt();
        } while ( year<1900 || year>2100 );

        
        //----------------------------------------------
        //                 Procesamiento 
        //                      +
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        fecha = LocalDate.of (year, 1, 13);
        while ( fecha.getYear() == year ) {
            if ( fecha.getDayOfWeek() == DayOfWeek.FRIDAY) {
                System.out.println (fecha);
            }
            fecha = fecha.plusMonths(1);
        }

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}