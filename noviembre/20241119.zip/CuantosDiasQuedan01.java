package ejemplos2024;

import java.time.LocalDate;
import java.time.DayOfWeek;
import java.util.Scanner;

/**
 *   Ejemplos con la clase Rectangle
 */

    public class CuantosDiasQuedan01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int year;
        
        
        // Variables de salida
        int diasParaFinSemana=0;
        int diasParaFinMes;
        int diasParaFinYear;



        // Variables auxiliares
        LocalDate fechaActual;
        
        
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CUÁNTOS DÍAS QUEDAN");
        System.out.println("-------------------");
        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        fechaActual = LocalDate.now();
        switch ( fechaActual.getDayOfWeek() ) {
            case SATURDAY:
            case SUNDAY:
                diasParaFinSemana = 0;
                break;
            case FRIDAY:
                diasParaFinSemana = 0;
                break;
            case THURSDAY:
                diasParaFinSemana = 1;
                break;
            case WEDNESDAY:
                diasParaFinSemana = 2;
                break;
            case TUESDAY:
                diasParaFinSemana = 3;
                break;
            case MONDAY:
                diasParaFinSemana = 4;
                break;                
        }
        
        diasParaFinMes = fechaActual.lengthOfMonth() - fechaActual.getDayOfMonth();
        
        diasParaFinYear = fechaActual.lengthOfYear() - fechaActual.getDayOfYear();
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println ("Fecha actual: " + fechaActual.toString() + " " + fechaActual.getDayOfWeek() );
        System.out.println ("Días que faltan para el fin de semana: " + diasParaFinSemana );
        System.out.println ("Días que faltan para el fin de mes: " + diasParaFinMes );
        System.out.println ("Días que faltan para el fin de año: " + diasParaFinYear );
        

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}