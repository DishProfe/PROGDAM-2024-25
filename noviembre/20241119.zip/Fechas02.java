package ejemplos2024;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *   Ejemplos con la clase Rectangle
 */

    public class Fechas02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        LocalDate fecha1, fecha2, fecha3, fecha4;
        
        
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS LOCALDATE");
        System.out.println("------------------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        System.out.println ("Creando objeto fecha1 con método fábrica of()");
        fecha1 = LocalDate.of (2024, 9, 15);   
                
        System.out.println ("Creando objeto fecha2 con método fábrica now()");
        fecha2 = LocalDate.now();   
        
        System.out.println ("Creando objeto fecha3 con método fábrica parse()");
        fecha3 = LocalDate.parse("2025-06-22");   
        
        System.out.println ("fecha3 recién creada: " + fecha3.toString() );
        System.out.println ("Incementamos fecha3 en 2 días:");
        fecha3 = fecha3.plusDays(2);
        System.out.println ("fecha3: " + fecha3.toString() );
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println ("fecha1.dia=" + fecha1.getDayOfMonth() );
        System.out.println ("fecha1.mes=" + fecha1.getMonthValue() );
        System.out.println ("fecha1.año=" + fecha1.getYear() );
        System.out.println ("fecha1 con toString()=" + fecha1.toString() );
        System.out.println ("fecha2 con toString()=" + fecha2.toString() );
        System.out.println ("fecha3 con toString()=" + fecha3.toString() );


        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}