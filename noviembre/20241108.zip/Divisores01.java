package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Divisores01 {

     public static void main(String[] args) {
     
        // Declaración de variables
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);
        
        // Variables de entrada
        long numero;

        // Variable de salida
        long posibleDivisor;
         
         // Variables auxiliares
         
         
        // Entrada de datos 
        // ----------------

        System.out.println("CÁLCULO DE DIVISORES");
        System.out.println("--------------------");

        System.out.println ("Introduzca número entero: ");
        numero = teclado.nextInt();
         
        // Procesamiento + Salida de Resultados
        // ------------------------------------
        posibleDivisor = 1;
        while ( posibleDivisor <= numero ) {
            if ( numero % posibleDivisor == 0 ) {
                System.out.print ( posibleDivisor + " ");
            }
            posibleDivisor++;
        }
        System.out.println ();
        
         
     
     }
    
}
