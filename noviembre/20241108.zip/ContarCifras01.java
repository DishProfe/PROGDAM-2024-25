package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class ContarCifras01 {

     public static void main(String[] args) {
     
        // Declaración de variables
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);
        
         // Variables de entrada
         long numero;

         // Variable de salida
         int cifras;
     
         // Variables auxiliares
         long residuo;
         
        // Entrada de datos 
        // ----------------

        System.out.println("CÁLCULO DEL NÚMERO DE CIFRAS");
        System.out.println("----------------------------");

        System.out.println ("Introduzca número entero: ");
        numero = teclado.nextInt();
         
        // Procesamiento
        // -------------
        cifras = 0;
        residuo = numero;
        do {
            residuo = residuo / 10;
            cifras++;            
        } while ( residuo > 0 );
        
        // Salida de resultados
        // --------------------
        System.out.println ("El número de cifras es: " + cifras);
        
         
     
     }
    
}
