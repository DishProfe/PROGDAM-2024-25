package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class SentenciaContinueCorregida01 {

     public static void main(String[] args) {
        // Declaración de variables
        int contador;
        //Procesamiento y salida de información    
	System.out.println ("Imprimiendo los números pares que hay del 1 al 10... "); 
        for (contador=1;contador<=10;contador++){
            if (contador % 2 == 0) {
		System.out.print(contador + " ");         
            }
        }
        System.out.println ("\nFin del programa");   
        /* Las iteraciones del bucle que generarán la impresión de cada uno de los números
         * pares, serán aquellas en las que el resultado de calcular el resto de la división
         * entre 2 de cada valor de la variable contador, sea igual a 0.
         */
    }
    
}
