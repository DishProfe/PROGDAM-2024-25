package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Divisores03 {

     public static void main(String[] args) {
     
        // Declaración de variables
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);
        
        // Variables de entrada
        long numero;

        // Variable de salida
        int numDivisores;
        
        // Variables auxiliares
        long posibleDivisor;
         
         
        // Entrada de datos 
        // ----------------

        System.out.println("CÁLCULO DE DIVISORES");
        System.out.println("--------------------");

        System.out.println ("Introduzca número entero: ");
        numero = teclado.nextInt();
         
        // Procesamiento 
        // --------------
        numDivisores = 0;
        for ( posibleDivisor = 2 ; posibleDivisor < numero ; posibleDivisor++ ) {
            if ( numero % posibleDivisor == 0 ) {
                numDivisores++;
            }
        }
        System.out.println ();
        
        // Salida de Resultados
        // --------------------
        System.out.println ("El número de divisores es: " + numDivisores);
        
        
     }
    
}
