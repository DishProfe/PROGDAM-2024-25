package ejemplos2024;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import java.util.Scanner;

/**
 *   Ejemplos con la clase Rectangle
 */

    public class Edad01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int dia, mes, year;
        
        
        // Variables de salida
        int edad;
        int edadMeses, edadSemanas, edadDias, edadDecadas;



        // Variables auxiliares
        LocalDate fechaActual;
        LocalDate fechaNacimiento;
        
        
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CALCULADORA DE EDAD");
        System.out.println("-------------------");
        System.out.println("Introduzca fecha de nacimiento: día, mes, año");
        dia = teclado.nextInt();
        mes = teclado.nextInt();
        year = teclado.nextInt();
        

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        // Obtenemos la fecha actual
        fechaActual = LocalDate.now();
        
        // Creamos un objeto con la fecha de nacimiento
        fechaNacimiento = LocalDate.of (year, mes, dia);
        
        edad = (int) fechaNacimiento.until ( fechaActual, ChronoUnit.YEARS );
        edadMeses = (int) fechaNacimiento.until ( fechaActual, ChronoUnit.MONTHS );
        edadSemanas = (int) fechaNacimiento.until ( fechaActual, ChronoUnit.WEEKS );
        edadDias = (int) fechaNacimiento.until ( fechaActual, ChronoUnit.DAYS );
        edadDecadas = (int) fechaNacimiento.until ( fechaActual, ChronoUnit.DECADES );
        
        
        

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println ("La edad en años es " + edad);
        System.out.println ("La edad en meses es " + edadMeses);
        System.out.println ("La edad en semanas es " + edadSemanas);
        System.out.println ("La edad en días es " + edadDias);
        System.out.println ("La edad en décadas es " + edadDecadas);

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}