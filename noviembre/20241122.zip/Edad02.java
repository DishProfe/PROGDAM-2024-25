package ejemplos2024;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.DateTimeException;

import java.util.Scanner;

/**
 *   Ejemplos con la clase Rectangle
 */

    public class Edad02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int dia, mes, year;
        
        
        // Variables de salida
        int edad;
        int edadMeses, edadSemanas, edadDias, edadDecadas;



        // Variables auxiliares
        LocalDate fechaActual;
        LocalDate fechaNacimiento = null;
        boolean fechaValida;
        
        
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CALCULADORA DE EDAD");
        System.out.println("-------------------");
        do {
            fechaValida = true;
            System.out.println("Introduzca fecha de nacimiento: día, mes, año");
            dia = teclado.nextInt();
            mes = teclado.nextInt();
            year = teclado.nextInt();
            // Intentamos crear fecha de nacimiento con los datos recibidos
            try {
                fechaNacimiento = LocalDate.of (year, mes, dia);
            } catch ( DateTimeException ex ) {
                System.out.println ("Fecha no válida: ");
                fechaValida = false;
            } 
        } while ( !fechaValida );
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        // Obtenemos la fecha actual
        fechaActual = LocalDate.now();
        
        // Creamos un objeto con la fecha de nacimiento
        
        
        
        
        edad = (int) fechaNacimiento.until ( fechaActual, ChronoUnit.YEARS );
        edadMeses = (int) fechaNacimiento.until ( fechaActual, ChronoUnit.MONTHS );
        edadSemanas = (int) fechaNacimiento.until ( fechaActual, ChronoUnit.WEEKS );
        edadDias = (int) fechaNacimiento.until ( fechaActual, ChronoUnit.DAYS );
        edadDecadas = (int) fechaNacimiento.until ( fechaActual, ChronoUnit.DECADES );
        
        String cadena;
        

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println ("La edad en años es " + edad);
        System.out.println ("La edad en meses es " + edadMeses);
        System.out.println ("La edad en semanas es " + edadSemanas);
        System.out.println ("La edad en días es " + edadDias);
        System.out.println ("La edad en décadas es " + edadDecadas);

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}