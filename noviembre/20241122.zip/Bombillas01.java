package ejemplos2024;

import aguadulce.Bombilla;
import java.util.Scanner;

/**
 *   Ejemplos con la clase Rectangle
 */

    public class Bombillas01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Bombilla b1, b2, b3, b4;
        
        
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE OBJETOS BOMBILLA");
        System.out.println("-----------------------------");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        System.out.println ("Número de bombillas creadas hasta el momento: " +
                Bombilla.getBombillasCreadas());
        System.out.println ("Número de bombillas encendidas en este momento: " +
                Bombilla.getBombillasEncendidas());
        System.out.println ();
        
        System.out.println ("Creamos b1 con valores por omisión");
        b1= new Bombilla();
        System.out.println ("b1 = " + b1.toString() );
        System.out.println ("Potencia de b1: " + b1.getPotencia());
        System.out.println ("Encendemos b1");
        b1.encender();
        System.out.println ( "b1 = " + b1.toString() );
        System.out.println ("Apagamos b1");
        b1.apagar();
        System.out.println ( "b1 = " + b1.toString() );
        System.out.println ("Encendemos b1");
        b1.encender();
        System.out.println ( "b1 = " + b1.toString() );

        System.out.println ("Creamos b2 con valores por omisión");
        b1= new Bombilla();
        
        
        
        System.out.println ("Número de bombillas creadas hasta el momento: " +
                Bombilla.getBombillasCreadas());
        System.out.println ("Número de bombillas encendidas en este momento: " +
                Bombilla.getBombillasEncendidas());
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");

        
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}