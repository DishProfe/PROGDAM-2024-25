
package ejemplos2024;


import java.util.Scanner;

/**
 *   Programa
 */

    public class Aleatorios05 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int numFilas, numColumnas;
        
        
        // Variables de salida
        double numAleatorio;



        // Variables auxiliares
        


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE NÚMEROS ALEATORIOS");
        System.out.println("------------------------------");
        do {
            System.out.println ("Número de filas (1-10): ");
            numFilas = teclado.nextInt();
        } while ( numFilas<1 || numFilas>10 );
        
        do {
            System.out.println ("Número de columnas (1-10): ");
            numColumnas = teclado.nextInt();
        } while ( numColumnas<1 || numColumnas>10 );


        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Marco superior
        // Esquina superior izquierda (+)
        System.out.print ("+");

        // Barra superior
        for ( int contador = 1 ; contador <= numColumnas ; contador ++ ) {
            System.out.print ("-------");
        }

        // Esquina superior derecha (+)
        System.out.println ("+");


        // Recorremos cada fila
        for ( int fila = 1 ; fila <=numFilas ; fila ++ ) {

            // Marco lateral iquierdo (|) al comienzo de cada fila
            System.out.print ("|");

            // Dentro de cada fila, recorremos cada columna
            // Pintamos tres aleatorios (uno por columna) por cada fila
            for (int columna = 1 ; columna<=numColumnas; columna++ ) {
                numAleatorio = Math.random()*20;
                System.out.printf (" %05.2f ", numAleatorio);
            }

            // Marco lateral derecho (|) al final de cada fila
            System.out.print ("|");
            // Avance de línea para la siguiente fila
            System.out.println ();        
        }
        
        // Marco inferior
        // Esquina inferior izquierda (+)
        System.out.print ("+");

        // Barra inferior
        for ( int contador = 1 ; contador <= numColumnas ; contador ++ ) {
            System.out.print ("-------");
        }

        // Esquina inferior derecha (+)
        System.out.println ("+");

        

        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------


        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}