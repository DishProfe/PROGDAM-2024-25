
package ejemplos2024;


import java.util.Scanner;
import aguadulce.Dado;
import aguadulce.CuentaBancaria;

/**
 *   Programa
 */

    public class DadosPrimos05 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Dado dado1, dado2, dado3;
        CuentaBancaria cuenta1, cuenta2, cuenta3;
        String tirada1, tirada2, tirada3;
        long tirada1num, tirada2num, tirada3num;
        boolean tirada1esPrimo, tirada2esPrimo, tirada3esPrimo;
        boolean finRonda;
        int contadorTiradas;
        int posibleDivisor;
        int ganador;
        long puntos1, puntos2, puntos3;
        


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("JUEGOS CON DADOS");
        System.out.println("----------------");
        System.out.println();

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        dado1 = new Dado (20);
        cuenta1 = new CuentaBancaria (200);
        
        dado2 = new Dado (20);
        cuenta2 = new CuentaBancaria (200);

        dado3 = new Dado (20);
        cuenta3 = new CuentaBancaria (200);
        
        contadorTiradas = 1;
        finRonda = false;
        
        puntos1 = 0;
        puntos2 = 0;
        puntos3 = 0;

        System.out.printf ("Probando formatos: %5d\n", 12);
        
        do {
            tirada1num = dado1.getSumaPuntuacionHistorica();
            tirada2num = dado2.getSumaPuntuacionHistorica();
            tirada3num = dado3.getSumaPuntuacionHistorica();
            
            tirada1 = dado1.lanzar();
            tirada2 = dado2.lanzar();
            tirada3 = dado3.lanzar();        

            tirada1num = dado1.getSumaPuntuacionHistorica() - tirada1num;
            tirada2num = dado2.getSumaPuntuacionHistorica() - tirada2num;
            tirada3num = dado3.getSumaPuntuacionHistorica() - tirada3num;

            puntos1 += tirada1num;
            puntos2 += tirada2num;
            puntos3 += tirada3num;
            
/*            
            System.out.println (contadorTiradas + ": " + tirada1 + " (" + tirada1num + ") "
                    + " " + tirada2 + " (" + tirada2num + ") "  
                    + " " + tirada3 + " (" + tirada3num + ") " );
*/
            //System.out.println (contadorTiradas + ": " + tirada1 + " (" + tirada1num + ") ");

            System.out.printf ("Tirada %2d: %-12s (%2d) - %-12s (%2d) - %-12s (%2d)\n", 
                    contadorTiradas, 
                    tirada1, tirada1num,
                    tirada2, tirada2num,
                    tirada3, tirada3num);
            


            contadorTiradas++;
            
            // Comprobar si tirada1 es primo
            posibleDivisor = 2;
            tirada1esPrimo= true;
            while ( tirada1esPrimo && posibleDivisor<=(int)Math.sqrt(tirada1num) ) {
                if ( tirada1num % posibleDivisor == 0 ) {
                    tirada1esPrimo = false;
                }
                posibleDivisor++;
            }
            
            // Comprobar si tirada2 es primo
            posibleDivisor = 2;
            tirada2esPrimo= true;
            while ( tirada2esPrimo && posibleDivisor<=(int)Math.sqrt(tirada2num) ) {
                if ( tirada2num % posibleDivisor == 0 ) {
                    tirada2esPrimo = false;
                }
                posibleDivisor++;
            }
            
            
            // Comprobar si tirada3 es primo
            posibleDivisor = 2;
            tirada3esPrimo= true;
            while ( tirada3esPrimo && posibleDivisor<=(int)Math.sqrt(tirada3num) ) {
                if ( tirada3num % posibleDivisor == 0 ) {
                    tirada3esPrimo = false;
                }
                posibleDivisor++;
            }
            
            finRonda = tirada1esPrimo && tirada2esPrimo && tirada3esPrimo;
            
        } while (!finRonda);

        // Fin de ronda
        // Mostramos los puntos de cada jugador en la ronda        
        System.out.println ("Puntos jugador 1 : " + puntos1);
        System.out.println ("Puntos jugador 2 : " + puntos2);
        System.out.println ("Puntos jugador 3 : " + puntos3);
        
        // Calculamos quien ha ganado la ronda
        long puntosGanador;
        // Calculamos el ganador entre 1 y 2
        if ( puntos1 > puntos2 ) {
            ganador = 1;
            puntosGanador = puntos1;
        } else {
            ganador = 2;
            puntosGanador = puntos2;
        }
        // Calculamos el ganador entre el ganador anterior y 3
        if ( puntos3 > puntosGanador ) {
            ganador = 3;
            puntosGanador = puntos3;
        }
        
        // A pagar!!!!!!
        if ( ganador == 1 ) {
            cuenta2.transferir(100.0, cuenta1);
            cuenta3.transferir(100.0, cuenta1);
        } else if ( ganador == 2 ) {
            cuenta1.transferir(100.0, cuenta2);
            cuenta3.transferir(100.0, cuenta2);
        } else {
            cuenta1.transferir(100.0, cuenta3);
            cuenta2.transferir(100.0, cuenta3);            
        }


        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------

        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        System.out.println ("El ganador es " + ganador);
        System.out.println ("con " + puntosGanador + " puntos");
        

	System.out.println ("Estado de las cuentas:");
        System.out.println ("Cuenta 1 : " + cuenta1.toString() );
        System.out.println ("Cuenta 2 : " + cuenta2.toString() );
        System.out.println ("Cuenta 3 : " + cuenta3.toString() );

        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}