
package ejemplos2024;


import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *   Programa
 */

    public class Aleatorios08 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int numFilas = 0, numColumnas = 0;
        
        
        // Variables de salida
        double numAleatorio;



        // Variables auxiliares
        boolean entradaValida;
        


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE NÚMEROS ALEATORIOS");
        System.out.println("------------------------------");
        entradaValida = false;
        do {
            System.out.println ("Número de filas (1-10): ");
            try {
                numFilas = teclado.nextInt();
                if ( numFilas>=1 && numFilas<=10 ) {
                    entradaValida = true;
                }   
            } catch ( InputMismatchException ex ) {
                entradaValida = false;
                String basura = teclado.nextLine();
            }
        } while ( !entradaValida );
        
        entradaValida = false;
        do {
            System.out.println ("Número de columnas (1-10): ");
            try {
                numColumnas = teclado.nextInt();
                if ( numColumnas>=1 && numColumnas<=10 ) {
                    entradaValida = true;
                }   
            } catch ( InputMismatchException ex ) {
                teclado.nextLine();
            }
        } while ( !entradaValida );


        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Marco superior
        System.out.print ("+");
        for ( int contador = 1 ; contador <= numColumnas ; contador ++ ) {
            System.out.print ("-------+");
        }
        System.out.println ();

        // Recorremos cada fila
        for ( int fila = 1 ; fila <=numFilas ; fila ++ ) {

            // Marco lateral iquierdo (|) al comienzo de cada fila
            System.out.print ("|");

            // Dentro de cada fila, recorremos cada columna
            // Pintamos tres aleatorios (uno por columna) por cada fila
            for (int columna = 1 ; columna<=numColumnas; columna++ ) {
                numAleatorio = Math.random()*20;
                System.out.printf (" %05.2f |", numAleatorio);                
            }

            // Avance de línea para la barra inferior
            System.out.println ();        

            // Barra inferior
            System.out.print ("+");
            for ( int contador = 1 ; contador <= numColumnas ; contador ++ ) {
                System.out.print ("-------+");
            }

            // Avance de línea para la siguiente fila
            System.out.println ();        

        }
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------


        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}