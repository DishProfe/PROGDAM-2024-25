
package ejemplos2024;


import java.util.Scanner;
import aguadulce.Dado;

/**
 *   Programa
 */

    public class Aleatorios01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida
        double numAleatorio;



        // Variables auxiliares
        


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE NÚMEROS ALEATORIOS");
        System.out.println("------------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        for (int contador = 1 ; contador<=30; contador++ ) {
            
            numAleatorio = Math.random()*20;
            System.out.println (contador + ": " + numAleatorio);
            
        }
        
        

        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------


        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}