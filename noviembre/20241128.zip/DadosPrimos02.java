
package ejemplos2024;


import java.util.Scanner;
import aguadulce.Dado;
import aguadulce.CuentaBancaria;

/**
 *   Programa
 */

    public class DadosPrimos02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Dado dado1, dado2, dado3;
        CuentaBancaria cuenta1, cuenta2, cuenta3;
        String tirada1, tirada2, tirada3;
        long longTirada1, longTirada2, longTirada3;
        boolean tirada1esPrimo, tirada2esPrimo, tirada3esPrimo;
        boolean finRonda;
        int contadorTiradas;
        int posibleDivisor;
        


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("JUEGOS CON DADOS");
        System.out.println("----------------");
        System.out.println();

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        dado1 = new Dado (20);
        cuenta1 = new CuentaBancaria (200);
        
        dado2 = new Dado (20);
        cuenta2 = new CuentaBancaria (200);

        dado3 = new Dado (20);
        cuenta3 = new CuentaBancaria (200);
        
        contadorTiradas = 1;
        finRonda = false;
        do {
            longTirada1 = dado1.getSumaPuntuacionHistorica();
            longTirada2 = dado2.getSumaPuntuacionHistorica();
            longTirada3 = dado3.getSumaPuntuacionHistorica();
            
            tirada1 = dado1.lanzar();
            tirada2 = dado2.lanzar();
            tirada3 = dado3.lanzar();        

            longTirada1 = dado1.getSumaPuntuacionHistorica() - longTirada1;
            longTirada2 = dado2.getSumaPuntuacionHistorica() - longTirada2;
            longTirada3 = dado3.getSumaPuntuacionHistorica() - longTirada3;


            System.out.println (contadorTiradas + ": " + tirada1 + " (" + longTirada1 + ") "
                    + " " + tirada2 + " (" + longTirada2 + ") "  
                    + " " + tirada2 + " (" + longTirada2 + ") " );
            contadorTiradas++;
            
            // Comprobar si tirada1 es primo
            posibleDivisor = 2;
            tirada1esPrimo= true;
            //while ( tirada1esPrimo && posibleDivisor<tirada1 )
            
            // Comprobar si tirada2 es primo
            posibleDivisor = 2;
            tirada2esPrimo= true;
            
            // Comprobar si tirada3 es primo
            posibleDivisor = 2;
            tirada3esPrimo= true;

            
            finRonda = tirada1esPrimo && tirada2esPrimo && tirada3esPrimo;
            
        } while (!finRonda);
        
        


        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------

        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}