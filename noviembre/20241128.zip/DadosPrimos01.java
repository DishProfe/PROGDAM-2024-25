
package ejemplos2024;


import java.util.Scanner;
import aguadulce.Dado;
import aguadulce.CuentaBancaria;

/**
 *   Programa
 */

    public class DadosPrimos01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Dado dado1, dado2, dado3;
        CuentaBancaria cuenta1, cuenta2, cuenta3;
        String tirada1, tirada2, tirada3;
        


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("JUEGOS CON DADOS");
        System.out.println("----------------");
        System.out.println();

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        dado1 = new Dado (20);
        cuenta1 = new CuentaBancaria (200);
        
        dado2 = new Dado (20);
        cuenta2 = new CuentaBancaria (200);

        dado3 = new Dado (20);
        cuenta3 = new CuentaBancaria (200);
        
        int contadorTiradas = 1;
        do {
            tirada1 = dado1.lanzar();
            tirada2 = dado1.lanzar();
            tirada3 = dado1.lanzar();        
            System.out.println (contadorTiradas + ": " + tirada1 + " " + tirada2 + " " + tirada3);
            contadorTiradas++;
                        
        } while (contadorTiradas<=10);
        
        


        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------

        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}