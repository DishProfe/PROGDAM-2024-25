
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Ejex02 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Constantes
        final int VALOR_BLANCAS = 1;
        final int VALOR_ROJAS   = 2;
        final int VALOR_NEGRAS  = 3;
        
        
        // Variables de entrada
        int fichasBlancas, fichasRojas, fichasNegras;       
        
        // Variables de salida
        int puntuacionTotal;
        boolean todasPares, todasImpares;
        boolean algunaPar, algunaImpar;
        int mayorBRN;
        
        
        
        // Variables auxiliares
        int mayorBR;
        

        // Entrada de datos
        // ----------------
        System.out.println ("ANÁLISIS DE FICHAS"); 
        System.out.println ("------------------"); 

        System.out.println ("Introduzca cantidad de fichas BLANCAS, ROJAS y NEGRAS: ");
        fichasBlancas = teclado.nextInt();
        fichasRojas = teclado.nextInt();
        fichasNegras = teclado.nextInt();

        
        // Procesamiento
        // -------------
        // Calulamos la puntuación total
        puntuacionTotal = fichasBlancas*VALOR_BLANCAS + fichasRojas*VALOR_ROJAS + fichasNegras*VALOR_NEGRAS;
        
        // Comprobamos si son todas pares o todas impares (tienen que ser todas: AND)
        todasPares = fichasBlancas%2==0 && fichasRojas%2==0 && fichasNegras%2==0;
        todasImpares = fichasBlancas%2!=0 && fichasRojas%2!=0 && fichasNegras%2!=0;

        // Comprobamos si hay alguna par o impar (basta con ser una: OR)
        algunaPar = fichasBlancas%2==0 || fichasRojas%2==0 || fichasNegras%2==0;
        algunaImpar = fichasBlancas%2!=0 || fichasRojas%2!=0 || fichasNegras%2!=0;
        
        // Calculamos la mayor entre Blancas y Rojas
        mayorBR = fichasBlancas > fichasRojas ? fichasBlancas : fichasRojas;
        // Calculamos la mayor antre la anterior y las Negras (es decir, la mayor de todas)
        mayorBRN = mayorBR > fichasNegras ? mayorBR : fichasNegras;
        
        
        // Salida de resultados
        // --------------------
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        System.out.println ("Puntuación total: " + puntuacionTotal);
        System.out.println ("Los tres paquetes tienen una cantidad de fichas par: " + 
                (todasPares ? "sí" : "no") );
        System.out.println ("Los tres paquetes tienen una cantidad de fichas impar: " + 
                (todasImpares ? "sí" : "no"));
        
        System.out.println ("Alguno de los tres paquetes tiene una cantidad de fichas par: " + 
                (algunaPar ? "sí" : "no"));
        System.out.println ("Alguno de los tres paquetes tiene una cantidad de fichas impar: " + 
                (algunaImpar ? "sí" : "no"));

        System.out.println ("La cantidad de fichas del mayor paquete es: " + mayorBRN);
        
        System.out.println ();
        
    }    
    
    
    
}
