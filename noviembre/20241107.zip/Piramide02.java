package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Piramide02 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numFilas;

        // Variables de salida

        // Variables auxiliares
        int fila, columna;
        
        // Entrada de datos 
        // ----------------
        System.out.println("PIRÁMIDE NUMÉRICA");
        System.out.println("-----------------");

        System.out.println ("Introduzca número de filas: ");
        numFilas = teclado.nextInt();
        
        
        // Procesamiento + Salida de resultados
        // ------------------------------------                   

        for ( fila = 1 ; fila <= numFilas ;  fila++ ) {

            for ( columna = 1; columna <= fila  ; columna++ ) {
                System.out.print (columna + " ");
            }

            System.out.println();
        }

        System.out.println();

        
    }

}
