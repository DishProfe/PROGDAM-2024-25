
package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Ejex01 {
    
    
    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        
        // Variables de entrada
        double velocidadMedia;       
        
        // Variables de salida
        double minPorKm, segPorKm;
        int minKm, segKm;
        
        // Variables auxiliares
        

        // Entrada de datos
        // ----------------
        System.out.println ("RITMO Y VELOCIDAD MEDIA"); 
        System.out.println ("-----------------------"); 

        System.out.println ("Introduzca velocidad media en km/h: ");
        velocidadMedia = teclado.nextDouble();

        
        // Procesamiento
        // -------------
        
        //10km/h -> 1h -> 10km  -> 60min/10km -> 6min/km
        
        minPorKm = 60.0 / velocidadMedia;           
        minKm = (int)minPorKm;

        segPorKm = (minPorKm - minKm) *60;
        segKm = (int)segPorKm;

        // Salida de resultados
        // --------------------
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        System.out.println ("El tiempo en hacer un kilómetro es: " + minKm + "min " + segKm + "seg");
        
        
    }    
    
    
    
}
