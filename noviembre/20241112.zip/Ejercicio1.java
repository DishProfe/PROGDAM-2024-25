package tarea02;

import java.util.Scanner;

/**
 * Ejercicio 1. Validación de entradas.
 *
 * @author Profe
 */
public class Ejercicio1 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Variables de entrada
        int numero;

        // Variables de salida
        int sumaCifras;

        // Variables auxiliares
        boolean valido;
        int residuo;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("VALIDACIÓN DE ENTRADAS Y SUMA DE CIFRAS");
        System.out.println("---------------------------------------");

        // Indicación de las instrucciones generales
        System.out.println("Se necesita un número entero que cumpla las siguientes condiciones: ");
        System.out.println("1. que sea positivo (mayor estricto que cero)");
        System.out.println("2. de como máximo ocho cifras");
        System.out.println("3. que sea impar");
        System.out.println("4. que no termine en 7");

        // Solicitud del número todas las veces que haga falta
        do {
            System.out.print("\nIntroduzca número que cumpla las condiciones: ");
            numero = teclado.nextInt();

            valido = true;
            
            if (numero <= 0) {
                System.out.println("Error: el número no es positivo.");
                valido = false;
            } else if (numero > 99_999_999) {
                System.out.println("Error: el número tiene más de ocho cifras.");
                valido = false;
            } else if (numero % 2 == 0) {
                System.out.println("Error: el número no es impar.");
                valido = false;
            } else if (numero % 10 == 7) {
                System.out.println("Error: el número termina en 7.");
                valido = false;
            }

        } while (!valido);

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Cálculo de la suma de las cifras del número
        residuo = numero; // Iniciamos el residuo al número que vamos a ir "empequeñeciendo" hasta que sea cero ("desacumulador")
        sumaCifras = 0;   // Iniciamos el acumulador que irá acumulando la suma de cifras
        // Vamos obteniendo cada cifra del número a base de ir dividiendo entre 10 y quedándome con el cociente
        do {
            sumaCifras += residuo % 10; // Obtenemos la cifra de más a la derecha (unidades) al calcular el resto de dividir entre 10
            residuo /= 10;  // // Eliminamos la cifra de más a la derecha (unidades) al calcular el cociente de dividir entre 10
        } while (residuo > 0);

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println("La suma de las cifras del número es: " + sumaCifras);

    }
}
