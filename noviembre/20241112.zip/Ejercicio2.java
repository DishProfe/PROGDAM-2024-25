package tarea02;

import java.util.Scanner;

/**
 * Ejercicio 2. Calendario.
 * @author Profe
 */
public class Ejercicio2 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Variables de entrada
        int diaInicio, diaFin;

        // Variables de salida
        String calendario;
        
        // Variables auxiliares
        int dia;
        
        // Clase Scanner para petición de datos
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
       
        System.out.println("CALENDARIO");
        System.out.println("----------");
        System.out.println ("Introduzca dos valores entre 1 y 30: ");
        
        do {
            System.out.print ("Día de inicio (1-30):");        
            diaInicio = teclado.nextInt();
        } while (diaInicio<1 || diaInicio>30);

        do {
            System.out.print ("Día de fin, no menor que el día de inicio: ");        
            diaFin = teclado.nextInt();
        } while (diaFin<diaInicio || diaFin>30);
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        // Generamos el calendario
        calendario = ""; // Lo incializamos a la cadena vacía, para poder contatenar con algo
        // Recorremos desde el día de inicio hasta el día de fin, de tres en tres        
        for ( dia = diaInicio ; dia<=diaFin ; dia +=3) {
            String diaSemana = "";
            String actividad = "";
            switch ( (dia-1) % 7 ) {  // Calculamos en qué día de la semana estamos a partir del día del mes
                // Obtenemos, para ese día, el día de la semana y la actividad correspondiente
                case 0:
                    diaSemana = "lunes";
                    actividad ="clase";
                    break;
                case 1:
                    diaSemana = "martes";
                    actividad ="estudio";
                    break;
                case 2:
                    diaSemana = "miércoles";
                    actividad ="clase";
                    break;
                case 3:
                    diaSemana = "jueves";
                    actividad ="estudio";
                    break;
                case 4:
                    diaSemana = "viernes";
                    actividad ="clase";
                    break;
                case 5:
                    diaSemana = "sábado";
                    actividad ="ocio";
                    break;
                case 6:
                    diaSemana = "domingo";
                    actividad ="ocio";
            }
            // Concatenamos en nuestra cadena de calendario
            calendario +=  diaSemana + " " + dia + ": " + actividad + "\n";
        } 
        

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println("El calendario generado es:");
        System.out.println(calendario);
    }
}