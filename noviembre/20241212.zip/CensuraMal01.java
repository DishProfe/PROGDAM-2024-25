package ejemplos2024;


import java.util.Scanner;

/**
 *   Programa
 */

    public class CensuraMal01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String textoEntrada;
        
        
        // Variables de salida
        String textoSalida;
        
        // Variables auxiliares
        boolean malEncontrado;
        int posicionMal = 0;


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CENSURA DEL MAL");
        System.out.println("-----------------");

            System.out.print("Introduzca el texto: ");
            textoEntrada = teclado.nextLine();

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        textoSalida =  textoEntrada.replace( "mal", "---");
          
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.printf ("El mal censurado: %s\n", textoSalida);
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}