package ejemplos2024;


import ejemplos2023.*;
import java.util.Scanner;
import java.awt.Rectangle;

/**
 *   Programa
 */

    public class Rectangle06 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Rectangle rec1, rec2, rec3, rec4;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS");
        System.out.println("--------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //                       +
        //              Salida de resultados 
        //----------------------------------------------
        
        // 0.- Creamos los dos rectángulos
        rec1= new Rectangle (1,2, 5, 4);
        rec2= new Rectangle (5,3, 4, 6);        
        
        // 1.- Comprobamos si los rectángulos contienen el punto (3,3)
        System.out.println ("rec1 contiene el punto (3,3): " + rec1.contains (3,3));
        System.out.println ("rec2 contiene el punto (3,3): " + rec2.contains (3,3));
        System.out.println ();

        // 2.- Comprobamos si ambos rectángulos tienen alguna zona en común (su intersección es no nula)
        System.out.println ("rec1 tiene partes en común con rec2 : " + 
                rec1.intersects (rec2) );        
        System.out.println ("rec2 tiene partes en común con rec1 : " + 
                rec2.intersects (rec1) );
        System.out.println ();
        

        // 3. Creamos un rectángulo con las partes en común de los dos anteriores
        System.out.println ("Creando rec3 como intersección de rec1 y rec2");
        rec3 = rec1.intersection(rec2);
        System.out.println ();

        // Mostramos los atributos de ese nuevo rectángulo 
        System.out.println ("Rectángulo rec3 intersección de rec1 y rec2:");
        System.out.println ("Ubicación: x=" + rec3.x + " y=" + rec3.y);
        System.out.println ("Dimensiones: base= " + rec3.width+ " altura= " + rec3.height);
        System.out.println ("rec3: " + rec3.toString());

        // 4.- Reubicamos el rectángulo rec1 en la posición (2,2)
        System.out.println ("Reubicando rec1 a (2,2)");
        rec1.setLocation(2, 2);
        System.out.println ();
        
        // 5. Creamos un rectángulo con las partes en común de rec1 y rec2
        System.out.println ("Creando rec4 como intersección de rec1 y rec2");
        rec4 = rec1.intersection(rec2);

        // Mostramos los atributos de ese nuevo rectángulo 
        System.out.println ("Rectángulo rec4 intersección de rec1 y rec2:");
        System.out.println ("Ubicación: x=" + rec4.x + " y=" + rec4.y);
        System.out.println ("Dimensiones: base= " + rec4.width+ " altura= " + rec4.height);
        System.out.println ();

        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}