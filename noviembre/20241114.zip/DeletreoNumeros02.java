package ejemplos2024;

import java.util.Scanner;

/**
 * Programa
 */
public class DeletreoNumeros02 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada
        int numero;

        // Variables de salida
        String deletreo;
        
        // Variables auxiliares
        int residuo;
        int cifra;
        int numCifras;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("'DELETREO' DE NÚMEROS");
        System.out.println("------------------------------");
        System.out.println("Introduzca número entero:");
        numero = teclado.nextInt();

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        residuo = numero;
        deletreo = "";
        
        while (residuo > 0) {

            cifra = residuo % 10;
            residuo = residuo / 10;

            switch (cifra) {
                case 0:
                    deletreo += "cero";
                    break;

                case 1:
                    deletreo = deletreo + "uno";
                    break;

                case 2:
                    deletreo = deletreo + "dos";
                    break;

                case 3:
                    deletreo = deletreo + "tres";
                    break;

                case 4:
                    deletreo = deletreo + "cuatro";
                    break;

                case 5:
                    deletreo = deletreo + "cinco";
                    break;

                case 6:
                    deletreo = deletreo + "seis";
                    break;

                case 7:
                    deletreo = deletreo + "siete";
                    break;

                case 8:
                    deletreo = deletreo + "ocho";
                    break;

                case 9:
                    deletreo = deletreo + "nueve";
                    break;

            }
            deletreo = deletreo + " ";
        }

    //----------------------------------------------
    //              Salida de resultados 
    //----------------------------------------------
    System.out.println ();

    System.out.println ("RESULTADO");
    System.out.println ("---------");
    System.out.println (deletreo);
    System.out.println ();
    System.out.println ("Fin del programa.");

    }

}
