package ejemplos2024;


import ejemplos2023.*;
import java.util.Scanner;
import java.awt.Rectangle;
import java.time.LocalDate;

/**
 *   Programa
 */

    public class Rectangle04 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Rectangle r1, r2, r3;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS RECTANGLE");
        System.out.println("------------------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //                       +
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Creación de objeto Rectangle con ubicación (10,10)
        // anchura 10 y altura 5
        r1 = new Rectangle (10, 10, 10, 5); 

        // Asigna a la variable r2 la misma referencia a la 
        // que apunta r1
        r2 = r1;
        

        // Mostramos los atributos o propiedades del objeto al que apunta r1
        System.out.println ("Rectángulo r1:");
        System.out.println ("Ubicación: x=" + r1.x + " y=" + r1.y);
        System.out.println ("Dimensiones: base= " + r1.width+ " altura= " + r1.height);
        System.out.println ();

        // Mostramos los atributos o propiedades del objeto al que apunta r2
        System.out.println ("Rectángulo r2:");
        System.out.println ("Ubicación: x=" + r2.x + " y=" + r2.y);
        System.out.println ("Dimensiones: base= " + r2.width+ " altura= " + r2.height);
        System.out.println ();

        // Modifica la altura del rectángulo al que apunta r2 poniéndola 
        // al valor 6
        System.out.println ("Modificamos al altura de r2 a 6");
        r2.height = 6;
        System.out.println ();

        // Mostramos los atributos o propiedades del objeto al que apunta r1
        System.out.println ("Rectángulo r1:");
        System.out.println ("Ubicación: x=" + r1.x + " y=" + r1.y);
        System.out.println ("Dimensiones: base= " + r1.width+ " altura= " + r1.height);
        System.out.println ();

        // Mostramos los atributos o propiedades del objeto al que apunta r2
        System.out.println ("Rectángulo r2:");
        System.out.println ("Ubicación: x=" + r2.x + " y=" + r2.y);
        System.out.println ("Dimensiones: base= " + r2.width+ " altura= " + r2.height);
        System.out.println ();
        
        // Instancia ahora un segundo objeto Rectangle con 
        // ubicación en las coordenadas (0,0), 
        // de base 100 y altura 20 asignando a la 
        // variable r3 la referencia a ese objeto 
        // recién creado.
        r3 = new Rectangle(100, 20);
        
        // Mostramos los atributos o propiedades del objeto al que apunta r3
        System.out.println ("Rectángulo r3:");
        System.out.println ("Ubicación: x=" + r3.x + " y=" + r3.y);
        System.out.println ("Dimensiones: base= " + r3.width+ " altura= " + r3.height);
        System.out.println ();
        
        // Modifica ahora el valor de la variable r3 
        // asignándole el valor de la variable r2.        
        r3 = r2;
        
        // Modifica la base y la altura de r3 
        // (en realidad del objeto rectángulo al 
        // que apunta r3) al valor 50 en ambos casos.
        r3.height = 50;
        r3.width  = 50;
        
        // Mostramos los atributos o propiedades del objeto al que apunta r1
        System.out.println ("Rectángulo r1:");
        System.out.println ("Ubicación: x=" + r1.x + " y=" + r1.y);
        System.out.println ("Dimensiones: base= " + r1.width+ " altura= " + r1.height);
        System.out.println ();

        // Mostramos los atributos o propiedades del objeto al que apunta r2
        System.out.println ("Rectángulo r2:");
        System.out.println ("Ubicación: x=" + r2.x + " y=" + r2.y);
        System.out.println ("Dimensiones: base= " + r2.width+ " altura= " + r2.height);
        System.out.println ();        
        
        // Mostramos los atributos o propiedades del objeto al que apunta r3
        System.out.println ("Rectángulo r3:");
        System.out.println ("Ubicación: x=" + r3.x + " y=" + r3.y);
        System.out.println ("Dimensiones: base= " + r3.width+ " altura= " + r3.height);
        System.out.println ();        


        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}