package ejemplos2024;

import java.awt.Rectangle;
import java.util.Scanner;

/**
 *   Ejemplos con la clase Rectangle
 */

    public class Rectangle01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Rectangle r1, r2, r3, r4, r5;
        
        int ent1, ent2, ent3;
        
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS");
        System.out.println("--------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        ent2 = 10;
        ent1 = ent2 + 5;
        
        r1 = new Rectangle();
        
        r2 = new Rectangle(3, 5);
        
        r3 = new Rectangle ( 3, 5, 3, 2);
        
        r4 = new Rectangle (r3);
        
        r5 = new Rectangle (0,0, 1,1);
        
        
        r5.width = 7;
        r5.height = 2;
        
        r4.setLocation(10,10);
        


        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        System.out.println ("r1.x = " + r1.x);
        System.out.println ("r1.y = " + r1.y);
        System.out.println ("r1.width = " + r1.width);
        System.out.println ("r1.height = " + r1.height);
	System.out.println ("-------------------------");

        System.out.println ("r2.x = " + r2.x);
        System.out.println ("r2.y = " + r2.y);
        System.out.println ("r2.width = " + r2.width);
        System.out.println ("r2.height = " + r2.height);
	System.out.println ("-------------------------");
               
        System.out.println ("r3.x = " + r3.x);
        System.out.println ("r3.y = " + r3.y);
        System.out.println ("r3.width = " + r3.width);
        System.out.println ("r3.height = " + r3.height);
	System.out.println ("-------------------------");

        System.out.println ("r4.x = " + r4.x);
        System.out.println ("r4.y = " + r4.y);
        System.out.println ("r4.width = " + r4.width);
        System.out.println ("r4.height = " + r4.height);
	System.out.println ("-------------------------");

        System.out.println ("r5.x = " + r5.x);
        System.out.println ("r5.y = " + r5.y);
        System.out.println ("r5.width = " + r5.width);
        System.out.println ("r5.height = " + r5.height);
	System.out.println ("-------------------------");


        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}