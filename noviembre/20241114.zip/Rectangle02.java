package ejemplos2024;

import java.awt.Rectangle;
import java.util.Scanner;

/**
 *   Ejemplos con la clase Rectangle
 */

    public class Rectangle02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Rectangle r1, r2, r3;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS RECTANGLE");
        System.out.println("------------------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //                       +
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");

        r1= new Rectangle (50, 50, 150, 150);  // Ubicado en (50,50), anchura 150, altura 150
        
        System.out.println ("r1.x = " + r1.x);
        System.out.println ("r1.y = " + r1.y);
        System.out.println ("r1.width = " + r1.width);
        System.out.println ("r1.height = " + r1.height);
        
        System.out.println ();
        System.out.println ("Modificamos algunos atributos del rectángulo r1:");
        
        System.out.println ();
        System.out.println ("1. Accediendo directamente a atributos públicos y modificándolos:");
        r1.height = 100 ;
        r1.width = 100 ;

        System.out.println ("r1.x = " + r1.x);
        System.out.println ("r1.y = " + r1.y);
        System.out.println ("r1.width = " + r1.width);
        System.out.println ("r1.height = " + r1.height);
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}