package ejemplos2024;

import java.util.Scanner;

/**
 * Programa
 */
public class DeletreoNumeros01 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada
        int numero;

        // Variables de salida
        // Variables auxiliares
        int residuo;
        int cifra;
        int numCifras;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("'DELETREO' DE NÚMEROS");
        System.out.println("------------------------------");
        System.out.println("Introduzca número entero:");
        numero = teclado.nextInt();

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        residuo = numero;

        while (residuo > 0) {

            cifra = residuo % 10;
            residuo = residuo / 10;

            System.out.print (cifra + " ");
            switch (cifra) {
                case 0:
                    System.out.println("cero");
                    break;

                case 1:
                    System.out.println("uno");
                    break;

                case 2:
                    System.out.println("dos");
                    break;

                case 3:
                    System.out.println("tres");
                    break;

                case 4:
                    System.out.println("cuatro");
                    break;

                case 5:
                    System.out.println("cinco");
                    break;

                case 6:
                    System.out.println("seis");
                    break;

                case 7:
                    System.out.println("siete");
                    break;

                case 8:
                    System.out.println("ocho");
                    break;

                case 9:
                    System.out.println("nueve");
                    break;

            }
        }

    //----------------------------------------------
    //              Salida de resultados 
    //----------------------------------------------
    System.out.println ();

    System.out.println (
            

    "RESULTADO");
    System.out.println (
            

    "---------");

    System.out.println ();

    System.out.println (
            

"Fin del programa.");

    }

}
