package ejemplos2024;


import java.util.Scanner;

/**
 *   Programa
 */

    public class Nombre03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String nombre;
        
        
        // Variables de salida
        boolean nombreValido = true;

        // Variables auxiliares
        int posicion;


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ENTRADA DE NOMBRE");
        System.out.println("-----------------");

        do {   
           System.out.print ("Introduzca el nombre (máximo diez caracteres y mínimo uno): ");
           nombre= teclado.nextLine();
           nombreValido= nombre.length()>=1 && nombre.length()<=10 && nombre.charAt(0)>='A' && nombre.charAt(0)<='Z';
           if (!nombreValido)  {
               System.out.println ("El nombre debe tener como como mínimo un carácter y como máximo diez, debe comenzar por letra mayúscula y el resto deben ser minúsculas.");
           } else {  // Si se supera la prueba del primer carácter en mayúscula, pasamos a comprobar el resto
               for (int indice=1 ; indice<nombre.length() && nombreValido ; indice++) {
                   nombreValido= nombre.charAt(indice)>='a' && nombre.charAt(indice)<='z';
               }
               if (!nombreValido)
                   System.out.println ("El nombre debe tener como como mínimo un carácter y como máximo diez, debe comenzar por letra mayúscula y el resto deben ser minúsculas.");
           }

       } while (!nombreValido); // Seguiremos solicitando mientras el nombre no sea válido
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        


        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("El nombre introducido es: " + nombre);
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}