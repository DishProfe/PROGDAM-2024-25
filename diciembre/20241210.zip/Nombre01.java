package ejemplos2024;


import java.util.Scanner;

/**
 *   Programa
 */

    public class Nombre01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String nombre;
        
        
        // Variables de salida
        boolean nombreValido = true;

        // Variables auxiliares
        int posicion;


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ENTRADA DE NOMBRE");
        System.out.println("-----------------");

        do {
            System.out.print("Introduzca el nombre (máximo diez caracteres y mínimo uno): ");
            nombre = teclado.nextLine();
            nombreValido = nombre.length() >= 1 && nombre.length() <= 10;
            if (!nombreValido) {
                System.out.println("El nombre debe tener como como mínimo un carácter y como máximo diez.");
            }
        } while (!nombreValido); // Seguiremos solicitando mientras el nombre no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("El nombre introducido es: " + nombre);
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}