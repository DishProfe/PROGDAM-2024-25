package ejemplos2024;


import java.util.Scanner;

/**
 *   Programa
 */

    public class Nombre04 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String nombre;
        
        
        // Variables de salida
        boolean nombreValido = true;

        // Variables auxiliares
        int espacios;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ENTRADA DE NOMBRE CON DOS PALABRAS");
        System.out.println("----------------------------------");



        do {
            System.out.println("Introduzca un nombre formado por dos palabras en minúscula separadas por un espacio:");
            nombre = teclado.nextLine();
            espacios = 0;
            nombreValido = nombre.length() > 0 && nombre.charAt(0) >= 'a' && nombre.charAt(0) <= 'z'
                    && nombre.charAt(nombre.length() - 1) >= 'a' && nombre.charAt(nombre.length() - 1) <= 'z';
            if (nombreValido) {
                for (int i=1 ; i<nombre.length()-2 && nombreValido ; i++) {
                    nombreValido = nombre.charAt(i) >= 'a' && nombre.charAt(i) <= 'z' || nombre.charAt(i) == ' ';
                    if (nombre.charAt(i) == ' ')
                        espacios++;
                    nombreValido = nombreValido & espacios<=1; // Si hay más de un espacio la cadena ya no es válida
                }
                nombreValido = nombreValido & espacios == 1; // La cadena es válida solo si al final hay exactamente un espacio
            }            
        } while (!nombreValido);
        System.out.printf ("Nombre introducido: %s", nombre );

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        


        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("El nombre introducido es: " + nombre);
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}