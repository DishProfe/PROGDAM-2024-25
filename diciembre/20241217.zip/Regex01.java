package ejemplos2024;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class Regex01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String numeroRomano;
        
        
        // Variables de salida
        boolean romanoValido;
        String numRomanoLimpio;

        // Variables auxiliares
        String patronNumRomano = "M{0,3}(D?C{0,3}|CD|CM)(L?X{0,3}|XL|XC)(V?I{0,3}|IV|IX)";
        Pattern patternNumeroRomano = Pattern.compile (patronNumRomano);


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        do {
            System.out.print("Introduzca un número romano entre 1 y 3999: ");
            numeroRomano = teclado.nextLine();
            numRomanoLimpio = numeroRomano.trim().toUpperCase();
            
            Matcher matcherRomano = patternNumeroRomano.matcher (numRomanoLimpio.trim());
            romanoValido = matcherRomano.matches();           
        } while (!romanoValido); // Seguiremos solicitando mientras el número romano no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("El número romano introducido es: " + numRomanoLimpio);
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}