package ejemplos2024;


import java.util.Scanner;

/**
 *   Programa
 */

    public class Regex02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String numeroRomano;
        
        
        // Variables de salida
        boolean romanoValido;
        String numRomanoLimpio;

        // Variables auxiliares
        String patronNumRomano = "M{0,3}(D?C{0,3}|CD|CM)(L?X{0,3}|XL|XC)(V?I{0,3}|IV|IX)";


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        do {
            System.out.print("Introduzca un número romano entre 1 y 3999: ");
            numeroRomano = teclado.nextLine();
            numRomanoLimpio = numeroRomano.trim().toUpperCase();
            
            romanoValido = numRomanoLimpio.matches(patronNumRomano);           
        } while (!romanoValido); // Seguiremos solicitando mientras el número romano no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("El número romano introducido es: " + numRomanoLimpio);
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}