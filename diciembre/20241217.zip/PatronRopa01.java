package ejemplos2024;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class PatronRopa01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String etiquetaPrenda;
        
        
        // Variables de salida
        boolean etiquetaValida;
        String etiquetaPrendaLimpia;

        // Variables auxiliares
        String patronPrenda = "[0-9]{5}-[HMB]-[EA]";
        Pattern patternPrenda = Pattern.compile (patronPrenda);


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        do {
            System.out.print("Introduzca la etiqueta de la prenda (NNNNN-Tipo(H/M/B)-Origen(E/A): ");
            etiquetaPrenda = teclado.nextLine();
            etiquetaPrendaLimpia = etiquetaPrenda.trim().toUpperCase();
            
            Matcher matcherRomano = patternPrenda.matcher (etiquetaPrendaLimpia.trim());
            etiquetaValida = matcherRomano.matches();           
        } while (!etiquetaValida); // Seguiremos solicitando mientras no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("La etiqueta introducida es: " + etiquetaPrendaLimpia);
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}