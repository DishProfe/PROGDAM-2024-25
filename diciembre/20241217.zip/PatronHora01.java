package ejemplos2024;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class PatronHora01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String hora;
        
        
        // Variables de salida
        boolean horaValida;
        String horaLimpia;

        // Variables auxiliares
        String patronHora = "([0-1][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]";
        Pattern patternHora = Pattern.compile (patronHora);


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        do {
            System.out.println("Introduzca una hora válida (hh:mm:ss): ");
            hora = teclado.nextLine();
            horaLimpia = hora.trim().toUpperCase();
            
            Matcher matcherRomano = patternHora.matcher (horaLimpia.trim());
            horaValida = matcherRomano.matches();           
        } while (!horaValida); // Seguiremos solicitando mientras no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("La hora introducida es: " + horaLimpia);
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}