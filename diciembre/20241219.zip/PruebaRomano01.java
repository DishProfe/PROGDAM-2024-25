package ejemplos2024;

import java.util.regex.*;

public class PruebaRomano01 {
    public static void main(String[] args) {
        // Texto de ejemplo
        String text = "Algunos números romanos comunes son I, IV, IX, XL, XC, CD, CM, y MMMCMXCIX.";

        // Expresión regular para números romanos válidos
        String romanRegex = "\\bM{0,3}(CM|CD|D?C{0,3})?(XC|XL|L?X{0,3})?(IX|IV|V?I{0,3})\\b";

        // Crear el patrón y el matcher
        Pattern pattern = Pattern.compile(romanRegex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);

        // Buscar coincidencias y mostrarlas
        System.out.println("Números romanos encontrados:");
        while (matcher.find()) {
            System.out.println("Coincidencia: " + matcher.group() + 
                               " (Inicio: " + matcher.start() + 
                               ", Fin: " + matcher.end() + ")");
        }
    }
}
