package ejemplos2024;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class PatronFecha01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String fecha;
        
        
        // Variables de salida
        boolean fechaValida;
        String fechaLimpia;
        
        String dia="" , mes="", year="";

        // Variables auxiliares
        String patronFecha = "(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/(20[0-9]{2})";
        Pattern patternFecha = Pattern.compile (patronFecha);
        Matcher matcherFecha = null;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        do {
            System.out.println("Introduzca una fecha válida (dd/mm/aaaa): ");
            fecha = teclado.nextLine();
            fechaLimpia = fecha.trim().toUpperCase();
            
            matcherFecha=  patternFecha.matcher (fechaLimpia.trim());
            fechaValida = matcherFecha.matches();           
        } while (!fechaValida); // Seguiremos solicitando mientras no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        if ( fechaValida ) {  // No debemos intentar extraer grupos si no se ha producido acoplamiento
            dia = matcherFecha.group(1);
            mes = matcherFecha.group(2);
            year = matcherFecha.group(3);
        }
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("La fecha desglosada es: " );
        if ( fechaValida ) {
            System.out.printf ("Dia: %s\n", dia);
            System.out.printf ("Mes: %s\n", mes);
            System.out.printf ("Año: %s\n", year);
        }
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}