package ejemplos2024;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class PatronRomano01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String romano;
        
        
        // Variables de salida
        boolean romanoValido;
        
        
        String miles="" , cientos="", decenas="", unidades="";

        // Variables auxiliares
        String patronRomano = "(M{0,3})(D?C{0,3}|CD|CM)(L?X{0,3}|XL|XC)(V?I{0,3}|IV|IX)";
        Pattern patternRomano = Pattern.compile (patronRomano);
        Matcher matcherRomano = null;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        do {
            System.out.println("Introduzca un número romano: ");
            romano = teclado.nextLine();
            
            matcherRomano=  patternRomano.matcher (romano.trim());
            romanoValido = matcherRomano.matches();           
        } while (!romanoValido); // Seguiremos solicitando mientras no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        if ( romanoValido ) {  // No debemos intentar extraer grupos si no se ha producido acoplamiento
            miles = matcherRomano.group(1);
            cientos = matcherRomano.group(2);
            decenas = matcherRomano.group(3);
            unidades = matcherRomano.group(4);
        }
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("Los componentes del número romano son: " );
        if ( romanoValido ) {
            System.out.printf ("Millares: %s\n", miles);
            System.out.printf ("Cientos: %s\n", cientos);
            System.out.printf ("Decenas: %s\n", decenas);
            System.out.printf ("Unidades: %s\n", unidades);
        }
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}