package ejemplos2024;

import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Programa
 */
public class PatronNumeroEntero01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        String texto;

        // Variables de salida
        String horaLimpia;
        int numEnteros;
        int inicio, fin;

        // Variables auxiliares
        String patronEntero = "[0-9]+";
        // Creamos el patrón de búsqueda de números enteros
        Pattern patternEntero = Pattern.compile(patronEntero);
        boolean enteroEncontrado;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        System.out.println("Introduzca un texto que contenga números enteros: ");
        texto = teclado.nextLine();


        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        // Creamos un matcher o acoplador con el texto introducido por teclado
        Matcher matcherTexto = patternEntero.matcher(texto);

        numEnteros = 0;
        do {
            enteroEncontrado = matcherTexto.find(); 
            
            if (enteroEncontrado) {
                inicio = matcherTexto.start();
                fin = matcherTexto.end();
                System.out.printf  ("%2d.- Patrón numérico entero encontrado. "
                        + "Ubicado entre las posiciones %d y %d: %s\n",
                ++numEnteros, inicio, fin, texto.substring(inicio, fin) );            
            }
                        
        } while (enteroEncontrado);


        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println("Cantidad total de enteros encontrados: " + numEnteros);

        System.out.println();
        System.out.println("Fin del programa.");

    }

}
