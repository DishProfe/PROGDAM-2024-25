package ejemplos2024;

import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Programa
 */
public class PatronNumeroRomano01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        String texto;

        // Variables de salida
        int numEnteros;
        int inicio, fin;

        // Variables auxiliares
        String patronRomano = "\\b(M{0,3}(CD|CM|D?C{0,3})(XL|XC|L?X{0,3})(IV|IX|V?I{0,3}))\\b";
        // Creamos el patrón de búsqueda de números enteros
        Pattern patternEntero = Pattern.compile(patronRomano);
        boolean romanoEncontrado;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        System.out.println("Introduzca un texto que contenga números romanos: ");
        texto = teclado.nextLine();

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Creamos un matcher o acoplador con el texto introducido por teclado
        Matcher matcherTexto = patternEntero.matcher(texto);

        numEnteros = 0;
        do {
            romanoEncontrado = matcherTexto.find();

            if (romanoEncontrado) {
                inicio = matcherTexto.start();
                fin = matcherTexto.end();
                if (inicio != fin) {

                    System.out.printf("%2d.- Patrón número romano encontrado. "
                            + "Ubicado entre las posiciones %d y %d: %s\n",
                            ++numEnteros, inicio, fin, texto.substring(inicio, fin));
                }
            }

        } while (romanoEncontrado);

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println("Cantidad total de números romanos encontrados: " + numEnteros);

        System.out.println();
        System.out.println("Fin del programa.");

    }

}
