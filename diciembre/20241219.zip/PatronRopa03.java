package ejemplos2024;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class PatronRopa03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String identificador;
        
        
        // Variables de salida
        boolean codigoValido;
        String codigoLimpio;
        
        
        String cliente="" , id="", origen="", codControl="";

        // Variables auxiliares
        String patronCodigo = "([HMB])([0-9]{3,7})([EA])([0-9]{2})";
        Pattern patternCodigo = Pattern.compile (patronCodigo);
        Matcher matcherCodigo = null;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        do {
            System.out.println("Introduzca un identificador de prenda: ");
            identificador = teclado.nextLine();
            
            matcherCodigo=  patternCodigo.matcher (identificador.trim());
            codigoValido = matcherCodigo.matches();           
        } while (!codigoValido); // Seguiremos solicitando mientras no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        if ( codigoValido ) {  // No debemos intentar extraer grupos si no se ha producido acoplamiento
            cliente = matcherCodigo.group(1);
            id = matcherCodigo.group(2);
            origen = matcherCodigo.group(3);
            codControl = matcherCodigo.group(4);
        }
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("Los componentes del identificador de prenda son: " );
        if ( codigoValido ) {
            System.out.printf ("Cliente: %s\n", cliente);
            System.out.printf ("identificador: %s\n", id);
            System.out.printf ("Origen: %s\n", origen);
            System.out.printf ("Código de control: %s\n", codControl);
        }
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}