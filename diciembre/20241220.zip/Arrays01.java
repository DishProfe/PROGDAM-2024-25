package ejemplos2024;


import java.util.Scanner;

/**
 *   Programa
 */

    public class Arrays01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida

        // Variables auxiliares
        int[] arrayNumeros;
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE ARRAYS");
        System.out.println("------------------");

        
        // Reservamos espacio para el array
        arrayNumeros = new int[10];

        // Rellenamos el contenido del array "a mano"
        arrayNumeros[0] = 0;
        arrayNumeros[1] = 2;
        arrayNumeros[2] = 4;
        arrayNumeros[3] = 6;
        arrayNumeros[4] = 8;
        arrayNumeros[5] = 10;
        


        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Mostramos el contenido del array mediante un bucle
        for ( int indice = 0; indice < arrayNumeros.length ; indice++ ) {
            System.out.printf ("Posición %2d: %2d\n",
                    indice, arrayNumeros[indice]);
        }
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}