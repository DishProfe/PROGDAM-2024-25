package ejemplos2024;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Programa
 */
public class Arrays05 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        // Variables de salida
        // Variables auxiliares
        LocalDate[] arrayFechas;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE ARRAYS");
        System.out.println("------------------");

        // Reservamos espacio para el array
        arrayFechas = new LocalDate[20];

        // Rellenamos el contenido del array con un bucle
        for (int indice = 0; indice < arrayFechas.length; indice++) {
            // Calculamos la fecha actual
            LocalDate fechaActual = LocalDate.now();
            // Generamos un número aleatorio entre 0 y la cantidad de días del año actual (365 o 366)
            int numAleatorioDias = (int) ((fechaActual.lengthOfYear()) * Math.random());
            // Sumamos al 1 de enero del año actual esa cantidad aleatoria de días
            LocalDate fechaAleatoria = LocalDate.of(fechaActual.getYear(), 1, 1).plusDays(numAleatorioDias);
            // Guardamos esa fecha aleatoria en la posición actual del array (posición "indice")
            arrayFechas[indice] = fechaAleatoria;
        }

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        // Mostramos el contenido del array mediante Arrays.toString
        System.out.println (Arrays.toString(arrayFechas));

        System.out.println();
        System.out.println("Fin del programa.");

    }

}
