package ejemplos2024;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class PatronRomano02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String romano;
        
        
        // Variables de salida
        boolean romanoValido;
        int numero;
        
        
        String miles="" , cientos="", decenas="", unidades="";

        // Variables auxiliares
        String patronRomano = "(M{0,3})(D?C{0,3}|CD|CM)(L?X{0,3}|XL|XC)(V?I{0,3}|IV|IX)";
        Pattern patternRomano = Pattern.compile (patronRomano);
        Matcher matcherRomano = null;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        do {
            System.out.println("Introduzca un número romano: ");
            romano = teclado.nextLine();
            
            matcherRomano=  patternRomano.matcher (romano.trim());
            romanoValido = matcherRomano.matches();           
        } while (!romanoValido); // Seguiremos solicitando mientras no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        numero = 0;
        if ( romanoValido ) {  // No debemos intentar extraer grupos si no se ha producido acoplamiento
            miles = matcherRomano.group(1);
            cientos = matcherRomano.group(2);
            decenas = matcherRomano.group(3);
            unidades = matcherRomano.group(4);
            
            // Sumamos los millares (la longitud de la cadena de caracteres 'M')
            numero += miles.length()*1000;

            // Sumamos los cientos (-, C, CC, CCC, CD, D, DC, DCC, DCCC, CM)
            // Casos "CD" y "CM"
            if (cientos.length() > 0) {
                if (cientos.length() == 2 && cientos.charAt(0) == 'C' && cientos.charAt(1) != 'C') {
                    switch (cientos.charAt(1)) {
                        case 'D': // "CD"
                            numero += 400;
                            break;
                        case 'M': // "CM"
                            numero += 900;
                            break;
                    }
                } else { // Casos "aditivos" (se suman valores): -, C, CC, CCC, D, DC, DCC, DCCC
                    int numCes = 0;  // Número de caracteres 'C' encontrados
                    if (cientos.charAt(0) == 'D') {
                        numero += 500;
                        numCes = cientos.length()-1;
                    } else {
                        numCes = cientos.length();                    
                    }
                    numero += numCes * 100;
                } 
            }
            
            // Sumamos los cientos (-, X, XX, XXX, XL, L, LX, LXX, LXXX, XC)
            if (decenas.length() > 0) {
                if (decenas.length() == 2 && decenas.charAt(0) == 'X' && decenas.charAt(1) != 'X') {
                    switch (decenas.charAt(1)) {
                        case 'L': // "XL"
                            numero += 40;
                            break;
                        case 'C': // "XC"
                            numero += 90;
                            break;
                    }
                } else { // Casos "aditivos" (se suman valores): -, X, XX, XXX, L, LX, LXX, LXXX
                    int numEquis = 0;  // Número de caracteres 'X' encontrados
                    if (decenas.charAt(0) == 'L') {
                        numero += 50;
                        numEquis = decenas.length()-1;
                    } else {
                        numEquis = decenas.length();                    
                    }
                    numero += numEquis * 10;
                }
            }

            // Sumamos las unidades (-, I, II, III, IV, V, VI, VII, VIII, IX)
            if (unidades.length() > 0) {
                if (unidades.length() == 2 && unidades.charAt(0) == 'I' && unidades.charAt(1) != 'I') {
                    switch (unidades.charAt(1)) {
                        case 'V': // "IV"
                            numero += 4;
                            break;
                        case 'X': // "IX"
                            numero += 9;
                            break;
                    }
                } else { // Casos "aditivos" (se suman valores): -, I, II, III, V, VI, VII, VIII
                    int numUnos = 0;  // Número de caracteres 'X' encontrados
                    if (unidades.charAt(0) == 'V') {
                        numero += 5;
                        numUnos = unidades.length()-1;
                    } else {
                        numUnos = unidades.length();                    
                    }
                    numero += numUnos;
                }
            }
            
            
        }




        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("Los componentes del número romano son: " );
        if ( romanoValido ) {
            System.out.printf ("Millares: %s\n", miles);
            System.out.printf ("Cientos: %s\n", cientos);
            System.out.printf ("Decenas: %s\n", decenas);
            System.out.printf ("Unidades: %s\n", unidades);
            
            System.out.printf ("El número en decimal es: %d\n", numero);
            
        }
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}