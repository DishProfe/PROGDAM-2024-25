package ejemplos2024;

import java.time.LocalDate;
import java.time.DayOfWeek;
import java.util.Scanner;
import java.util.InputMismatchException;

/**
 * Ejemplos con la clase Rectangle
 */
public class BuscadorViernesTreceRobusto01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        final int YEAR_MIN = 1900;
        final int YEAR_MAX = 2100;

        // Variables de entrada
        int startYear = 0, endYear = 0;

        // Variables de salida
        // Variables auxiliares
        LocalDate fecha;
        boolean entradaValida;
        int numViernes13 = 0;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BUSCADOR DE VIERNES 13");
        System.out.println("----------------------");
        entradaValida = false;
        do {
            System.out.printf("Introduzca año de inicio: (%d-%d)",
                    YEAR_MIN, YEAR_MAX);
            try {
                startYear = teclado.nextInt();
            } catch (InputMismatchException ex) {
                teclado.nextLine();// Purgamos el buffer de teclado
            }
            entradaValida = startYear >= YEAR_MIN && startYear <= YEAR_MAX;
        } while (!entradaValida);

        entradaValida = false;
        do {
            System.out.printf("Introduzca año de fin: (%d-%d)",
                    startYear, YEAR_MAX);
            try {
                endYear = teclado.nextInt();
            } catch (InputMismatchException ex) {
                teclado.nextLine();// Purgamos el buffer de teclado
            }
            entradaValida = endYear >= startYear && endYear <= YEAR_MAX;
        } while (!entradaValida);


        //----------------------------------------------
        //                 Procesamiento 
        //                      +
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        LocalDate fechaFinal = LocalDate.of (endYear+1,1,1);
        fecha = LocalDate.of (startYear, 1, 13);        
        do {
            if ( fecha.getDayOfWeek().equals(DayOfWeek.FRIDAY) ) {
                numViernes13++;
                System.out.printf ("%2d: %s\n", 
                        numViernes13, fecha.toString());
            }
            fecha = fecha.plusMonths(1);
        } while ( fecha.isBefore(fechaFinal));
        
        System.out.println();
        System.out.println("Fin del programa.");

    }

}
