package ejemplos2024arrays;


import java.time.LocalTime;
import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class RepasoArrayHorario02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int hora, minuto;
        
        
        // Variables de salida
        LocalTime[] horario;
        
        
        // Variables auxiliares
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("HORARIO DE CLASES EN ARRAY");
        System.out.println("--------------------------");
        System.out.println ("Introduzca hora y minuto de la primera clase");
        System.out.print ("Hora:");
        hora = teclado.nextInt();
        System.out.print ("Minuto:");
        minuto = teclado.nextInt();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Reservamos espacio para el array (siete elementos: 6 sesiones + recreo)
        horario = new LocalTime[7];

        // Preparamos la hora de entrada
        LocalTime sesion = LocalTime.of (hora, minuto);
        
        // Rellenamos el array con la hora de comienzo de las tres primeras sesiones
        // más el comienzo del recreo (cuatro elementos)
        for (int indice=0 ; indice<7 ; indice++ ) {
            // Asignamos al horario la siguiente sesión
            horario[indice] = sesion;
            // Sumamos 1h o 30 min para calcular la siguiente sesión
            if (indice == 3) { // Si es justo después del recreo (indice=4) sumamos 30 min
                sesion =sesion.plusMinutes(30);
            } else {
                sesion = sesion.plusHours(1);
            }
        }


        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        // Mostramos el contenido del array de LocalTime
        System.out.println ("Horario de clases: ");
        System.out.println (Arrays.toString (horario));
        System.out.println ();
        
        
        

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}