package ejemplos2024arrays;


import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class RepasoArrayViernesTrece01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int yearInicial, yearFinal;
        
        
        // Variables de salida
        LocalDate[][] arrayViernes13;
        
        
        // Variables auxiliares
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println ("BUSCADOR DE VIERNES 13");
        System.out.println ("----------------------");
        System.out.println ("Introduzca año de inicio y fin para realizar la búsqueda");
        yearInicial = teclado.nextInt();
        yearFinal = teclado.nextInt();
        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Reservamos espacio para el array 
        // (primera dimensión: número de años, segunda dimensión: como mucho 3)
        arrayViernes13 = new LocalDate[yearFinal-yearInicial+1][3];

        // Recorremos los años
        for (int indiceYear=0; indiceYear < arrayViernes13.length ; indiceYear++ ) {
            int year = yearInicial + indiceYear;
            // Recorremos los meses dentro de cada año
            int indiceMes = 0;
            for ( int mes = 1 ; mes <= 12 ; mes++ ) {
                // Si el día 13 del mes es viernes, hemos encontrado uno
                LocalDate fechaDia13 = LocalDate.of (year, mes, 13);
                if ( fechaDia13.getDayOfWeek() == DayOfWeek.FRIDAY ) {
                    // Lo guardamos en el array
                    arrayViernes13[indiceYear][indiceMes++] = fechaDia13;
               }
            }
        }
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        // Mostramos el contenido del array 2D
        System.out.println ("Viernes 13 encontrados: ");
        System.out.println (Arrays.deepToString (arrayViernes13));
        System.out.println ();
        
        // Mostramos el contenido del array recorriendo la primera dimensión
        for (int indiceYear = 0 ; indiceYear < arrayViernes13.length ; indiceYear++ ) {
            System.out.printf ("%4d: %s\n", 
                    yearInicial + indiceYear,
                   Arrays.toString(arrayViernes13[indiceYear]));
        }
        System.out.println ();
        
        // Mostramos  el contenido del array recorriendo la primera dimensión
        // y también la segunda dimensión
        for (int indiceYear = 0 ; indiceYear < arrayViernes13.length ; indiceYear++ ) {
            System.out.printf ("%4d: ", 
                yearInicial + indiceYear);
            for (int indiceMes = 0 ; indiceMes < arrayViernes13[indiceYear].length && arrayViernes13[indiceYear][indiceMes] !=null ; indiceMes++ ) {
                System.out.printf ("%18s ", 
                    arrayViernes13[indiceYear][indiceMes]);
            }
            System.out.println ();
        }
        System.out.println ();

        

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
        
        
        
    }
    
}