package ejemplos2024arrays;


import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class RepasoArrayHorario01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int hora, minuto;
        
        
        // Variables de salida
        LocalTime[] horario;
        
        
        // Variables auxiliares
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("HORARIO DE CLASES EN ARRAY");
        System.out.println("--------------------------");
        System.out.println ("Introduzca hora y minuto de la primera clase");
        System.out.print ("Hora:");
        hora = teclado.nextInt();
        System.out.print ("Minuto:");
        minuto = teclado.nextInt();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Reservamos espacio para el array (siete elementos: 6 sesiones + recreo)
        horario = new LocalTime[7];

        // Preparamos la hora de entrada
        LocalTime sesion = LocalTime.of (hora, minuto);
        
        // Rellenamos el array con la hora de comienzo de las tres primeras sesiones
        // más el comienzo del recreo (cuatro elementos)
        for (int indice=0 ; indice<=3 ; indice++ ) {
            horario[indice] = sesion;
            sesion = sesion.plusHours(1);
        }

        // Calculamos la sesión tras el recreo 
        sesion = horario[3].plusMinutes(30);
        
        // Rellenamos el array con la hora de comienzo de las tres últimas sesiones
        // (tres elementos)
        for (int indice=4 ; indice<=6 ; indice++ ) {
            horario[indice] = sesion;
            sesion = sesion.plusHours(1);
        }
        

        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        // Mostramos el contenido del array de LocalTime
        System.out.println ("Horario de clases: ");
        System.out.println (Arrays.toString (horario));
        System.out.println ();
        
        
        

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}