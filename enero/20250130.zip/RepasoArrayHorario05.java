package ejemplos2024arrays;


import java.time.LocalTime;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class RepasoArrayHorario05 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int hora, minuto;
        int dia;
        
        
        // Variables de salida
        LocalTime[][] horario;
        
        
        // Variables auxiliares
        int duracionRecreo;
        int duracionSesion;
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println ("HORARIO SEMANAL DE CLASES EN ARRAY 2D");
        System.out.println ("-------------------------------------");
        System.out.println ("Si la primera clase comienza antes de las 12:00 se considera horario de mañana");
        System.out.println ("Duración sesiones para horarios de mañana: 1 hora");
        System.out.println ("Duración sesiones para horarios de tarde: 45 min");
        System.out.println ("Recreo para horarios de mañana: 30min");
        System.out.println ("Recreo para horarios de tarde:  15min");
        System.out.println ("Introduzca hora y minuto de la primera clase");
        System.out.print ("Hora:");
        hora = teclado.nextInt();
        System.out.print ("Minuto:");
        minuto = teclado.nextInt();
        System.out.println ("Introduzca día del mes actual");
        dia = teclado.nextInt();
        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Calculamos el lunes de la semana en la que se encuentra el día introducido
        LocalDate hoy = LocalDate.now();
        LocalDate fechaDia = LocalDate.of (hoy.getYear(), hoy.getMonth(), dia);
        // Hay que restar el día de la semana-1 a ese día para obtener su lunes
        int diaSemana = fechaDia.getDayOfWeek().getValue();
        LocalDate fechaLunes = fechaDia.minusDays(diaSemana-1);
        
        // Reservamos espacio para el array (siete elementos: 6 sesiones + recreo)
        horario = new LocalTime[5][7];

        // Comprobamos si es horario de mañana o de tarde para decidir 
        // la duración de recreo (30/15 min) y la duración de sesión (60/45 min)
        duracionRecreo = hora < 12 ? 30 : 15;
        duracionSesion = hora < 12 ? 60 : 45;

        // Bucle para rellenar los cinco días de la semana
        for (int indiceDia=0; indiceDia<horario.length ; indiceDia++ ) {
            // Preparamos la hora de entrada
            LocalTime sesion = LocalTime.of (hora, minuto);

            // Rellenamos el array con la hora de comienzo de las tres primeras sesiones
            // más el comienzo del recreo (cuatro elementos)
            for (int indiceSesion=0 ; indiceSesion<7 ; indiceSesion++ ) {
                // Asignamos al horario la siguiente sesión
                horario[indiceDia][indiceSesion] = sesion;
                // Sumamos 1h o 15/30 min para calcular la siguiente sesión
                if (indiceSesion == 3) { // Si es justo después del recreo (indice=4) sumamos la duración del recreo
                    sesion =sesion.plusMinutes(duracionRecreo);
                } else {
                    sesion = sesion.plusMinutes(duracionSesion);
                }
            }
        }
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        // Mostramos el contenido del array 2D
        System.out.println ("Horario de clases: ");
        System.out.println (Arrays.deepToString (horario));
        System.out.println ();
        
        // Mostramos el contenido del array recorriendo la primera dimensión
        for (int indiceDia = 0 ; indiceDia < horario.length ; indiceDia++ ) {
            System.out.printf ("%s - %-10s: %s\n", 
                    fechaLunes.plusDays(indiceDia),
                    fechaLunes.plusDays(indiceDia).getDayOfWeek(),
                    Arrays.toString(horario[indiceDia]));
        }
        
        

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
        
        
        
    }
    
}