package ejemplos20024arrays;


import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class ArrayCalendario04 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida

        // Array principal (primera dimensión): array de arrays de fechas
        DayOfWeek[][] calendario;
        
        // Subarrays de fechas (segunda dimensión)
        
        
        // Variables auxiliares
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CALENDARIO: DÍA DE LA SEMANA");
        System.out.println("----------------------------");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Calculamos el año actual
        int year= LocalDate.now().getYear();
        
        // Reservamos espacio para el array principal (primera dimensión)
        calendario = new DayOfWeek[12][];
        
        // Reservamos espacio para los subarrays (segunda dimensión) y los asignamos como
        // elementos del primer array (array principal o primera dimensión)
        for (int mes = 0; mes < calendario.length ;  mes++ ) {
            calendario[mes] =  new DayOfWeek[ LocalDate.of(year, mes+1, 1).lengthOfMonth() ];
        }
        
        // Rellenamos cada subarray con los primeros días de cada mes
        LocalDate fecha= LocalDate.of(year, 1, 1);
        for (int mes = 0; mes < calendario.length;  mes++ ) {
            // Calculamos la fecha inicial de cada subarray (día 1 del mes)
            for (int dia=0 ; dia < calendario[mes].length ; dia ++) {
                calendario[mes][dia] =  fecha.getDayOfWeek();
                fecha = fecha.plusDays(1);
            }
        }
        
    
        


        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        // Mostramos el contenido del array de arrays de fechas
        System.out.println ("Calendario: Array de arrays de fechas");
        System.out.println (Arrays.toString (calendario));
        System.out.println (Arrays.deepToString (calendario));
        System.out.println ();
        
        
        // Acceso a todas las posiciones del array "principal" (primera dimensión):
        // los componentes son a su vez arrays
        System.out.println ("Recorrido de la primera dimensión del array");
        for (int indice1 = 0 ; indice1 < calendario.length ; indice1 ++ ) {
            System.out.printf ("[%2d]: %s\n", indice1, Arrays.deepToString(calendario[indice1]));
        }
        System.out.println ();
        
        // Acceso a todas las posiciones bidimensionales del array (dos coordenadas): primeras dos dimensiones
        System.out.println ("Recorrido de las dos dimensiones del array");
        for (int mes = 0 ; mes < calendario.length ; mes ++ ) {
            fecha = LocalDate.of (year, mes+1, 1);
            System.out.printf ("%-10s", fecha.getMonth() + ":" );
            for (int dia = 0 ; dia < calendario[mes].length ; dia++ ) {
                System.out.printf ("%10s ", calendario[mes][dia]);
            }
            System.out.println ();
        }
        System.out.println ();
        

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}