package ejemplos20024arrays;


import java.util.Arrays;
import java.util.Scanner;

/**
 *   Programa
 */

    public class Split01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida
        String[] lista;

        // Variables auxiliares
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE SPLIT");
        System.out.println("-----------------");

        
        System.out.println ("Introduzca un texto con elementos usando la combinación de separadores \"+*-\": ");        
        String linea = teclado.nextLine();
        lista = linea.split ("[*+-]+"); // Los separadores de elementos serán cualquier combinación de *, + y -
        System.out.printf ("\nLos elementos son: %s\n", Arrays.toString(lista));       


        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Mostramos el contenido del array mediante un bucle
        for ( int indice = 0; indice < lista.length ; indice++ ) {
            System.out.printf ("Posición %2d: %s\n",
                    indice, lista[indice]);
        }
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}