package ejemplos2024;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class RepasoDivisores01 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numero;

        // Variables de salida
        int divisor;
        
        // Variables auxiliares
        
        // Entrada de datos 
        // -----------------
        System.out.println("CÁLCULO DE DIVISORES DE UN NÚMERO");
        System.out.println("---------------------------------");

        System.out.println ("Introduzca número positivo > 2");
        numero = teclado.nextInt();

        
        // Procesamiento + Salida de resultados
        // ------------------------------------
        System.out.println ("Los divisores del número son:");
        for ( divisor = 2; divisor < numero ; divisor++ ) {
            
            if ( numero % divisor == 0 ) {
                System.out.println (divisor);
            } 
        }
        
        System.out.println();

    }

}
