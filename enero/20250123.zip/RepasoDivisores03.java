package ejemplos2024;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class RepasoDivisores03 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numero=0;

        // Variables de salida
        int divisor;
        
        // Variables auxiliares
        boolean entradaValida;
        
        // Entrada de datos 
        // -----------------
        System.out.println("CÁLCULO DE DIVISORES DE UN NÚMERO");
        System.out.println("---------------------------------");

        entradaValida = false;
        do {
            System.out.println ("Introduzca número positivo > 1");
            try {
                numero = teclado.nextInt();                
                entradaValida = numero > 1;                
            } catch ( InputMismatchException ex ) {
                teclado.nextLine();
            }
        } while ( !entradaValida );
        System.out.println();

        
        // Procesamiento + Salida de resultados
        // ------------------------------------
        System.out.println ("Los divisores del número son:");
        for ( divisor = 2; divisor < numero ; divisor++ ) {            
            if ( numero % divisor == 0 ) {
                System.out.println (divisor);
            } 
        }
        
        System.out.println();

    }

}
