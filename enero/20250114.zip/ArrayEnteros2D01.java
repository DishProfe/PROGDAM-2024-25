package ejemplos20024arrays;


import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class ArrayEnteros2D01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida
        int[][] arrayEnteros2D;
        
        int[] arrayPares;
        int[] arrayPositivos;
        int[] arrayCientos;

        // Variables auxiliares
        int[] arrayAleatorios;
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("VARIOS ARRAYS DE ENTEROS");
        System.out.println("------------------------");

        
        // Reservamos espacio para los arrays de int
        arrayPares = new int[4];
        arrayPositivos = new int[4];
        arrayCientos = new int[4];

        // Reservamos espacio para el array de arrays de int
        arrayEnteros2D = new int[3][];
        
        // Rellenamos el contenido de los arrays con un bucle
        for ( int indice=0 ; indice < arrayPares.length ; indice++ ) {
            arrayPares[indice] = indice*2;
            arrayPositivos[indice] = indice+1;
            arrayCientos[indice] = (indice+1)*100;            
        }
        
        // Rellenamos el contenido del array de arrays de int
        arrayEnteros2D[0] = arrayPares;
        arrayEnteros2D[1] = arrayPositivos;
        arrayEnteros2D[2] = arrayCientos;

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        


        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Mostramos el contenido de los arrays de enteros
        System.out.println ("Array de pares");
        System.out.println (Arrays.toString (arrayPares));
        System.out.println ();
        System.out.println ("Array de positivos");
        System.out.println (Arrays.toString (arrayPositivos));
        System.out.println ();
        System.out.println ("Array de cientos");
        System.out.println (Arrays.toString (arrayCientos));
        System.out.println ();
        
        // Mostramos el contenido del array de arrays de enteros
        System.out.println ("Array de arrays de enteros");
        System.out.println (Arrays.toString (arrayEnteros2D));
        System.out.println (Arrays.deepToString (arrayEnteros2D));
        System.out.println ();
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}