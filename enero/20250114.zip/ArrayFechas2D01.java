package ejemplos20024arrays;


import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class ArrayFechas2D01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida

        // Array principal (primera dimensión): array de arrays de fechas
        LocalDate[][] arrayFechas;
        
        // Subarrays de fechas (segunda dimensión)
        LocalDate[] array5UltimosDiasYear;
        LocalDate[] arrayUltimosDias5PrimerosMesesYear;
        
        
        // Variables auxiliares
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ARRAYS DE ARRAYS DE FECHAS");
        System.out.println("-------------------------------------");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Calculamos el año actual
        int year= LocalDate.now().getYear();
        
        // Reservamos espacio para el array principal (primera dimensión)
        arrayFechas = new LocalDate[2][];
        
        // Reservamos espacio para los subarrays (segunda dimensión)
        array5UltimosDiasYear = new LocalDate[5];
        arrayUltimosDias5PrimerosMesesYear = new LocalDate[5];
        
        // Rellenamos el primer array con los últimos cinco días del año actual
        LocalDate fecha= LocalDate.of(year, 12, 31);
        for (int contador = 0; contador < 5;  contador++ ) {
            array5UltimosDiasYear[contador] =  fecha;
            fecha = fecha.minusDays(1);
        }
        // Los ordenamos en orden ascendente
        Arrays.sort (array5UltimosDiasYear);

        // Rellenamos el segundo array con el último día de los cinco primeros meses del año actual
        fecha= LocalDate.of(year, 1, 31);
        for (int contador = 0; contador < 5;  contador++ ) {
            arrayUltimosDias5PrimerosMesesYear[contador] =  fecha;
            fecha = fecha.plusDays(1); // Pasamos al mes siguiente
            int longMes = fecha.lengthOfMonth(); // Calculamos cuántos días tiene ese mes
            fecha = LocalDate.of (year, fecha.getMonth(), longMes); // Creamos una fecha con ese mes y su último día
        }
        
        // Asignamos a las posiciones del array principal (primera dimensión)
        // los arrays de fechas (segunda dimensión)
        arrayFechas[0] = array5UltimosDiasYear;
        arrayFechas[1] = arrayUltimosDias5PrimerosMesesYear;
        
        
        
    
        


        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        // Mostramos el contenido del array de arrays de fechas
        System.out.println ("Array de arrays de fechas");
        System.out.println (Arrays.toString (arrayFechas));
        System.out.println (Arrays.deepToString (arrayFechas));
        System.out.println ();
        
        
        // Acceso a todas las posiciones del array "principal" (primera dimensión):
        // los componentes son a su vez arrays
        System.out.println ("Recorrido de la primera dimensión del array");
        for (int indice1 = 0 ; indice1 < arrayFechas.length ; indice1 ++ ) {
            System.out.printf ("[%d]: %s\n", indice1, Arrays.deepToString(arrayFechas[indice1]));
        }
        System.out.println ();
        
        // Acceso a todas las posiciones bidimensionales del array (dos coordenadas): primeras dos dimensiones
        System.out.println ("Recorrido de las dos dimensiones del array");
        for (int indice1 = 0 ; indice1 < arrayFechas.length ; indice1 ++ ) {
            for (int indice2 = 0 ; indice2 < arrayFechas[indice1].length ; indice2++ ) {
                System.out.printf ("[%d][%d]: %s ", indice1, indice2, arrayFechas[indice1][indice2]);
            }
            System.out.println ();
        }
        System.out.println ();
        

        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}