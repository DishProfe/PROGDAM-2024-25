package ejemplos20024arrays;


import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class ArrayEnteros3D02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida
        
        int[] arrayPares;
        int[] arrayPositivos;
        int[] arrayCientos;
        int[] arrayPrimos = { 2, 3, 5, 7, 11, 13, 17, 19};
        int[] arrayFibonacci = { 1, 1, 2, 3, 5, 8};


        // Variables auxiliares
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ARRAYS DE ARRAYS DE ARRAYS DE ENTEROS");
        System.out.println("-------------------------------------");

        
        // Reservamos espacio para los arrays de int
        arrayPares = new int[4];
        arrayPositivos = new int[4];
        arrayCientos = new int[4];

        // Rellenamos el contenido de los arrays finales con un bucle
        for ( int indice=0 ; indice < arrayPares.length ; indice++ ) {
            arrayPares[indice] = indice*2;
            arrayPositivos[indice] = indice+1;
            arrayCientos[indice] = (indice+1)*100;            
        }
        
        // Rellenamos el contenido del array de arrays de arrays de int
        int[][][] arrayEnteros3D = { { arrayPares, arrayPositivos, arrayCientos  } , { arrayPrimos, arrayFibonacci }  } ;

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        


        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Mostramos el contenido de los arrays de enteros
        System.out.println ("Array de pares");
        System.out.println (Arrays.toString (arrayPares));
        System.out.println ();
        System.out.println ("Array de positivos");
        System.out.println (Arrays.toString (arrayPositivos));
        System.out.println ();
        System.out.println ("Array de cientos");
        System.out.println (Arrays.toString (arrayCientos));
        System.out.println ();
        System.out.println ("Array de primos");
        System.out.println (Arrays.toString (arrayPrimos));
        System.out.println ();
        System.out.println ("Array de Fibonacci");
        System.out.println (Arrays.toString (arrayFibonacci));
        System.out.println ();
        
        // Mostramos el contenido del array de arrays de enteros
        System.out.println ("Array de arrays de enteros");
        System.out.println (Arrays.toString (arrayEnteros3D));
        System.out.println (Arrays.deepToString (arrayEnteros3D));
        System.out.println ();
        
        
        // Acceso a todas las posiciones del array "principal" (primera dimensión):
        // los componentes son a su vez arrays
        System.out.println ("Recorrido de la primera dimensión del array");
        for (int indice1 = 0 ; indice1 < arrayEnteros3D.length ; indice1 ++ ) {
            System.out.printf ("[%d]: %s\n", indice1, Arrays.deepToString(arrayEnteros3D[indice1]));
        }
        System.out.println ();
        
        // Acceso a todas las posiciones bidimensionales del array (dos coordenadas): primeras dos dimensiones
        System.out.println ("Recorrido de las dos dimensiones del array");
        for (int indice1 = 0 ; indice1 < arrayEnteros3D.length ; indice1 ++ ) {
            for (int indice2 = 0 ; indice2 < arrayEnteros3D[indice1].length ; indice2++ ) {
                System.out.printf ("[%d][%d]: %s ", indice1, indice2, Arrays.toString (arrayEnteros3D[indice1][indice2]));
            }
            System.out.println ();
        }
        System.out.println ();
        System.out.println ();
        
        // Acceso a todas las posiciones tridimensionales del array (tres coordenadas)
        System.out.println ("Recorrido de las tres dimensiones del array");
        for (int indice1 = 0 ; indice1 < arrayEnteros3D.length ; indice1 ++ ) {
            for (int indice2 = 0 ; indice2 < arrayEnteros3D[indice1].length ; indice2++ ) {
                for (int indice3 = 0; indice3 < arrayEnteros3D[indice1][indice2].length ; indice3++ ) {
                    System.out.printf ("[%d][%d][%d]:%3d ", indice1, indice2, indice3, 
                            arrayEnteros3D[indice1][indice2][indice3]);                    
                }
                System.out.println ();
            }
            System.out.println ();
        }



        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}