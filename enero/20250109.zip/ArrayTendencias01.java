package ejemplos20024arrays;


import java.util.Scanner;
import java.util.Arrays;
import java.util.InputMismatchException;

/**
 *   Programa
 */

    public class ArrayTendencias01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int longArray = 20;
        
        // Variables de salida
        int[] arrayTendencias;
        int numPares, numImpares;

        // Variables auxiliares
        int[] arrayAleatorios;
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ARRAY DE ENTEROS ALEATORIOS");
        System.out.println("---------------------------");
        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        // Parte 1: Array de aleatorios 
        // ----------------------------
        
        // Reservamos espacio para el array
        arrayAleatorios = new int[longArray];

        // Rellenamos el contenido del array con un bucle
        for ( int indice=0 ; indice < arrayAleatorios.length ; indice++ ) {
            int aleatorio = (int)(Math.random()*11);
            arrayAleatorios[indice] = aleatorio;
        }
        

        // Parte 2: búsqueda de tendencias dentro del array
        // ------------------------------------------------
        
        // Reservamos espacio para los arrays de pares e impares (del mismo tamaño que el array original)
        arrayTendencias = new int[arrayAleatorios.length];

        // Iniciamos los contadores a cero
        
        // Recorremos el array de aleatorios y analizo la tendencia
        for ( int indice=0 ; indice < arrayAleatorios.length-1 ; indice++ ) {
            if ( arrayAleatorios[indice] < arrayAleatorios[indice+1]) {
                // Tendencia de subida
                arrayTendencias[indice] = 1;
            } else if ( arrayAleatorios[indice] > arrayAleatorios[indice+1]) {
                // Tendencia de bajada
                arrayTendencias[indice] = -1;
            } else {
                // Tendencia sostenida
                arrayTendencias[indice] = 0;
            }
        }
        


        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Mostramos el contenido del array original
        System.out.println ("Array de aleatorios original:");
        System.out.printf ("Número total de elementos: %d\n", longArray);
        System.out.println (Arrays.toString (arrayAleatorios));
        System.out.println ();
        
        // Mostramos el contenido del array de tendencias
        System.out.println ("Array de tendencias:");
        System.out.println (Arrays.toString (arrayTendencias));
        System.out.println ();
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}