package ejemplos20024arrays;


import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class ArrayAleatorios03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida
        int[] arrayPares;
        int[] arrayImpares;

        // Variables auxiliares
        int[] arrayAleatorios;
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ARRAY DE ENTEROS ALEATORIOS");
        System.out.println("---------------------------");

        
        // Reservamos espacio para el array
        arrayAleatorios = new int[10];

        // Rellenamos el contenido del array con un bucle
        for ( int indice=0 ; indice < arrayAleatorios.length ; indice++ ) {
            int aleatorio = (int)(Math.random()*101);
            arrayAleatorios[indice] = aleatorio;
        }
        
        // Mostramos el contenido del array original
        System.out.println (Arrays.toString (arrayAleatorios));

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Reservamos espacio para los arrays de pares e impares (del mismo tamaño que el array original)
        arrayPares = new int[10];
        arrayImpares = new int[10];

        // Recorremos el array de aleatorios y si encuentro un par lo meto en el otro array
        for ( int indice=0, indicePares=0, indiceImpares=0 ; indice < arrayAleatorios.length ; indice++ ) {
            int elemento = arrayAleatorios[indice];
            if ( elemento % 2 == 0 ) {
                // Cada vez que encuentre un par lo meto en el array y avanzo su índice
                arrayPares[indicePares++] = elemento;
            } else {
                // Si no es par, lo meto en el otro array
                arrayImpares[indiceImpares++] = elemento;                
            }
        }
        


        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Mostramos el contenido del array original
        System.out.println ("Array de aleatorios original:");
        System.out.println (Arrays.toString (arrayAleatorios));
        System.out.println ();
        
        // Mostramos el contenido del array de pares
        System.out.println ("Array de pares:");
        System.out.println (Arrays.toString (arrayPares));
        System.out.println ();
        
        // Mostramos el contenido del array de impares
        System.out.println ("Array de impares:");
        System.out.println (Arrays.toString (arrayImpares));
        System.out.println ();
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}