package ejemplos20024arrays;


import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class ArrayAleatorios01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida

        // Variables auxiliares
        int[] arrayAleatorios;
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ARRAY DE ENTEROS ALEATORIOS");
        System.out.println("---------------------------");

        
        // Reservamos espacio para el array
        arrayAleatorios = new int[10];

        // Rellenamos el contenido del array con un bucle
        for ( int indice=0 ; indice < arrayAleatorios.length ; indice++ ) {
            int aleatorio = (int)(Math.random()*101);
            arrayAleatorios[indice] = aleatorio;
        }
        


        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Mostramos el contenido del array mediante un bucle
        for ( int indice = 0; indice < arrayAleatorios.length ; indice++ ) {
            int numero = arrayAleatorios[indice];
            System.out.printf ("Posición %2d: %3d\n",
                    indice, 
                    numero
            );
        }
        
        System.out.println();
        System.out.println ("Conenido del array usando Arrays.toString:");
        System.out.println (Arrays.toString (arrayAleatorios));
        
        
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}