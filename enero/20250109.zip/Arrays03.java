package ejemplos20024arrays;


import java.util.Scanner;

/**
 *   Programa
 */

    public class Arrays03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida

        // Variables auxiliares
        int[] arrayNumeros;
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE ARRAYS");
        System.out.println("------------------");

        
        // Reservamos espacio para el array
        arrayNumeros = new int[20];

        // Rellenamos el contenido del array con un bucle
        for ( int indice=0 ; indice < arrayNumeros.length ; indice++ ) {
            int aleatorio = (int)(Math.random()*10_000);
            arrayNumeros[indice] = aleatorio;
        }
        


        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Mostramos el contenido del array mediante un bucle
        for ( int indice = 0; indice < arrayNumeros.length ; indice++ ) {
            int numero = arrayNumeros[indice];
            System.out.printf ("Posición %1$2d: %2$5d %2$05d %2$05x %2$05X %3$16s %4$s\n",
                    indice, 
                    numero,
                    Integer.toBinaryString(numero),
                    String.format("%16s", Integer.toBinaryString(numero)).replace(' ', '0')
            );
        }
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}