package ejemplos20024arrays;


import java.util.Scanner;
import java.util.Arrays;
import java.util.InputMismatchException;

/**
 *   Programa
 */

    public class ArrayAleatorios04 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int longArray = 0;
        
        // Variables de salida
        int[] arrayPares;
        int[] arrayImpares;
        int numPares, numImpares;

        // Variables auxiliares
        int[] arrayAleatorios;
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ARRAY DE ENTEROS ALEATORIOS");
        System.out.println("---------------------------");
        
        System.out.println ("Introduzca tamaño del array: (10-20)");
        boolean entradaValida = false;
        do {
            try {
                longArray = teclado.nextInt();
                entradaValida = longArray>=10 && longArray<=20;
            } catch ( InputMismatchException ex ) {
                teclado.nextLine();
            }
        } while (!entradaValida);
        
        

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        // Parte 1: Array de aleatorios 
        // ----------------------------
        
        // Reservamos espacio para el array
        arrayAleatorios = new int[longArray];

        // Rellenamos el contenido del array con un bucle
        for ( int indice=0 ; indice < arrayAleatorios.length ; indice++ ) {
            int aleatorio = (int)(Math.random()*101);
            arrayAleatorios[indice] = aleatorio;
        }
        
        // Mostramos el contenido del array original
        //System.out.println (Arrays.toString (arrayAleatorios));


        // Parte 2: búsqueda dentro del array
        // ----------------------------------
        
        // Reservamos espacio para los arrays de pares e impares (del mismo tamaño que el array original)
        arrayPares = new int[arrayAleatorios.length];
        arrayImpares = new int[arrayAleatorios.length];

        // Iniciamos los contadores a cero
        numPares = 0;
        numImpares = 0;
        
        // Recorremos el array de aleatorios y si encuentro un par lo meto en el otro array
        for ( int indice=0 ; indice < arrayAleatorios.length ; indice++ ) {
            int elemento = arrayAleatorios[indice];
            if ( elemento % 2 == 0 ) {
                // Cada vez que encuentre un par lo meto en el array y avanzo su índice
                arrayPares[numPares++] = elemento;
            } else {
                // Si no es par, lo meto en el otro array
                arrayImpares[numImpares++] = elemento;                
            }
        }
        


        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Mostramos el contenido del array original
        System.out.println ("Array de aleatorios original:");
        System.out.printf ("Número total de elmentos: %d\n", longArray);
        System.out.println (Arrays.toString (arrayAleatorios));
        System.out.println ();
        
        // Mostramos el contenido del array de pares
        System.out.println ("Array de pares:");
        System.out.printf ("Número de elmentos pares: %d\n", numPares);
        System.out.println (Arrays.toString (arrayPares));
        System.out.println ();
        
        // Mostramos el contenido del array de impares
        System.out.println ("Array de impares:");
        System.out.printf ("Número de elmentos impares: %d\n", numImpares);
        System.out.println (Arrays.toString (arrayImpares));
        System.out.println ();
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}