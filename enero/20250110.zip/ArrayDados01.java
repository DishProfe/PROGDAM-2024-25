package ejemplos20024arrays;

import java.util.Scanner;
import java.util.Arrays;
import aguadulce.Dado;

/**
 * Programa
 */
public class ArrayDados01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        Dado[] arrayDados = {new Dado(4), new Dado(6), new Dado(8), new Dado(12), new Dado(20)};

        // Variables de salida
        long[] arrayPuntuaciones;
        long[] arrayLanzamientos;

        // Variables auxiliares
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ARRAYS DE DADOS Y PUNTUACIONES");
        System.out.println("------------------------------");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Reservamos espacio para el array
        arrayPuntuaciones = new long[arrayDados.length];
        arrayLanzamientos = new long[arrayDados.length];

        // Lanzamos cada dado 10 veces
        for (int tirada = 1; tirada <= 10; tirada++) {
            System.out.printf ("Tirada %2d: ", tirada);
            for (int contadorDado = 0; contadorDado < arrayDados.length; contadorDado++) {
                String lanzamiento = arrayDados[contadorDado].lanzar();
                System.out.printf ("%12s  ", lanzamiento);
            }
            System.out.println();
        }

        // Almacenamos las puntuaciones de cada dado
        for (int contadorDado = 0; contadorDado < arrayDados.length; contadorDado++) {
            arrayPuntuaciones[contadorDado] = arrayDados[contadorDado].getSumaPuntuacionHistorica();
            arrayLanzamientos[contadorDado] = arrayDados[contadorDado].getNumeroLanzamientos();
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        // Mostramos el contenido de los arrays
        System.out.println("Array de dados:");
        System.out.println(Arrays.toString(arrayDados));
        System.out.println();
        System.out.println("Array de puntuaciones:");
        System.out.println(Arrays.toString(arrayPuntuaciones));
        System.out.println();
        System.out.println("Array de cantidad de tiradas:");
        System.out.println(Arrays.toString(arrayLanzamientos));
        System.out.println();

        System.out.println();
        System.out.println("Fin del programa.");

    }

}
