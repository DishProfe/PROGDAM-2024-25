package ejemplos20024arrays;


import java.time.LocalDate;
import java.time.DayOfWeek;
import java.util.Scanner;
import java.util.Arrays;

/**
 *   Programa
 */

    public class ArrayFechas01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int longArray = 20;
        
        // Variables de salida
        LocalDate[] arrayLunes;
 
        // Variables auxiliares
        int[] arrayAleatorios;
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ARRAY DE LOS DIEZ PRIMEROS LUNES");
        System.out.println("--------------------------------");
        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        // Reservamos espacio para el array
        arrayLunes = new LocalDate[10];

        // Calculamos el año actual
        int yearActual = LocalDate.now().getYear();
        //yearActual= 2022;
        
        // Buscamos el primer lunes del año
        LocalDate fecha = LocalDate.of (yearActual, 1, 1);        
        while ( fecha.getDayOfWeek() != DayOfWeek.MONDAY ) {
            fecha = fecha.plusDays(1);
        }   
        
        // A partir de ese lunes calulamos los diez primeros lunes el alp
        // de 7 en 7
        for (int indice = 0; indice < arrayLunes.length ; indice++ ) {
            arrayLunes[indice] = fecha;
            fecha = fecha.plusWeeks(1);
        }    
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        // Mostramos el contenido del array original
        System.out.printf ("Año actual: %d", yearActual);
        System.out.println ("Array de lunes:");
        System.out.println (Arrays.toString (arrayLunes));
        System.out.println ();
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}