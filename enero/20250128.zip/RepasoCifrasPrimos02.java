package ejemplos2024;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class RepasoCifrasPrimos02 {

    public static void main(String[] args) {
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        // Variables
        // ---------
        // Variables de entrada
        int numero=0;

        // Variables de salida
        int primerPrimoConNCifras;
        
        // Variables auxiliares
        boolean entradaValida;
        int divisor;
        int numCifras;
        int residuo;
        int candidatoPrimo;
        boolean esPrimo;
        
        // Entrada de datos 
        // -----------------
        System.out.println("CÁLCULO DEL PRIMER PRIMO CON UN DETERMINADO NÚMERO DE CIFRAS");
        System.out.println("------------------------------------------------------------");

        entradaValida = false;
        do {
            System.out.println ("Introduzca número positivo > 1");
            try {
                numero = teclado.nextInt();                
                entradaValida = numero > 1;                
            } catch ( InputMismatchException ex ) {
                teclado.nextLine();
            }
        } while ( !entradaValida );
        System.out.println();

        
        // Procesamiento 
        // -------------

        // Cálculo del número de cifras de la entrada
        numCifras = 0;
        residuo = numero;
        do {
            numCifras++;
            residuo = residuo / 10;
        } while ( residuo > 0 );
        
        //numCifras = (int) Math.log10(numero) + 1;
        
        // A partir de ahí, calculamos el primer primo que exita con ese número de cifras
        
        
        // Calculamos el número más pequeño con ese número de cifras 
        candidatoPrimo = (int)Math.pow(10, numCifras-1) + 1;

        // Empezamos a probar a partir de ese número 
        // hasta que encontremos un primo
        do {
            divisor = 2;
            esPrimo = true;
            do {
                if ( candidatoPrimo % divisor == 0 ) {
                    esPrimo = false;
                }
                divisor++;
            } while (esPrimo && divisor < Math.sqrt(candidatoPrimo  ));
            if ( !esPrimo ) {
                candidatoPrimo +=2;
            }
        } while ( !esPrimo );

        primerPrimoConNCifras = candidatoPrimo;
        
        // Salida de resultados
        // --------------------
        System.out.printf ("Primer primo con %d cifras: %d\n",
                numCifras, primerPrimoConNCifras);

        System.out.println();

    }

}
